# Kaggle eval run corpus_gemma27b_fixes

100 questions, 5 cases

## gemma3:27b-it-qat

- answers 100 (errors 0, empty 0), cases 5 (errors 0)
- judge-free: multiple choice 0.875 (n=16), yes/no label 0.833 (n=18)
- repairs {'label_fixed': 3, 'hebrew_rewrite': 5}; case repairs {'facts_revised': 2}; answers with other-script words: 3

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 105 | 0 | 0 | 19.6 | 7355 | 2674 |
| legal_eval_label_check | 18 | 0 | 0 | 2.3 | 386 | 7 |
| legal_eval_plan | 105 | 0 | 0 | 16.3 | 1295 | 409 |
| legal_eval_repair | 2 | 0 | 0 | 184.2 | 3785 | 2424 |
| legal_eval_rewrite | 5 | 0 | 0 | 18.0 | 320 | 247 |

### Against the 12B baseline (judge-free)

| | gemma3:12b (29 Sept, before the fixes) | gemma3:27b-it-qat |
|---|---|---|
| multiple choice | 0.812 | 0.875 |
| yes/no label | 0.722 | 0.833 |
| governing section retrieved (%) | 83.7 | 88.8 |
| questions retrieving West Bank military orders | 15 | 0 |
| questions retrieving Jordanian criminal law | 11 | 0 |
| questions retrieving Repealed Civil Procedure Regs 1984 | 9 | 0 |
| questions retrieving Herut draft constitution | 4 | 0 |
| non-yes/no answers opening with כן/לא (as written) | 55 of 66 | 2 of 66 |
| plans cut off | 4 | 0 |
| median answer call (s) | 9.8 | 19.6 |
| median plan call (s) | 9.1 | 16.3 |
| judged overall / cases average | 69.2 / 42.8 | after Claude's judging |
