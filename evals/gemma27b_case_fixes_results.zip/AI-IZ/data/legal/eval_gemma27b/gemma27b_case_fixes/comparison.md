# Kaggle eval run gemma27b_case_fixes

36 questions (affected), 5 cases -- against gemma3:27b-it-qat, 29 Sept (before these fixes)

## gemma3:27b-it-qat

### Questions (affected)

| | 29 Sept | now |
|---|---|---|
| plans cut off | 36 | 0 |
| plans with section numbers | 2 | 31 |
| plans with gregorian years | 0 | 36 |
| governing section retrieved pct | 88.6 | 88.6 |
| multiple choice | 2/3 | 2/3 |
| yes no label | 6/8 | 7/8 |
| judged score (%) | 71.5 | after Claude's judging |

answers 36 (errors 0, empty 0); repairs {'label_fixed': 2}; answers with a stray template token: 0

### Cases

| case | rubric sections retrieved (29 Sept / now) | deadline hedges | flagged values | repairs | plan issues | minutes |
|---|---|---|---|---|---|---|
| case_01 | 1/10 / 2/10 | 3 / 2 | - / - | - | 8 | 4.8 |
| case_02 | 2/5 / 2/5 | 3 / 5 | 3.2, 20.2, 10.3, 20.3, 8,000 / - | - | 8 | 4.4 |
| case_03 | 3/5 / 4/5 | 2 / 1 | 16.9, 17.9 / 1.10 | facts_revised | 8 | 6.5 |
| case_04 | 1/9 / 1/9 | 3 / 0 | - / - | - | 8 | 4.4 |
| case_05 | 4/9 / 1/9 | 3 / 1 | - / - | - | 8 | 4.9 |

rubric sections retrieved in total: 11/38 -> 10/38; case plans cut off: 3 -> 0; judged average: 37.0 (12B re-graded: 34.8) -> after Claude's judging

- case_01 still missing: חוק בית הדין לעבודה s.24; חוק הגנת השכר s.17; חוק הגנת השכר s.9; חוק הודעה מוקדמת לפיטורים ולהתפטרות s.3; חוק פיצויי פיטורים s.1; חוק פיצויי פיטורים s.12; חוק שוויון ההזדמנויות בעבודה s.2; חוק שוויון ההזדמנויות בעבודה s.9
- case_02 still missing: חוק החוזים (תרופות בשל הפרת חוזה) s.10; חוק החוזים (תרופות בשל הפרת חוזה) s.2; חוק השכירות והשאילה s.25ח
- case_03 still missing: חוק הגנת הצרכן s.2
- case_04 still missing: חוק החוזים (תרופות בשל הפרת חוזה) s.10; חוק החוזים (תרופות בשל הפרת חוזה) s.2; חוק החוזים (תרופות בשל הפרת חוזה) s.9; חוק המקרקעין s.126; חוק המקרקעין s.127; חוק המקרקעין s.7; חוק העונשין s.415; פקודת הנזיקין [נוסח חדש] s.35
- case_05 still missing: חוק הירושה s.19; חוק הירושה s.20; חוק הירושה s.26; חוק הירושה s.27; חוק הירושה s.30; חוק הירושה s.35; חוק הירושה s.56; חוק יחסי ממון בין בני זוג s.5

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 41 | 0 | 0 | 21.8 | 7287 | 3056 |
| legal_eval_label_check | 8 | 0 | 0 | 2.3 | 387 | 7 |
| legal_eval_plan | 41 | 0 | 0 | 15.2 | 1333 | 527 |
| legal_eval_repair | 1 | 0 | 0 | 172.3 | 3466 | 2088 |
