# LLM trace

| call site | calls | seconds | stopped on length | errors |
|---|---|---|---|---|
| legal_eval_baseline | 105 | 1516 | 0 | 0 |
| legal_eval_plan | 104 | 1108 | 4 | 0 |

## IL-001

### 1. legal_eval_plan (attempt 1, 86.1 s, tokens 126 in / 118 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Formation of a Contract - General Principles",
"law": "חוק החוזים (חלק כללי), התשלג"
},
{
"issue": "Offer and Acceptance",
"law": "חוק החוזים (חלק כללי), התשלג"
},
{
"issue": "Intention to Create Legal Relations",
"law": "חוק החוזים (חלק כללי), התשלג"
}
] }
```

### 2. legal_eval_baseline (attempt 1, 7.2 s, tokens 2677 in / 85 out, stop: stop)

**Output**

```text
כן, חוזה נכרת בדרך של הצעה וקיבול, כפי שמתואר בסעיף 1 לחוק החוזים (חלק כללי), תשל״ג–1973. הצעה היא פנייה המעידה על גמירת דעת להתקשר בחוזה, כפי שמוסבר בסעיף 2 לחוק.
```


## IL-011

### 1. legal_eval_plan (attempt 1, 11.0 s, tokens 121 in / 262 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Contract Interpretation - Completing Unspecified Terms", "law": "חוק החוזים (חלק כללי), התשכג – 1962 (Contracts (General Part) Law, 1962)", "sections": ["25", "30", "32", "34"]},
{"issue": "Good Faith in Contractual Performance", "law": "חוק החוזים (חלק כללי), התשכג – 1962 (Contracts (General Part) Law, 1962)", "sections": ["6"]},
{"issue": "Principles of Fairness and Reasonableness in Filling Contract Gaps", "law": "חוק החוזים (חלק כללי), התשכג – 1962 (Contracts (General Part) Law, 1962)", "sections": ["3"]},
  {"issue": "Custom and Usage in Contractual Interpretation", "law": "חוק החוזים (חלק כללי), התשכג – 1962 (Contracts (General Part) Law, 1962)", "sections": ["24"]}
]}
```

### 2. legal_eval_baseline (attempt 1, 7.2 s, tokens 2680 in / 84 out, stop: stop)

**Output**

```text
לא, פרטים שלא נקבעו בחוזה משלימים לפי הנוהג הקיים בין הצדדים, ובאין נוהג כזה – לפי הנוהג המקובל בחוזים מאותו סוג. הדבר מעוגן בסעיף 26 לחוק החוזים (חלק כללי), תשל״ג–1973.
```


## IL-014

### 1. legal_eval_plan (attempt 1, 9.3 s, tokens 124 in / 214 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Performance of contractual obligations when a deadline is not specified.",
"law": "חוק החוזים (חלק כללי), התשכג – 1963 (Contracts Law, General Part, 1963)",
"sections": ["48", "53"]
},
{
"issue": "Good faith in contract performance and interpretation.",
"law": "חוק החוזים (חלק כללי), התשכג – 1963 (Contracts Law, General Part, 1963)",
"sections": ["6", "12"]
},
{
"issue": "Principles of contractual interpretation to determine implied deadlines.",
"law": "חוק החוזים (חלק כללי), התשכג – 1963 (Contracts Law, General Part, 1963)",
"sections": ["25"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 7.1 s, tokens 2715 in / 80 out, stop: stop)

**Output**

```text
יש לקיים חיוב חוזי כאשר לא נקבע לו מועד, זמן סביר לאחר כריתת החוזה, במועד שעליו הודיע הנושה לחייב זמן סביר מראש. סעיף 41 לחוק החוזים (חלק כללי), תשל״ג–1973 קובע זאת.
```


## IL-061

### 1. legal_eval_plan (attempt 1, 16.4 s, tokens 128 in / 398 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Remedies for Breach of Contract",
"law": "חוק החוזים (תרופות בשל הפרת חוזה), התשל”ז-1977",
"sections": ["1", "2", "6", "7", "8", "9", "10", "11", "12"]
},
{
"issue": "General Principles of Contract Law (as background to remedies)",
"law": "חוק החוזים, התשכב’ – 1953",
"sections": ["4", "6", "14", "15", "26", "28", "30"]
},
{
"issue": "Damages Calculation (principles applicable to remedies)",
"law": "חוק הפרוצדורה האזרחית, התשכ" },{"issue": "Remedies for Breach of Contract",
"law": "חוק החוזים (תרופות בשל הפרת חוזה), התשל”ז-1977",
"sections": ["1", "2", "6", "7", "8", "9", "10", "11", "12"]
},
{
"issue": "General Principles of Contract Law (as background to remedies)",
"law": "חוק החוזים, התשכב’ – 1953",
"sections": ["4", "6", "14", "15", "26", "28", "30"]
},
{
"issue": "Damages Calculation (principles applicable to remedies)",
"law": "חוק הפרוצדורה האזרחית, התשכ"
}
]
}
```

### 2. legal_eval_baseline (attempt 1, 13.8 s, tokens 5402 in / 190 out, stop: stop)

**Output**

```text
כן, לנפגע מהפרת חוזה עומדות מספר תרופות. לפי חוק החוזים (תרופות בשל הפרת חוזה), תשל״א–1970, סעיף 2, הנפגע זכאי לתבוע אכיפת החוזה או לבטלו, וכן זכאי לפיצויים, בנוסף על אחת מהתרופות האמורות או במקומן. סעיף 10 לחוק זה קובע שהנפגע זכאי לפיצויים בעד הנזק שנגרם לו עקב ההפרה ותוצאותיה. כמו כן, סעיף 11 לחוק קובע שאם הופר חיוב ובוטל החוזה, הנפגע זכאי לפיצויים ללא הוכחת נזק.
```


## IL-062

### 1. legal_eval_plan (attempt 1, 7.0 s, tokens 124 in / 147 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "General Principles of Contract Enforcement & Defenses to Performance",
"law": "חוק החוזים (מכר) תשכ"
},
{
"issue": "Illegality of Subject Matter or Purpose of Contract",
"law": "חוק החוזים, חלק ה' - הוראות כלליות",
"sections": ["56"]
},
{
"issue": "Unforeseeable Events (Force Majeure) Excusing Performance",
"law": "חוק החוזים (תנאי שינוי נסיבות) תשכ"
}
] }
```

### 2. legal_eval_baseline (attempt 1, 11.0 s, tokens 4443 in / 138 out, stop: stop)

**Output**

```text
לא, לא תמיד תינתן אכיפה של חוזה שהופר. חוק החוזים (תרופות בשל הפרת חוזה), תשל״א–1970, סעיף 3, קובע כי הנפגע זכאי לאכיפת החוזה, זולת אם החוזה אינו בר-ביצוע, אכיפת החוזה היא כפיה לעשות עבודה אישית, ביצוע צו האכיפה דורש פיקוח בלתי סביר, או אכיפת החוזה היא בלתי צודקת בנסיבות הענין.
```


## IL-113

### 1. legal_eval_plan (attempt 1, 5.4 s, tokens 127 in / 111 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Determination of Transaction Completion in Real Estate Transactions",
"law": "חוק המקרקעין, תשי"
},
{
"issue": "Registration of Title and Transfer of Ownership",
"law": "חוק המקרקעין, תשי"
},
{
"issue": "Rights and Obligations of Parties Post-Contract Signature",
"law": "חוק המקרקעין, תשי"
}
] }
```

### 2. legal_eval_baseline (attempt 1, 9.6 s, tokens 5221 in / 87 out, stop: stop)

**Output**

```text
כן, העסקה במקרקעין נגמרת ברישום. סעיף 7(א) לחוק המקרקעין, תשכ״ט–1969 קובע שהעסקה נגמרת ברישום, ורואים את השעה שבה אישר הרשם את העסקה לרישום כשעת הרישום.
```


## IL-115

### 1. legal_eval_plan (attempt 1, 5.3 s, tokens 121 in / 106 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Validity of Contracts - General Principles of Contract Law", "law": "חוק החוזים (חלק כללי), התשל" },
{"issue": "Specific Rules Regarding Contracts Affecting Land (Real Estate)", "law": "חוק המקרקעין, התשל" },
{"issue": "Protection of Third Parties and Good Faith in Transactions", "law": "חוק המקרקעין, התשל" }
]}
```

### 2. legal_eval_baseline (attempt 1, 10.1 s, tokens 3480 in / 139 out, stop: stop)

**Output**

```text
כן, הכלל בעסקאות נוגדות במקרקעין קבוע בסעיף 9 לחוק המקרקעין, תשכ"ט-1969. סעיף זה קובע שאם אדם התחייב לעסקה במקרקעין ולפני סיום הרישום התחייב כלפי אדם אחר לעסקה נוגדת, זכותו של בעל העסקה הראשונה עדיפה. עם זאת, אם השני פעל בתום לב ובתמורה והעסקה לטובתו נרשמה, זכותו עדיפה.
```


## IL-153

### 1. legal_eval_plan (attempt 1, 9.9 s, tokens 121 in / 218 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Determination of Natural Guardianship (אפוטרופסות טבעית)",
      "law": "חוק האפוטרופסות, התשכ" },{"issue": "Order of Priority for Natural Guardianship (סדר העדיפויות לאפוטרופסות טבעית)",
      "law": "חוק האפוטרופסות, התשכ" },
    {
      "issue": "Legal Capacity and Rights of a Minor (זכויות ויכולת משפטית של קטין)",
      "law": "חוק הכשרות המשפטית, התשכ" },{"issue": "Parental Responsibilities and Obligations (אחריות וחובות הורים)",
      "law": "חוק הקמה וניהול של מוסדות להשגחה על קטינים, התשנ״א-1991"}
  ] }
```

### 2. legal_eval_baseline (attempt 1, 6.6 s, tokens 2933 in / 64 out, stop: stop)

**Output**

```text
כן, ההורים הם האפוטרופסים הטבעיים של ילדיהם הקטינים. חוק הכַּשרוּת המשפטית והאפוטרופסות, תשכ״ב–1962, סעיף 14 קובע זאת.
```


## IL-202

### 1. legal_eval_plan (attempt 1, 7.7 s, tokens 124 in / 176 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Evidentiary Admissibility - Self-Incrimination and Circumstantial Evidence", "law": "חוק הסדרים דיוניים, פקודת בית המשפט העליון [נוסח משפטי]", "sections": ["ס' 83", "ס' 85", "ס' 92"]},
{"issue": "Rules of Evidence - Circumstantial Evidence and Inference", "law": "פסיקת בית המשפט העליון (regarding interpretation of evidentiary rules)", "sections": []},
{"issue": "Criminal Procedure - Burden of Proof and Inference of Guilt", "law": "חוק סדר הדין הפלילי [זכות השיפוט העניינית]", "sections": ["ס' 116"]}
]}
```

### 2. legal_eval_baseline (attempt 1, 9.8 s, tokens 4299 in / 114 out, stop: stop)

**Output**

```text
הכלל "הדבר מעיד על עצמו" אינו מוגדר בחוק ישראלי. עם זאת, הדין מאפשר לנאשם להעיד בעצמו בבית הדין המשמעתי, והוא מטופל כמו כל עד אחר. הדבר מעוגן, למשל, בתקנות שירות המדינה (משמעת) (סדרי הדין של בית הדין), תשכ"ד–1963, סעיף 44.
```


## IL-205

### 1. legal_eval_plan (attempt 1, 8.9 s, tokens 121 in / 200 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Employer Liability for Employee Torts (Vicarious Liability)",
      "law": "חוק האחריות בנזיקין, תשי״ה-1951",
      "sections": ["44"]
    },
    {
      "issue": "Scope of Employer's Duty of Care Regarding Employee Actions",
      "law": "פקודת הנזיקין [נושאים]: סעיף 30",
      "sections": ["30"]
    },
    {
      "issue": "Potential Application of Negligence Principles in Determining Liability",
      "law": "דיני רשלנות (General Negligence Principles - not a specific statute, but foundational to the issue)",
      "sections": ["N/A - Principles derived from case law and general tort law"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 10.0 s, tokens 4333 in / 118 out, stop: stop)

**Output**

```text
כן, מעביד חב בשל עוולה של עובדו במקרים מסוימים. לפי סעיף 13(א)(1) לפקודת הנזיקין [נוסח חדש], מעביד יהיה אחראי למעשה שעשה עובדו אם הרשה או אישרר את המעשה. בנוסף, לפי סעיף 13(א)(2), מעביד יהיה אחראי אם העובד עשה את המעשה תוך כדי עבודתו.
```


## IL-245

### 1. legal_eval_plan (attempt 1, 9.1 s, tokens 132 in / 205 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Eligibility for Severance Pay (Dismissal Indemnity)",
      "law": "חוק פיצויי פיטורים, התשל”ג-1972",
      "sections": ["1", "3", "5", "11"]
    },
    {
      "issue": "Definition of 'Employee' for Severance Pay Purposes",
      "law": "חוק פיצויי פיטורים, התשל”ג-1972",
      "sections": ["1", "3"]
    },
    {
      "issue": "Exemptions from Severance Pay Obligations (e.g., certain types of employment)",
      "law": "חוק פיצויי פיטורים, התשל”ג-1972",
      "sections": ["5", "11"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 9.2 s, tokens 4259 in / 99 out, stop: stop)

**Output**

```text
כן, התנאי הבסיסי לזכאות לפיצויי פיטורים לפי חוק פיצויי פיטורים הוא שעבד שנה אחת ברציפות אצל מעסיק או במקום עבודה אחד, או עובד עונתי שתי עונות בשתי שנים רצופות. סעיף 1(א) לחוק פיצויי פיטורים, תשכ״ג–1963, קובע זאת.
```


## IL-247

### 1. legal_eval_plan (attempt 1, 8.7 s, tokens 129 in / 197 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Notice Period for Termination of Employment",
      "law": "חוק הודעה מוקדמת לחייל ופועל - The Notification of Advance Notice Law for Soldiers and Employees",
      "sections": ["1", "3", "5"]
    },
    {
      "issue": "Minimum Notice Period Based on Length of Service",
      "law": "חוק הודעה מוקדמת לחייל ופועל - The Notification of Advance Notice Law for Soldiers and Employees",
      "sections": ["3(א)"]
    },
    {
      "issue": "Compensation for Unpaid Notice Period (in lieu of notice)",
      "law": "חוק הגנת השכר - The Wage Protection Law",
      "sections": ["15", "17"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 7.6 s, tokens 3757 in / 72 out, stop: stop)

**Output**

```text
כן, אורך ההודעה המוקדמת לעובד בשכר חודשי שעבד יותר משנה הוא חודש ימים. סעיף 4(4) לחוק הודעה מוקדמת לפיטורים ולהתפטרות, התשס״א–2001 קובע זאת.
```


## IL-248

### 1. legal_eval_plan (attempt 1, 9.3 s, tokens 133 in / 211 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Notice Period for Termination of Employment",
"law": "חוק הודעה מוקדמת לחייל ופועל - P'rakodat Hod'a Mukdamet Lachayil V'Po'el",
"sections": ["5(א)","5(ב)"]
},
{
"issue": "Minimum Notice Periods Based on Length of Service",
"law": "חוק הודעה מוקדמת לחייל ופועל - P'rakodat Hod'a Mukdamet Lachayil V'Po'el",
"sections": ["5(ג)"]
},
{
"issue": "Calculation of Service Length for Notice Purposes",
"law": "חוק הודעה מוקדמת לחייל ופועל - P'rakodat Hod'a Mukdamet Lachayil V'Po'el",
"sections": ["1"]
}
] }
```

### 2. legal_eval_baseline (attempt 1, 8.8 s, tokens 4927 in / 76 out, stop: stop)

**Output**

```text
כן, במהלך ששת חודשי העבודה הראשונים, אורך ההודעה המוקדמת הוא יום אחד בשל כל חודש עבודה. סעיף 3(1) לחוק הודעה מוקדמת לפיטורים ולהתפטרות, התשס״א–2001 קובע זאת.
```


## IL-253

### 1. legal_eval_plan (attempt 1, 7.0 s, tokens 133 in / 147 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Definition of 'Payment in Advance' (שכר מולן) in the context of wage payments.",
      "law": "חוק הגנת השכר, התשע" },{"issue": "Deadlines for Wage Payment and Potential Penalties for Late Payment.",
      "law": "חוק הגנת השכר, התשע"
    },
    {
      "issue": "Legal implications of classifying a payment as 'Payment in Advance' regarding employee rights and obligations.",
      "law": "חוק הגנת השכר, התשע"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 6.9 s, tokens 3566 in / 59 out, stop: stop)

**Output**

```text
לא. לפי חוק הגנת השכר, תשי״ח-1958, סעיף 9, שכר עבודה המשתלם על בסיס של חודש ישולם עם תום החודש בעדו הוא משתלם.
```


## IL-254

### 1. legal_eval_plan (attempt 1, 6.5 s, tokens 128 in / 135 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Prohibited grounds of discrimination in employment",
      "law": "חוק שוויון הזדמנויות בעבודה, התשנ" },{"issue": "Definition of 'discrimination' and related terms",
      "law": "חוק שוויון הזדמנויות בעבודה, התשנ" },
    {
      "issue": "Exceptions and limitations to anti-discrimination provisions",
      "law": "חוק שוויון הזדמנויות בעבודה, התשנ" }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 13.3 s, tokens 4583 in / 193 out, stop: stop)

**Output**

```text
כן, חוק שוויון ההזדמנויות בעבודה אוסר על אפליה מחמת מין, נטייה מינית, מעמד אישי, הריון, טיפולי פוריות, טיפולי הפריה חוץ-גופית, היותם הורים, גיל, גזע, דת, לאומיות, ארץ מוצא, מקום מגורים, השקפה, מפלגה או שירות מילואים, של העובד, בן זוגו או הוריו. איסור זה חל על קבלה לעבודה, תנאי עבודה, קידום בעבודה, הכשרה מקצועית, פיטורים ופיצויי פיטורים. חוק שוויון ההזדמנויות בעבודה, התשמ״ח–1988, סעיף 2(א).
```


## IL-256

### 1. legal_eval_plan (attempt 1, 14.0 s, tokens 141 in / 332 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Jurisdiction of Labor Courts - Determining which court has the authority to hear employment-related disputes.",
"law": "חוק בית הדין לעבודה, התשכ\"ט-1969 (Huk Beit HaDin Le'Avoda, HaTash'chat-1969) - The Labor Court Law, 1969",
"sections": ["1", "3", "5", "10"]
},
{
"issue": "Definition of 'Labor Relations' - Defining the scope of disputes that fall under the jurisdiction of the Labor Court (i.e., what constitutes a dispute 'arising from employment relations').",
"law": "חוק בית הדין לעבודה, התשכ\"ט-1969 (Huk Beit HaDin Le'Avoda, HaTash'chat-1969) - The Labor Court Law, 1969",
"sections": ["1", "3"]
},
{
"issue": "Exclusivity of Jurisdiction - Establishing that the Labor Court has exclusive jurisdiction over certain types of disputes, preventing them from being heard in other courts.",
"law": "חוק בית הדין לעבודה, התשכ\"ט-1969 (Huk Beit HaDin Le'Avoda, HaTash'chat-1969) - The Labor Court Law, 1969",
"sections": ["10"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 9.1 s, tokens 2779 in / 127 out, stop: stop)

**Output**

```text
כן, סמכות ייחודית לדון בתובענות בין עובד למעביד הנובעות מיחסי עבודה קיימת בבית הדין האזורי לעבודה. סעיף 24(א)(1) לחוק בית הדין לעבודה, תשכ״ט–1969, קובע כי לבית דין אזורי תהא סמכות ייחודית לדון בתובענות בין עובד או חליפו למעסיק או חליפו שעילתן ביחסי עבודה.
```


## IL-293

### 1. legal_eval_plan (attempt 1, 10.6 s, tokens 127 in / 248 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Classification of Crimes by Severity under Criminal Law",
"law": "חוק העונשין, התשל\"ז-1977 (Criminal Law, 1977)",
"sections": ["13-18", "34-36", "44-46", "51-53", "57-59", "61"]
},
{
"issue": "Graded Penalties and Sentencing Guidelines",
"law": "חוק העונשין, התשל\"ז-1977 (Criminal Law, 1977)",
"sections": ["29-33", "34-36", "44-46", "51-53", "57-59", "61"]
},
{
"issue": "Definition of Criminal Offenses",
"law": "חוק העונשין, התשל\"ז-1977 (Criminal Law, 1977)",
"sections": ["1-12"]
}
] }
```

### 2. legal_eval_baseline (attempt 1, 11.9 s, tokens 4720 in / 157 out, stop: stop)

**Output**

```text
כן, חוק העונשין מבחין בין סוגי עבירות לפי חומרתן. העבירות מסווגות לשלושה סוגים: פשע, עוון וחטא. פשע הוא עבירה שנקבע לה עונש מאסר לתקופה של שלוש שנים או יותר, עוון הוא עבירה שנקבע לה עונש מאסר העולה על שלושה חודשים ושאינו עולה על שלוש שנים, וחטא הוא עבירה שנקבע לה עונש מאסר שאינו עולה על שלושה חודשים. סעיף 24 לחוק העונשין קובע את הסיווג הזה.
```


## IL-294

### 1. legal_eval_plan (attempt 1, 6.9 s, tokens 118 in / 150 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Age of Criminal Responsibility", "law": "חוק הנוער (סדר דין בעבירות), התשנ״ב-1992", "sections": ["1", "13"]},
{"issue": "Juvenile Justice System", "law": "חוק הנוער (סדר דין בעבירות), התשנ״ב-1992", "sections": ["2", "3", "4"]},
{"issue": "Legal Capacity/Ability to Understand", "law": "חוק הכשרות המשפטית, התשנ״א-1991", "sections": ["5", "6"]}
]}
```

### 2. legal_eval_baseline (attempt 1, 7.2 s, tokens 2875 in / 78 out, stop: stop)

**Output**

```text
כן, גיל האחריות הפלילית בישראל הוא שתים עשרה שנים. לפי חוק העונשין, תשל"ז-1977, סעיף 34ו, "לא יישא אדם באחריות פלילית בשל מעשה שעשה בטרם מלאו לו שתים עשרה שנים."
```


## IL-296

### 1. legal_eval_plan (attempt 1, 10.5 s, tokens 121 in / 250 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Murder (intentional killing) and the definition of 'aggravated circumstances' impacting sentencing.", "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן)", "sections": ["302", "303", "304", "305"]},
{"issue": "Sentencing guidelines and the court's discretion in determining punishment based on aggravating factors.", "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן)", "sections": ["34", "34א"]},
{"issue": "Potential application of mitigating circumstances (though the question specifically asks about *aggravated* circumstances, understanding the interplay is important).", "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן)", "sections": ["34", "34ב"]}
]}
```

### 2. legal_eval_baseline (attempt 1, 8.8 s, tokens 3671 in / 102 out, stop: stop)

**Output**

```text
כן, העונש על רצח בנסיבות מחמירות הוא מאסר עולם. סעיף 301א(א) לחוק העונשין, תשל"ז-1977, קובע כי מי שגורם בכוונה או באדישות למותו של אדם באחת מהנסיבות המפורטות בסעיף זה, דינו מאסר עולם ועונש זה בלבד.
```


## IL-297

### 1. legal_eval_plan (attempt 1, 9.6 s, tokens 117 in / 222 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Criminal Liability for Manslaughter (Causing Death Without Intent)", "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן)", "sections": ["302", "303"]},
{"issue": "Degrees of Culpability and Sentencing", "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן)", "sections": ["34", "35", "36"]},
{"issue": "Legal Definitions of 'קלות דעת' (Recklessness/Negligence) in the Context of Homicide", "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן)", "sections": ["302"]}
]}
```

### 2. legal_eval_baseline (attempt 1, 6.3 s, tokens 3108 in / 52 out, stop: stop)

**Output**

```text
לא, העונש על המתה בקלות דעת הוא מאסר שתים עשרה שנים. סעיף 301ג לחוק העונשין, תשל"ז-1977 קובע זאת.
```


## IL-300

### 1. legal_eval_plan (attempt 1, 6.8 s, tokens 125 in / 148 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Time Limit for Bringing a Detainee Before a Judge",
"law": "חוק סדר הדין הפלילי ביהודה ושומרון (חוק המעצרים)",
"sections": ["10"]
},
{
"issue": "Rights of Detainees",
"law": "חוק זכויות הנישואין",
"sections": [""]
},
{
"issue": "Procedural Fairness in Criminal Proceedings",
"law": "חוק סדר הדין הפלילי ביהודה ושומרון",
"sections": [""]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 9.2 s, tokens 5004 in / 80 out, stop: stop)

**Output**

```text
כן. לפי חוק סדר הדין הפלילי (סמכויות אכיפה – מעצרים), סעיף 29(ה), העצור יובא בפני שופט לא יאוחר מתום 32 שעות מעת מעצרו, אם צירוף השבת והחג עולה על 72 שעות.
```


## IL-353

### 1. legal_eval_plan (attempt 1, 7.3 s, tokens 132 in / 160 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Minimum Voting Age for Knesset Elections",
      "law": "חוק הבחירה לכנסת (פסקאות 1-3)",
      "sections": ["1", "2", "3"]
    },
    {
      "issue": "Minimum Age to be a Knesset Candidate",
      "law": "חוק הבחירה לכנסת (פסקאות 1-3)",
      "sections": ["3"]
    },
    {
      "issue": "Eligibility Requirements for Knesset Candidates (General)",
      "law": "חוק הכנסת",
      "sections": ["7"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 10.3 s, tokens 3434 in / 145 out, stop: stop)

**Output**

```text
כן, אזרח ישראלי זכאי לבחור לכנסת מגיל שמונה עשרה, ולי להיבחר מגיל עשרים ואחת.

לפי חוק-יסוד: הכנסת, סעיף 5, "כל אזרח ישראלי בן שמונה עשרה שנה ומעלה זכאי לבחור לכנסת".  לפי סעיף 6(א), "כל אזרח ישראלי, שביום הגשת רשימת המועמדים הכוללת את שמו הוא בן עשרים ואחת שנה ומעלה, זכאי להיבחר לכנסת".
```


## IL-016

### 1. legal_eval_plan (attempt 1, 7.3 s, tokens 154 in / 157 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Misrepresentation/Fraudulent Concealment in Contract Law (הטעיה/הסתרה במעמד כריתת חוזה)",
      "law": "חוק המכר, התשכ"
      },
    {
      "issue": "Breach of Contract/Warranty (הפרת חוזה/ערבות)",
      "law": "חוק המכר, התשכ"
      },
    {
      "issue": "Duty of Disclosure (חובת גילוי)",
      "law": "חוק החוזים (חלק כללי), התשכ"
      }
    ]
  }
```

### 2. legal_eval_baseline (attempt 1, 11.1 s, tokens 5766 in / 116 out, stop: stop)

**Output**

```text
לא. בהתבסס על העובדות שציינת, הקונה רשאי לבטל את החוזה מכוח סעיף 15 לחוק החוזים (חלק כללי), תשל״ג–1973, העוסק בהטעיה. מכיוון שהמוכר הסתיר את הרטיבות בקירות באמצעות צבע טרי ולא גילה לקונה את העובדה, מדובר בהטעיה המקנה לקונה את הזכות לבטל את החוזה.
```


## IL-024

### 1. legal_eval_plan (attempt 1, 7.1 s, tokens 148 in / 148 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Contract Cancellation Due to Misrepresentation (Mistake) and Obligation to Restitution",
      "law": "חוק החוזים (תרופות בשל הפרת חוזה), התשכ"
      },
    {
      "issue": "Unjust Enrichment (Undue Benefit)",
      "law": "חוק העשיית עושר ולא מגיע, התשכ"
      },
    {
      "issue": "Principles of Contract Law - Formation and Validity",
      "law": "חוק החוזים, התשכ"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 10.0 s, tokens 4861 in / 108 out, stop: stop)

**Output**

```text
כן. בהתאם לסעיף 21 לחוק החוזים (חלק כללי), תשל״ג–1973, משבוטל חוזה, חייב כל צד להשיב לצד השני מה שקיבל על פי החוזה. במקרה זה, בעל העסק ביטל את החוזה עקב הטעיה, ולכן עליו להשיב את 10,000 הש"ח שקיבל מהצד השני.
```


## IL-075

### 1. legal_eval_plan (attempt 1, 11.8 s, tokens 160 in / 274 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Contractual Enforcement & Specific Performance",
      "law": "חוק החוזים (חלק כללי), התשכג – 1973 (HaChok HaContractot (Hakhel Klali), HaTashchag – 1973)",
      "sections": ["48", "58", "61"]
    },
    {
      "issue": "Freedom of Contract vs. Public Interest/Reasonableness (Potential Defense)",
      "law": "חוק החוזים (חלק כללי), התשכג – 1973 (HaChok HaContractot (Hakhel Klali), HaTashchag – 1973)",
      "sections": ["34"]
    },
    {
      "issue": "Damages for Breach of Contract",
      "law": "חוק החוזים (חלק כללי), התשכג – 1973 (HaChok HaContractot (Hakhel Klali), HaTashchag – 1973)",
      "sections": ["62", "63"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 11.8 s, tokens 3870 in / 171 out, stop: stop)

**Output**

```text
לא. בית המשפט לא צפוי לאכוף את החוזה באופן אוטומטי. סעיף 3 לחוק החוזים (תרופות בשל הפרת חוזה), תשל״א–1970 קובע שהנפגע זכאי לאכיפת החוזה, זולת אם מתקיימת אחת מהנסיבות המפורטות שם, לרבות המצב בו אכיפת החוזה היא בלתי צודקת בנסיבות הענין. בנוסף, סעיף 4 לחוק החוזים (תרופות בשל הפרת חוזה), תשל״א–1970 מאפשר לבית המשפט להתנות את אכיפת החוזה בתנאים מסוימים.
```


## IL-126

### 1. legal_eval_plan (attempt 1, 6.6 s, tokens 154 in / 136 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Statute of Frauds - Requirement of Written Agreements for Land Transactions",
      "law": "חוק המקרקעין, תשי"
      },
      {
        "issue": "Oral Agreements and Estoppel (Potential for Reliance)",
        "law": "חוק המקרקעין, תשי"
      },
      {
        "issue": "Proof of Payment and Preliminary Payment ( מקדמה )",
        "law": "חוק המקרקעין, תשי"
      }
    ]
  }
```

### 2. legal_eval_baseline (attempt 1, 8.2 s, tokens 4274 in / 72 out, stop: stop)

**Output**

```text
לא. לפי חוק המקרקעין, התחייבות לעסקה במקרקעין טעונה מסמך בכתב (חוק המקרקעין, סעיף 8). העובדה שהקונה שילם מקדמה אינה משנה את הדרישה לכתב.
```


## IL-164

### 1. legal_eval_plan (attempt 1, 11.4 s, tokens 147 in / 252 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Minority Contractual Capacity & Voidability",
      "law": "חוק הכשרות המשפטית של אנשים עם מוגבלויות, תשנ" },{"issue": "Parental Responsibility for Minors' Contracts",
      "law": "פקודת הבוגדים, תשי\"ז-1957"
    },
    {
      "issue": "Right of Rescission/Cancellation of Contract due to Lack of Capacity",
      "law": "חוק החוזים (חלק כללי), תשל" },{"issue": "Consumer Protection in Contractual Agreements",
      "law": "חוק הגנת הצרכן, תשנ" },{"issue": "Potential for Civil Liability of the Seller",
      "law": "פקודת הנזיקין, תשל" },{"issue": "Possible Claims of Unjust Enrichment",
      "law": "חוק העשיית עושר ולא מגיע, תשכ\"ד-1964"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 12.3 s, tokens 4661 in / 168 out, stop: stop)

**Output**

```text
לא. נער בן 16 אינו כשיר לבצע עסקאות משפטיות באופן עצמאי. לפי חוק הכשרות המשפטית והאפוטרופסות, תשכ"ב-1962, סעיף 26, הורה שאינו מסוגל למלא את חובותיו בנוגע לרכושו של ילדו הקטין, או מזניח חובות אלה, רשאי בית המשפט להורות שיחולו עליו ההוראות החלות על אפוטרופסות. במקרה זה, ההורים אינם יכולים לבטל את העסקה באופן חד-צדדי, אך ניתן לפנות לבית המשפט כדי לקבל סיוע משפטי.
```


## IL-168

### 1. legal_eval_plan (attempt 1, 7.3 s, tokens 137 in / 157 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Eligibility to inherit despite a criminal conviction, specifically for a crime against a family member.",
"law": "חוק המירוש (חוק עוולות משפחה), תשכ" },{"issue": "The effect of a conviction on the right to inherit, considering public policy and moral considerations.",
"law": "חוק המירוש (חוק עוולות משפחה), תשכ" },
{
"issue": "Potential application of provisions related to disinheritance or limitations on inheritance due to egregious acts.",
"law": "חוק המירוש (חוק עוולות משפחה), תשכ" }
]}
```

### 2. legal_eval_baseline (attempt 1, 8.6 s, tokens 4680 in / 76 out, stop: stop)

**Output**

```text
לא. אדם שהורשע ברצח אביו פסול לרשת את אביו. סעיף 5(א)(1) לחוק הירושה, תשכ״ה–1965 קובע כי מי שגרם, במתכוון או באדישות, למותו של המוריש פסול לרשת.
```


## IL-172

### 1. legal_eval_plan (attempt 1, 8.8 s, tokens 137 in / 190 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Custody and Parental Decision-Making Authority",
      "law": "חוק השיפוט העליון בתובענות בעניני משפחה, תשכ" },{"issue": "Child's Best Interests",
      "law": "חוק הסכסוך בין הורים לבין ילדיהם, תשנ״ח-1998"
    },
    {
      "issue": "Enforcement of Court Orders Regarding Custody",
      "law": "פקודת בתי משפט (ענייני משפחה), תשכ" },{"issue": "Legal Representation for Children",
      "law": "חוק זכויות הילד, תשנ״ב-1992"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 7.6 s, tokens 3502 in / 77 out, stop: stop)

**Output**

```text
לא. ההורים אינם רשאים להחליט לבדם. סעיף 19 לחוק הכשרות המשפטית והאפוטרופסות קובע שאם ההורים לא הגיעו להסכמה בעניין הנוגע לקטין, רשאים לפנות לבית המשפט שיכריע בדבר.
```


## IL-212

### 1. legal_eval_plan (attempt 1, 6.9 s, tokens 169 in / 146 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Liability under the Victims of Road Accidents Compensation Law – apportionment of blame/reduction of compensation.",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      },
    {
      "issue": "Negligence of the driver and its impact on liability.",
      "law": "פקודת תעבורה, תשכ"
      },
    {
      "issue": "Determination of fault and contributory negligence in traffic accidents.",
      "law": "חוק הראיות, תשכ"
      }
    ]
  }
```

### 2. legal_eval_baseline (attempt 1, 12.1 s, tokens 4131 in / 172 out, stop: stop)

**Output**

```text
לא. חוק הפיצויים לנפגעי תאונות דרכים קובע כי הפיצויים ישולמו ללא קשר לאשמת ההולך. עם זאת, אם הוכח שההולך גרם לתאונה במתכוון, הוא לא יהיה זכאי לפיצויים (סעיף 7(1) לחוק). במקרה זה, ההולך חצה באדום, ולכן ייתכן שיש לראות בכך אשמה, אך אין זה אומר בהכרח שהפיצויים יופחתו באופן אוטומטי. בית המשפט רשאי לקחת את האשמה בחשבון, אך לא בהכרח יפחית את הפיצויים.
```


## IL-213

### 1. legal_eval_plan (attempt 1, 7.9 s, tokens 159 in / 173 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Fraudulent Claim / Bad Faith (מרמה / רעה רוח)",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      },
    {
      "issue": "Causation and Intent (סיבתיות וכוונה)",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      },
    {
      "issue": "Definition of 'Accident' (הגדרת 'תאונה')",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      }
    ]
  }
```

### 2. legal_eval_baseline (attempt 1, 10.4 s, tokens 5620 in / 101 out, stop: stop)

**Output**

```text
לא. לפי חוק פיצויים לנפגעי תאונות דרכים, מאורע שאירע כתוצאה ממעשה שנעשה במתכוון כדי לגרום נזק לגופו או לרכושו של אותו אדם, לא יראו כתאונת דרכים. סעיף 7 לחוק קובע כי מי שגרם לתאונה במתכוון אינו זכאי לפיצויים.
```


## IL-214

### 1. legal_eval_plan (attempt 1, 6.9 s, tokens 144 in / 143 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Employer Liability for Employee Actions (Vicarious Liability)",
      "law": "חוק האחריות הסטטוטורית, התשל"
      },
    {
      "issue": "Scope of Employment (Whether the employee was acting within the scope of employment)",
      "law": "פקודת הנזיקין, התשל"
      },
    {
      "issue": "Negligence and Duty of Care (Potential negligence of the employee and the company)",
      "law": "פקודת הנזיקין, התשל"
    }
  ] }
```

### 2. legal_eval_baseline (attempt 1, 9.0 s, tokens 4016 in / 99 out, stop: stop)

**Output**

```text
לא. החברה עשויה לחוב כמעביד אם העובד פגע ברכב אחר במהלך נסיעה שבוצעה במסגרת עבודתו. סעיף 13(א)(2) לפקודת הנזיקין [נוסח חדש] קובע כי מעביד חב על מעשה שעשה עובד שלו אם העובד עשה את המעשה תוך כדי עבודתו.
```


## IL-217

### 1. legal_eval_plan (attempt 1, 7.5 s, tokens 141 in / 159 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Determination of Damages in Defamation Claims (Whether compensation can be awarded without proof of financial damages)",
      "law": "חוק איסור לשון הרע, תשכ" },{"issue": "The concept of 'moral damages' (נזק מוסרי) in the context of defamation, and whether it can be awarded even without financial loss.",
      "law": "חוק איסור לשון הרע, תשכ" },
    {
      "issue": "The burden of proof regarding damages in defamation cases.",
      "law": "חוק איסור לשון הרע, תשכ" }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 9.1 s, tokens 4272 in / 96 out, stop: stop)

**Output**

```text
לא. לפי חוק איסור לשון הרע, התשכ"ה-1965, סעיף 7א(ב), במשפט בשל עוולה אזרחית לפי החוק, רשאי בית המשפט לחייב את הנתבע לשלם לנפגע פיצוי שלא יעלה על 50,000 שקלים חדשים, ללא הוכחת נזק.
```


## IL-219

### 1. legal_eval_plan (attempt 1, 11.3 s, tokens 160 in / 249 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Statute of Limitations (Prescription) and Acknowledgement of Debt",
      "law": "חוק ההתיישנות, תשכ" },{"issue": "חוק הפסיקתא, תשכ","law": "חוק הפסיקתא, תשכ"
    },
    {
      "issue": "Contract Law - Offer and Acceptance/Request for Payment Plan",
      "law": "חוק החוזים (חלק כללי), תשל" },{"issue": "חוק החוזים (חלק כללי), תשל","law": "חוק החוזים (חלק כללי), תשל"
    },
    {
      "issue": "Written Acknowledgement of Debt and its Legal Effect",
      "law": "חוק הסדר דין האזרחי, תשכ" },{"issue": "חוק הסדר דין האזרחי, תשכ","law": "חוק הסדר דין האזרחי, תשכ"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 9.8 s, tokens 3462 in / 129 out, stop: stop)

**Output**

```text
לא. הודאה בחוב בכתב, כפי שצוין במכתב מ-2021, מאפסת את תקופת ההתיישנות ומתחילה תקופה חדשה. סעיף 9 לחוק ההתיישנות, תשי״ח–1958 קובע כי "הודה הנתבע, בכתב או בפני בית משפט, בין בתוך תקופת ההתיישנות ובין לאחריה, בקיום זכות התובע, תתחיל תקופת ההתיישנות מיום ההודאה".
```


## IL-262

### 1. legal_eval_plan (attempt 1, 6.0 s, tokens 150 in / 127 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Overtime Compensation",
"law": "חוק שעות עבודה ומנוחה",
"sections": ["34", "36"]
},
{
"issue": "Definition of 'Regular Working Hours'",
"law": "חוק שעות עבודה ומנוחה",
"sections": ["3"]
},
{
"issue": "Calculation of Overtime Pay Rate",
"law": "חוק שעות עבודה ומנוחה",
"sections": ["36"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 10.5 s, tokens 5023 in / 112 out, stop: stop)

**Output**

```text
לא. לפי חוק שעות עבודה ומנוחה, תשי"א-1951, סעיף 16(א), העובד זכאי לגמול של 1.25 על שתי השעות הנוספות הראשונות, ו-1.5 על כל שעה נוספת מעבר לכך. העובד עבד 3 שעות נוספות, ולכן הוא זכאי לגמול של 1.25 על כל 3 השעות הנוספות.
```


## IL-306

### 1. legal_eval_plan (attempt 1, 8.5 s, tokens 134 in / 187 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Age of Criminal Responsibility",
"law": "חוק הנוער (סדר דין מעצרים) תשנ״ב-1992",
"sections": ["11", "12", "13"]
},
{
"issue": "Juvenile Justice System - Procedures and Alternatives to Criminal Prosecution",
"law": "חוק הסדרים מנהליים בתיק פלילי, תשע״א-2011",
"sections": ["3", "5", "7"]
},
{
"issue": "Theft as a Criminal Offense",
"law": "חוק העבירות נגד הקנין, תשל״ז-1977",
"sections": ["32", "38"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 10.3 s, tokens 4208 in / 128 out, stop: stop)

**Output**

```text
לא. על פי חוק העונשין, תשל"ז-1977, סעיף 383(א), אדם גונב דבר אם הוא נוטל אותו במרמה ובלי תביעת זכות בתום לב, כשהוא מתכוון לשלול את הדבר מבעלו. עם זאת, על פי החוק הפלילי הירדני, חוק מס' 16 לשנת 1960, סעיף 94, לא יישפט בפלילים מי שלא השלים את גיל 12.
```


## IL-309

### 1. legal_eval_plan (attempt 1, 9.0 s, tokens 152 in / 204 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Self-Defense (הגנה עצמית)",
      "law": "חוק ההגנה העצמית (Huk ha-Hagana ha-Atzmit)",
      "sections": ["5", "6", "7"]
    },
    {
      "issue": "Use of Force Necessary to Repel Attack (שימוש בכוח סביר להדוף התקפה)",
      "law": "חוק ההגנה העצמית (Huk ha-Hagana ha-Atzmit)",
      "sections": ["4", "5"]
    },
    {
      "issue": "Necessity/Duress (הצורך/הכרח)",
      "law": "חוק העונשין (Huk ha-Ounshin)",
      "sections": ["33"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 11.1 s, tokens 4371 in / 142 out, stop: stop)

**Output**

```text
כן. בהתחשב בעובדות שתוארו, ייתכן שאדם יצליח לטעון להגנה עצמית. סעיף 34י לחוק העונשין, תשל"ז-1977, קובע שאדם אינו אחראי פלילית למעשה שנחוץ להדוף תקיפה שלא כדין, המציגה סכנה מוחשית לפגיעה בחייו. דחיפה של תוקף הנושא סכין, במטרה להציל את חייו, עשויה להיחשב כמעשה הדרוש להגנה עצמית.
```


## IL-368

### 1. legal_eval_plan (attempt 1, 8.3 s, tokens 149 in / 184 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Eligibility to Vote and Voter Registration/Relocation",
      "law": "חוק הבחירות לכנסת",
      "sections": ["סעיפים 51, 52, 53, 54, 55, 56"]
    },
    {
      "issue": "Special Provisions for Displaced Voters (due to security situation)",
      "law": "חוק הבחירות לכנסת",
      "sections": ["סעיף 56א"]
    },
    {
      "issue": "Voter Identification and Verification",
      "law": "חוק הבחירות לכנסת",
      "sections": ["סעיפים 61, 62"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 7.0 s, tokens 2267 in / 84 out, stop: stop)

**Output**

```text
לא. בוחר שהתפנה מביתו עקב המצב הביטחוני רשאי להצביע בקלפי ייעודית למפונים או בכל קלפי שנקבעה כקלפי להצבעת אנשים המוגבלים בניידות. חוק הבחירות לכנסת, סעיף 116יז10(ב).
```


## IL-409

### 1. legal_eval_plan (attempt 1, 13.1 s, tokens 149 in / 314 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Derivative Actions (תביעה ייצוגית) - Whether a shareholder has standing to bring a lawsuit on behalf of a company against a director.",
      "law": "חוק תביעה ייצוגית, התשכ\"ט-1968 (Huk Tavia Yetzugit, Tish'at-1968)",
      "sections": ["14", "15", "16"]
    },
    {
      "issue": "Director's Liability (אחריות דירקטור) - The potential liability of a director for damages caused to the company.",
      "law": "חוק השליחות, התשכ\"ז-1967 (Huk HaShlucht, Tish'az-1967)",
      "sections": ["3", "6", "9"]
    },
    {
      "issue": "Corporate Governance (ניהול תאגידי) - The procedures and rules governing the management and operation of a company, including the role of the board of directors.",
      "law": "חוק החברות, התשע\"ב-2012 (Huk HaHeverot, Tish'bet-2012)",
      "sections": ["163", "165", "167"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 10.0 s, tokens 4282 in / 118 out, stop: stop)

**Output**

```text
לא. בעל מניות אינו יכול להגיש תביעה בשם החברה נגד דירקטור ללא אישור בית המשפט. על פי חוק החברות, התשנ״ט–1999, סעיף 194(א), כל בעל מניה וכל דירקטור רשאים להגיש תביעה נגזרת, אך קודם לכן עליו לפנות לחברה ולדרוש ממנה למצות את זכויותיה באמצעות הגשת תביעה.
```


## IL-410

### 1. legal_eval_plan (attempt 1, 6.0 s, tokens 162 in / 119 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Legality of Dividend Distribution Despite Accumulated Losses and Insolvency Risk",
      "law": "חוק החברות, התשע" },{"issue": "Fiduciary Duties of Company Directors",
      "law": "חוק החברות, התשע"
    },
    {
      "issue": "Potential for Director Liability for Improper Actions",
      "law": "חוק החברות, התשע"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 10.0 s, tokens 4281 in / 119 out, stop: stop)

**Output**

```text
לא. חלוקת דיבידנד לחברה בעלת הפסדים צבורים וחשש שלא תוכל לעמוד בתשלומי חובותיה אינה מותרת, אלא אם כן יתקבל אישור בית משפט. סעיף 302 לחוק החברות קובע כי חברה רשאית לבצע חלוקה מתוך רווחיה ובלבד שלא קיים חשש סביר שהחלוקה תמנע ממנה את היכולת לעמוד בחבויותיה.
```


## IL-032

### 1. legal_eval_plan (attempt 1, 11.1 s, tokens 186 in / 249 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Contract Interpretation - Determining the 'Custom of the Industry' (המקובל בענף)",
      "law": "חוק החוזים (תום לב והגינות) - The Contract Law (Good Faith and Fair Dealing) Law, 1973",
      "sections": [
        "סעיף 2",
        "סעיף 6"
      ]
    },
    {
      "issue": "Contract Interpretation - Ambiguity and Evidence (ראיות)",
      "law": "חוק הפרוצדורה האזרחית, תשכ"
      },
      {
      "issue": "Contract Interpretation - Good Faith and Fair Dealing (תום לב והגינות)",
      "law": "חוק החוזים (תום לב והגינות) - The Contract Law (Good Faith and Fair Dealing) Law, 1973",
      "sections": [
        "סעיף 2",
        "סעיף 6"
      ]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 24.4 s, tokens 4149 in / 472 out, stop: stop)

**Output**

```text
כן, הפער בין 30% ל-10% יוכרע על ידי בית המשפט.

**סוגיה:** יזם ומשקיע חתמו על הסכם שבו נקבע שהמשקיע יקבל את חלקו ברווחים לפי המקובל בענף. המשקיע טוען ל-30% והיזם ל-10%. אין הוראה נוספת בחוזה. כיצד יוכרע הפער?

**כלל (חוק וסעיף):** חוק החוזים (חלק כללי), סעיף 25(ב1) קובע שאם לחוזה ישנם פירושים שונים, והיתה לאחד הצדדים עדיפות בעיצוב תנאיו, פירוש נגדו עדיף על פירוש לטובתו. בנוסף, סעיף 6 לחוק המכר וסעיף 39 לחוק החוזים (חלק כללי) מחייבים קיום חוזה בדרך של תום לב.

**יישום על העובדות:** במקרה זה, המשקיע טוען לשיעור רווח גבוה יותר מהיזם, וייתכן שהמשקיע השקיע מאמץ רב יותר בעיצוב תנאי ההסכם. בהתאם לסעיף 25(ב1) לחוק החוזים (חלק כללי), פירוש לטובת המשקיע, כלומר שיעור הרווח הגבוה יותר, עשוי להימצא עדיף. כמו כן, בית המשפט יבחן את ההתנהלות של הצדדים וידאג שהחוזה יתקיים בדרך של תום לב.

**מסקנה:** מאחר שהחוזה אינו מבהיר את שיעור הרווח, וקיימים פירושים שונים, הפער יוכרע על ידי בית המשפט, אשר יבחן את הנסיבות, את מאמצי הצדדים בעיצוב החוזה, ואת עקרון תום הלב.
```


## IL-087

### 1. legal_eval_plan (attempt 1, 9.5 s, tokens 197 in / 213 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Breach of Contract (Failure to Perform)",
      "law": "חוק החוזים (תרופות בשל הפרת חוזה), תשל״ג-1973",
      "sections": ["4", "6", "13"]
    },
    {
      "issue": "Damages - Compensatory Damages (specifically, reliance damages and consequential damages)",
      "law": "חוק הנזיקין, תשי״ב-1952",
      "sections": ["212", "213", "219"]
    },
    {
      "issue": "Damages - Non-Pecuniary Damages (Pain and Suffering/Distress)",
      "law": "חוק הנזיקין, תשי״ב-1952",
      "sections": ["225"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 25.0 s, tokens 3806 in / 499 out, stop: stop)

**Output**

```text
כן, בני הזוג יוכלו לתבוע פיצויים.

**סוגיה:** מה הפיצויים שמגיעים לבני זוג אשר הזמינו אולם לחתונה, והאולם ביטל את ההזמנה שבועיים לפני האירוע?

**כלל:**
*   חוק החוזים (תרופות בשל הפרת חוזה), תשל״א–1970, סעיף 2 קובע כי הנפגע מהפרת חוזה זכאי לפיצויים בנוסף לאכיפת החוזה או ביטולו.
*   חוק החוזים (תרופות בשל הפרת חוזה), תשל״א–1970, סעיף 13 מאפשר לבית המשפט לפסוק פיצויים בעד נזק שאינו של ממון בשיעור שייראה לו בנסיבות העניין.
*   חוק החזר מקדמה בשל ביטול אירוע (נגיף הקורונה החדש), התשפ״א–2020, סעיף 3(א) מאפשר לתבוע פיצויים לדוגמה שלא יעלו על 10,000 ש"ח במידה והמפעיל לא החזיר את המקדמה בתוך חודש.

**יישום על העובדות:** האולם הפר חוזה עם בני הזוג, וגרם להם נזק שאינו של ממון, בדמות עוגמת נפש. בנוסף, הם נאלצו לשלם יותר עבור אולם חלופי. ניתן לתבוע פיצויים בגין הנזק שנגרם להם, כולל עוגמת הנפש וההפרש בעלות האולם החלופי.

**מסקנה:** בני הזוג יוכלו לתבוע פיצויים בגין הפרת החוזה, כולל פיצוי בגין עוגמת הנפש וההפרש בעלות האולם החלופי, וכן פיצוי לדוגמה שלא יעלה על 10,000 ש"ח בהתאם לחוק החזר מקדמה בשל ביטול אירוע.
```


## IL-135

### 1. legal_eval_plan (attempt 1, 10.7 s, tokens 169 in / 245 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Validity of Contractual Clauses Limiting Landlord's Responsibilities",
"law": "חוק השכירות והשאילה (בטחונות) תשכ\"ב-1972 (Huk haShekirah veHaShe'ila (Bituhonot) Tashkach-1972)",
"sections": ["16", "18"]
},
{
"issue": "Unconscionability of Contractual Terms",
"law": "חוק החוזים (חלק כללי) תשכג-1973 (Huk haChuzim (Hakhel Klali) Tashkach-1973)",
"sections": ["13"]
},
{
"issue": "Consumer Protection in Rental Agreements (potentially, depending on the tenant's status)",
"law": "חוק הגנת הצרכן תשנ\"א-1991 (Huk Haganat haTzarkhan Tashna-1991)",
"sections": ["8", "13"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 21.5 s, tokens 3838 in / 414 out, stop: stop)

**Output**

```text
לא. סעיף שכזה, המחייב את השוכר לשאת בכל תיקון בדירה מכל סיבה, אינו תקף.

**סוגיה:** האם סעיף בחוזה שכירות המחייב את השוכר לשאת בכל תיקונים בדירה, כולל מערכות מים וחשמל, תקף?

**כלל (חוק וסעיף):** חוק השכירות והשאילה, תשכ"א-1971, סעיף 25ט(ב)(1) קובע שהשוכר יישא בתשלומים שוטפים, כולל מים וחשמל. עם זאת, סעיף 25ט(ב)(2) קובע שהשוכר אינו נושא במישרין בתשלומים לרכישה או השבחה של מערכות קבועות, וסעיף 25ח(א) קובע שהשוכר אחראי על ליקויים בדירה, אך סעיף 7 קובע שהמשכיר חייב לתקן פגמים הגורמים להפרעה לשימוש במושכר.

**יישום על העובדות:** הסעיף בחוזה המטיל על השוכר את כל התיקונים, כולל מערכות מים וחשמל, מנוגד להוראות חוק השכירות והשאילה. סעיף 25ט(ב)(2) שולל חיוב השוכר בתשלומים לרכישה או השבחה של מערכות קבועות, וסעיף 7 מחייב את המשכיר לתקן פגמים המשפיעים על השימוש במושכר.

**מסקנה:** הסעיף בחוזה אינו תקף, והשוכר אינו מחויב לשאת בכל התיקונים בדירה.
```


## IL-136

### 1. legal_eval_plan (attempt 1, 6.5 s, tokens 171 in / 134 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Validity of the Transfer of Ownership due to Forged Power of Attorney",
      "law": "חוק המקרקעין, תשי"
      },
      {
        "issue": "Liability of the Seller for Fraudulent Actions",
        "law": "חוק המקרקעין, תשי"
      },
      {
        "issue": "Potential Claims Against the Forger of the Power of Attorney",
        "law": "חוק העונשין, תשל"
      }
    ]
  }
```

### 2. legal_eval_baseline (attempt 1, 21.3 s, tokens 4845 in / 387 out, stop: stop)

**Output**

```text
כן.

**סוגיה:** חברה רכשה מגרש בהסתמך על רישום בפנקסי המקרקעין, אך התברר שהמוכר זייף ייפוי כוח. יש לנתח את מעמדה המשפטי של החברה.

**כלל:**
*   **חוק המקרקעין, סעיף 10:** קונה זכות במקרקעין בתמורה ובהסתמך בתום לב על הרישום, זכותו יפה אף אם הרישום לא היה נכון.
*   **פקודת הסדר זכויות במקרקעין [נוסח חדש], סעיף 93:** בית משפט רשאי להורות על תיקון פנקס במקרה של מרמה ברישום, אך לא אם הקונה רכש את המקרקעין בתום לב ובתמורה.

**יישום על העובדות:** החברה רכשה את המגרש בתמורה ובהסתמך על רישום בפנקסי המקרקעין, ולכן היא קונה בתום לב. העובדה שהמוכר זייף ייפוי כוח מהווה מרמה ברישום.

**מסקנה:** בהתאם לחוק המקרקעין, סעיף 10, זכותה של החברה במגרש תהיה יפה, למרות הרישום השגוי. בית המשפט לא יורה על תיקון הפנקס, בהתאם לפקודת הסדר זכויות במקרקעין, סעיף 93, מאחר והחברה רכשה את המקרקעין בתום לב ובתמורה.
```


## IL-223

### 1. legal_eval_plan (attempt 1, 6.3 s, tokens 193 in / 120 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Defamation (specifically, false statements damaging reputation)",
      "law": "חוק איסור לשון הרע, תשכ" },{"issue": "Potential breach of confidentiality/non-disclosure obligations (depending on the employment contract)",
      "law": "חוק חוזה העבודה, תש" },{"issue": "Possible tort liability for false statements impacting business operations",
      "law": "חוק הנזיקין, תשי" }]}
```

### 2. legal_eval_baseline (attempt 1, 22.1 s, tokens 4200 in / 418 out, stop: stop)

**Output**

```text
כן. ניתוח העובדות והדין מעלה כי העובדת לשעבר עלולה להיות חשופה לתביעה בגין לשון הרע.

**סוגיה:** האם פרסום הפוסט בפייסבוק על ידי העובדת לשעבר מהווה לשון הרע, ומהן ההשלכות המשפטיות?

**כלל (חוק וסעיף):** חוק איסור לשון הרע, תשכ״ה–1965, סעיף 1 מגדיר לשון הרע כדבר שפרסומו עלול לבזות אדם, בין היתר, בשל מעשים המיוחסים לו. סעיף 2 קובע כי פרסום כולל בין היתר פוסט ברשת חברתית. סעיף 6 קובע כי המפרסם לשון הרע בכוונה לפגוע, דינו מאסר שנה אחת.

**יישום על העובדות:** הפוסט שפרסמה העובדת לשעבר כלל טענות על התעללות ואי-תשלום שכר. הטענה על התעללות אינה נכונה, אך הטענה על אי-תשלום שכר נכונה ומתועדת. גם אם חלק מהטענות נכונות, פרסום טענה שקרית עלולה להיחשב לשון הרע.

**מסקנה:** בעל העסק יכול לתבוע את העובדת לשעבר בגין לשון הרע. עם זאת, ייתכן שהעובדת תוכל לטעון להגנה על פי חוק איסור לשון הרע, תשכ״ה–1965, סעיף 19, בטענה שהייתה משוכנעת באמיתות הטענות (גם אם חלקן שקריות).
```


## IL-267

### 1. legal_eval_plan (attempt 1, 9.6 s, tokens 197 in / 216 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Unlawful Dismissal/Termination of Employment - Lack of Notice",
        "law": "חוק הודעה מוקדמת לפיטורין ופירוק העסקה - *Huk Hod'a Mukdamet Lifitorin u'Piruk Ha'Asaka*",
        "sections": ["1", "5", "7", "9"]
    },
    {
        "issue": "Unpaid Wages - Right to Immediate Payment",
        "law": "חוק תשלום שכר - *Huk T'shlum S'char*",
        "sections": ["10", "12"]
    },
    {
        "issue": "Potential for Unlawful Verbal Termination (Lack of Written Notice/Reason)",
        "law": "חוק עבודת נשים - *Huk Avodat Nashim*",
        "sections": ["16"]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 15.5 s, tokens 3821 in / 267 out, stop: stop)

**Output**

```text
לא. רונית זכאית לפיצוי בגין אי מתן הודעה מוקדמת לפיטורים. סעיף 7 לחוק הודעה מוקדמת לפיטורים ולהתפטרות, התשס״א–2001 קובע את תקופת ההודעה המוקדמת הנדרשת, ובמקרה של רונית, בהיותה עובדת מעל שלוש שנים, היא זכאית לחודש הודעה מוקדמת. העובדה שהמעסיק פיטר אותה בעל פה ללא הודעה מוקדמת, וכן אי תשלום השכר של אוגוסט, מהווים הפרה של החוק. רונית זכאית לפיצוי השווה לשכרה הרגיל בעד התקופה שלגביה לא ניתנה ההודעה המוקדמת, כלומר, 9,000 ש"ח לחודש. בנוסף, המעסיק עלול לעמוד לדין לפי חוק הגנת השכר, תשי״ח–1958, סעיף 25ב(ב1), בגין אי תשלום השכר.
```


## IL-268

### 1. legal_eval_plan (attempt 1, 7.2 s, tokens 172 in / 154 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Unlawful Dismissal/Termination of Employment - Potential Violation of Worker's Rights during Pregnancy",
      "law": "חוק עבודת נשים, תשנ"
      },
    {
      "issue": "Duress/Coercion in Signing a Resignation Letter",
      "law": "חוק החוזים (חלק כללי), התשכג – 1973"
      },
    {
      "issue": "Severance Pay and Entitlements upon Termination",
      "law": "חוק פיצויי עבודה, התשכ"
    }
  ] }
```

### 2. legal_eval_baseline (attempt 1, 10.5 s, tokens 4974 in / 117 out, stop: stop)

**Output**

```text
כן. דנה עובדת בחברה מעל חצי שנה, ולכן פיטוריה בשל הריונה דורשים היתר משר העבודה והרווחה לפי סעיף 9(א) לחוק עבודת נשים. המנהל לא קיבל היתר כזה, ולכן הפיטורים אינם חוקיים. המעסיק לא יכול לפטר עובדת בהריון אלא בהיתר, והפיטורים כאלה נחשבים כקשורים להריון.
```


## IL-269

### 1. legal_eval_plan (attempt 1, 9.8 s, tokens 152 in / 221 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Working Hours and Overtime Compensation",
      "law": "חוק שעות עבודה ומנוחה (Hours of Work and Rest Law) - פְּקֻדַּת שעות עבודה ומנוחה",
      "sections": ["3", "11", "15"]
    },
    {
      "issue": "Minimum Wage",
      "law": "חוקי שכר מינימום (Minimum Wage Laws) - חֲדָסוֹת שכר מינימום",
      "sections": ["1", "4"]
    },
    {
      "issue": "Rest Days and Paid Leave",
      "law": "חוק שעות עבודה ומנוחה (Hours of Work and Rest Law) - פְּקֻדַּת שעות עבודה ומנוחה",
      "sections": ["25", "32"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 21.3 s, tokens 4243 in / 400 out, stop: stop)

**Output**

```text
כן, לעובד זכויות שכר נוספות.

**סוגיה:** עובד עבד במשך שנה 12 שעות ביום, 6 ימים בשבוע, וקיבל שכר שעתי רגיל על כל השעות. מה זכויותיו?

**כלל (חוק וסעיף):** לפי חוק שעות עבודה ומנוחה, תשי"א-1951, סעיף 16(א), עובד שמועסק שעות נוספות זכאי לתשלום בעד שתי השעות הנוספות הראשונות שבאותו יום שכר עבודה לא פחות מ-1.25 משכרו הרגיל, ובעד כל שעה נוספת שאחריהן לא פחות מ-1.5 משכרו הרגיל. כמו כן, לפי חוק שעות עבודה ומנוחה, תשי"א-1951, סעיף 17(א)(1), אם הועסק עובד בשעות המנוחה השבועית, ישלם לו המעסיק בעד שעות אלה שכר עבודה לא פחות מ-1.5 משכרו הרגיל.

**יישום על העובדות:** העובד עבד 12 שעות ביום, 6 ימים בשבוע, ולכן עבד שעות נוספות מעבר לשעות העבודה הרגילות. בנוסף, ייתכן שעבד גם בשעות המנוחה השבועית.

**מסקנה:** העובד זכאי לקבל תשלום עבור שעות נוספות, לפי הכללים שצוינו בחוק שעות עבודה ומנוחה, וכן תשלום עבור שעות עבודה במנוחה השבועית, אם עבד בהן.
```


## IL-317

### 1. legal_eval_plan (attempt 1, 14.7 s, tokens 169 in / 336 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Homicide - Specifically, whether the act constitutes Murder (רצח) or Manslaughter (הריגה) under Israeli law, considering Yossi's claim of intent to only intimidate.",
      "law": "חוק העונשין, התשל\"ז-1977 (Mishpat Ha'Onashin, Tish'atz-1977)",
      "sections": ["7 (Murder)", "8 (Manslaughter)"]
    },
    {
      "issue": "Aggravated Assault - Even if not considered homicide, the use of a knife and the resulting injury could constitute Aggravated Assault (תקיפה הגורמת חבלה)",
      "law": "חוק העונשין, התשל\"ז-1977 (Mishpat Ha'Onashin, Tish'atz-1977)",
      "sections": ["36 (Assault and Battery)", "37 (Aggravated Assault)"]
    },
    {
      "issue": "Possession of a Weapon - The act of pulling out a knife, regardless of the ultimate intent, raises the issue of illegal weapon possession (החזקת נשק שלא כדין).",
      "law": "פקודת הנשק, התשכ"
      														}
      														]
    }
```

### 2. legal_eval_baseline (attempt 1, 23.3 s, tokens 2282 in / 488 out, stop: stop)

**Output**

```text
כן, יוסי עשוי להיות מואשם בעבירות שונות, בהתאם לנסיבות המקרה ולכוונתו.

**סוגיה:** ניתוח העבירות האפשריות לאחר רפורמת ההמתה, בהתחשב בטענתו של יוסי שרצה רק להפחיד.

**כלל (חוק וסעיף):**

*   **סעיף 300 לחוק העונשין, תשל"ז-1977:** הגורם בכוונה או באדישות למותו של אדם, דינו מאסר עולם.
*   **סעיף 378 לחוק העונשין, תשל"ז-1977:** המכה אדם... בלא הסכמתו... הרי זו תקיפה.
*   **סעיף 379 לחוק העונשין, תשל"ז-1977:** התוקף שלא כדין את חברו, דינו – מאסר שנתיים.

**יישום על העובדות:** יוסי שלף סכין והכה את יריבו בחזה, מה שהוביל למותו. גם אם טענתו היא שרצה רק להפחיד, העובדה שהיריב מת מעלה שאלות לגבי כוונתו או לפחות אדישותו לתוצאה. אם יוכח שהכה את היריב בכוונה לגרום לו מוות או באדישות למוות, הוא עלול להיות מואשם ברצח (סעיף 300). אם לא יוכח כוונה או אדישות, ייתכן שיוחזק כאשם בתקיפה (סעיף 378) שהובילה למוות, מה שעשוי להחמיר את העונש.

**מסקנה:** בהתחשב בנסיבות המקרה, יוסי עלול להיות מואשם ברצח או בתקיפה שהובילה למותו של היריב. ההכרעה תלויה בראיות ובכוונתו של יוסי בעת ביצוע המעשה.
```


## IL-321

### 1. legal_eval_plan (attempt 1, 9.2 s, tokens 152 in / 208 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Right to a Speedy Trial/Reasonable Duration of Proceedings",
      "law": "חוק בתי משפט (סדרי דין) – סעיף 17",
      "sections": ["17"]
    },
    {
      "issue": "Right to Challenge Prolonged Detention/Pre-Trial Detention",
      "law": "חוק סדר הדין הפלילי (כתב אישום וזכות השימוע) – סעיף 13",
      "sections": ["13"]
    },
    {
      "issue": "Potential for Release from Detention Pending Trial",
      "law": "פקודת סדר דין פלילי (מעצרים) – סעיפים 12, 16",
      "sections": ["12", "16"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 18.1 s, tokens 4095 in / 323 out, stop: stop)

**Output**

```text
כן, לנאשם יש זכויות.

**סוגיה:** נאשם נעצר עד תום ההליכים, חלפו 9 חודשים מהגשת כתב האישום והמשפט לא הסתיים. מהן זכויותיו?

**כלל (חוק וסעיף):** סעיף 44(א1) לצו בדבר הוראות ביטחון [נוסח משולב] (יהודה והשומרון) קובע כי נאשם בעבירה שאינה עבירת ביטחון, אשר תקופת מעצרו מצטרפת לכדי תשעה חודשים, יובא לפני שופט בבית המשפט הצבאי לערעורים.

**יישום על העובדות:** מאחר וחלפו 9 חודשים מהגשת כתב האישום, הנאשם זכאי שהעניינו יובא לפני שופט בבית המשפט הצבאי לערעורים. השופט יבחן את נסיבות המקרה ויכריע האם ניתן להמשיך ולהאריך את המעצר.

**מסקנה:** הנאשם זכאי שהעניינו יובא לפני שופט בבית המשפט הצבאי לערעורים, אשר יבחן את נסיבות המקרה ויכריע האם ניתן להמשיך ולהאריך את המעצר.
```


## IL-371

### 1. legal_eval_plan (attempt 1, 9.3 s, tokens 163 in / 210 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Default Judgment (הכרת פסק דין בהעדר הגנה)",
      "law": "פקודת בתי משפט (סדרי דין)",
      "sections": ["76", "77", "78"]
    },
    {
      "issue": "Time Limits for Responding to a Claim (מגבלות זמן להגשת כתב הגנה)",
      "law": "פקודת בתי משפט (סדרי דין)",
      "sections": ["61"]
    },
    {
      "issue": "Plaintiff's Options After Defendant's Failure to Respond (אפשרויות התובע לאחר אי הגשת כתב הגנה)",
      "law": "פקודת בתי משפט (סדרי דין)",
      "sections": ["78"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 11.0 s, tokens 3776 in / 152 out, stop: stop)

**Output**

```text
לא. בהתחשב בעובדות, הנתבע לא הגיש כתב הגנה תוך 70 יום, אך תקופת הזמן להגשת כתב הגנה אינה מצוינת בשאלה. בהתאם לתקנה 10 לתקנות שיפוט בתביעות קטנות (סדרי דין), תשל"ז–1976, בית המשפט רשאי לתת פסק דין על יסוד כתב התביעה בלבד, אך רשאי גם להזמין את הצדדים לטעון את טענותיהם ולהביא ראיות, גם אם לא הוגש כתב הגנה.
```


## IL-415

### 1. legal_eval_plan (attempt 1, 9.9 s, tokens 150 in / 219 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Violation of Privacy - Publication of a Person's Image and Information Without Consent",
      "law": "חוק הגנת הפרטיות, התשנ״א-1991 (Huk HaGenat HaPirviut, HaTshna-1991) - The Privacy Protection Act, 1991",
      "sections": ["10", "12"]
    },
    {
      "issue": "Defamation/Damage to Reputation (Potential)",
      "law": "חוק איסור הוצאת דיבה, תשכ" },{"issue": "Potential for a claim under tort law for emotional distress",
      "law": "חוק הנזיקין, התשכ" },{"issue": "Potential for a claim under tort law for emotional distress",
      "law": "חוק הנזיקין, התשכ"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 12.9 s, tokens 4017 in / 194 out, stop: stop)

**Output**

```text
כן. העיתון הפר את חוק הגנת הפרטיות, סעיף 2(4), שקובע שפרסום תצלום של אדם ברבים עלול להוות פגיעה בפרטיות אם הפרסום עלול להשפילו או לבזותו. בנוסף, הפרסום מהווה לשון הרע לפי חוק איסור לשון הרע, סעיף 1, שכן הכיתוב המשפיל עלול להשפיל את האדם בעיני הבריות או לבזותו. גם אם מדובר בפרסום של תמונה של אדם מאושפז, אין בכך היתר לפרסם אותה עם כיתוב משפיל, אלא אם כן קיים עניין ציבורי חריג המצדיק זאת, דבר שאינו ברור מהעובדות.
```


## IL-036

### 1. legal_eval_plan (attempt 1, 9.1 s, tokens 160 in / 206 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Interpretation of Contracts - Subjective Intent",
        "law": "חוק החוזים (תום לב והגינות) - The Contract Law (Good Faith and Fair Dealing) Law",
        "sections": ["25(א)"]
    },
    {
        "issue": "Contractual Interpretation - Absence of Agreement on Interpretation Method",
        "law": "חוק החוזים, התשכג – The Contract Law, 1973",
        "sections": ["13", "25(א)"]
    },
    {
        "issue": "Legal Effect of New Contract Law Provisions",
        "law": "חוק החוזים (תום לב והגינות) - The Contract Law (Good Faith and Fair Dealing) Law",
        "sections": ["11"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 7.5 s, tokens 3339 in / 76 out, stop: stop)

**Output**

```text
לא, כלל הפרשנות לפי אומד דעת הצדדים חל על כל סוגי החוזים, באין הסכמה על אופן הפרשנות. סעיף 25(א) לחוק החוזים (חלק כללי), תשל״ג–1973 קובע זאת.
```


## IL-040

### 1. legal_eval_plan (attempt 1, 5.6 s, tokens 123 in / 116 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Unfairness/Exploitation in Contractual Relationships (Misleading or Exploitative Practices)", "law": "חוק הגנת הצרכן, התשכ"
},
{"issue": "Definition of 'Exploitation' within the Context of Consumer Protection", "law": "חוק הגנת הצרכן, התשכ"
},
{"issue": "Interpretation of Legal Terms in Statutory Contexts", "law": "חוק הפרשנות, התשכ"
}
]}
```

### 2. legal_eval_baseline (attempt 1, 10.0 s, tokens 4378 in / 117 out, stop: stop)

**Output**

```text
כן, לפי סעיף 431 לחוק העונשין, תשל"ז-1977, "עושק" הוא ניצול של מצוקה, חולשה גופנית או שכלית, חוסר ניסיון או קלות דעת של הזולת, למשל, בדרישת דבר שאינו מגיע לו כדין, או בדרישת תמורה העולה במידה בלתי סבירה על התמורה המקובלת עבור מצרך או שירות.
```


## IL-230

### 1. legal_eval_plan (attempt 1, 10.2 s, tokens 142 in / 233 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Definition of 'Use of a Motor Vehicle for Transportation' (שימוש ברכב מנועי למטרות תחבורה) within the context of the Victims of Road Accidents Compensation Law.",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      },
    {
      "issue": "Scope of 'Motor Vehicle' (רכב מנועי) as defined within the Victims of Road Accidents Compensation Law, impacting whether a particular vehicle falls under the law's jurisdiction.",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      },
    {
      "issue": "Determination of 'Transportation' (תחבורה) – whether the activity constitutes transportation of persons or goods, which is crucial for establishing liability under the law.",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, תשכ"
      }
  ] }
```

### 2. legal_eval_baseline (attempt 1, 14.7 s, tokens 5129 in / 216 out, stop: stop)

**Output**

```text
כן, לפי חוק פיצויים לנפגעי תאונות דרכים, "שימוש ברכב מנועי למטרות תחבורה" מוגדר כנסיעה ברכב, כניסה לתוכו או ירידה ממנו, החנייתו, דחיפתו או גרירתו, טיפול-דרך או תיקון-דרך ברכב, שנעשה בידי המשתמש בו או בידי אדם אחר שלא במסגרת עבודתו, לרבות הידרדרות או התהפכות של הרכב או התנתקות או נפילה של חלק מהרכב או מטענו תוך כדי נסיעה וכן הינתקות או נפילה כאמור מרכב עומד או חונה, שלא תוך כדי טיפולו של אדם ברכב במסגרת עבודתו. (חוק פיצויים לנפגעי תאונות דרכים, תשל״ה–1975, סעיף 1).
```


## IL-274

### 1. legal_eval_plan (attempt 1, 11.1 s, tokens 137 in / 251 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Definition of 'Material Deterioration of Working Conditions' (החמרה מוחשית בתנאי העבודה) in the context of termination entitling an employee to severance pay.",
"law": "חוק פיצויי עבודה (התגמלת לנפגעי תאונות עבודה וגמלאות מעבידים) - *The Workers' Compensation Law (Compensation for Work Accidents and Employer Benefits)*",
"sections": ["38", "48"]
},
{
"issue": "Legal consequences of termination due to a material deterioration of working conditions, including eligibility for severance pay and potential claims for damages.",
"law": "חוק עבודת המגן - *The Protection of Wages Law*",
"sections": ["13", "16"]
},
{
"issue": "The interpretation and application of 'material deterioration' by Israeli courts, considering precedent and the specific circumstances of the employment relationship.",
"law": "No specific statute - this is a matter of judicial interpretation based on general labor law principles and case law.",
"sections": []
}
]}
```

### 2. legal_eval_baseline (attempt 1, 7.7 s, tokens 3506 in / 80 out, stop: stop)

**Output**

```text
כן, לפי סעיף 11(א) לחוק פיצויי פיטורים, התשכ"ג-1963, התפטרות עובד "מחמת הרעה מוחשית בתנאי העבודה" רואים אותה כפיטורים, ולכן עשויה לזכות אותו בפיצויי פיטורים.
```


## IL-276

### 1. legal_eval_plan (attempt 1, 13.1 s, tokens 127 in / 314 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Exclusive Jurisdiction of the Labor Court (בית הדין לעבודה) - Defining the Scope",
"law": "חוק בתי דין לעבודה, התשכ\"ט-1969 (Hukkat Beit Din Le'Avoda, HaTash'chat-1969) - Law of Labor Courts, 1969",
"sections": ["1", "3", "5", "11"]
},
{
"issue": "Determination of Labor-Related Disputes - What Constitutes a 'Labor Dispute'?",
"law": "חוק בית הדין לעבודה, התשכ\"ט-1969 (Hukkat Beit Din Le'Avoda, HaTash'chat-1969) - Law of Labor Courts, 1969",
"sections": ["1", "3", "5"]
},
{
"issue": "Potential Conflicts with General Civil Courts - Hierarchy and Concurrent Jurisdiction",
"law": "חוק בתי משפט (סדר דין אזרחי), התשכ\"ט-1969 (Hukkat Beit Mishpat (Seder Din Azrachi), HaTash'chat-1969) - Law of Courts (Civil Procedure Code), 1969",
"sections": ["1", "4", "6"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 11.1 s, tokens 2897 in / 175 out, stop: stop)

**Output**

```text
כן, "סמכות ייחודית" של בית הדין לעבודה פירושה שלבית הדין לעבודה יש סמכות בלעדית לדון בהליכים מסוימים, כפי שמוגדר בחוק. לדוגמה, לפי סעיף 29 לחוק יישום ההסכם בדבר רצועת עזה ואזור יריחו, לבית הדין לעבודה תהיה סמכות ייחודית לדון בכל הליך אזרחי הנובע מהוראות הסימן. כמו כן, לפי סעיף 82א לחוק שירות התעסוקה, לבית הדין לעבודה תהיה סמכות ייחודית לדון בכל הליך אזרחי הנובע מהוראות חוק זה.
```


## IL-325

### 1. legal_eval_plan (attempt 1, 9.0 s, tokens 136 in / 199 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Distinction between 'Adishut' (Indifference) and 'Klal De'at' (Recklessness) in Criminal Law",
"law": "חוק העונשין, התשל\"ז-1977 (חוק העונשין)",
"sections": ["20"]
},
{
"issue": "Elements of Criminal Negligence and the Mental State Required for Criminal Liability",
"law": "חוק העונשין, התשל\"ז-1977 (חוק העונשין)",
"sections": ["20"]
},
{
"issue": "Interpretation and Application of Criminal Law Terms",
"law": "חוק העונשין, התשל\"ז-1977 (חוק העונשין)",
"sections": ["20"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 13.1 s, tokens 6457 in / 149 out, stop: stop)

**Output**

```text
כן, ההבדל בין "אדישות" ל"קלות דעת" טמון ביחס הנפשי של העבריין לתוצאות הפעולה. לפי סעיף 20(ב)(2) לחוק העונשין, "אדישות" היא שוויון נפש לאפשרות גרימת התוצאות, בעוד ש"קלות דעת" היא נטילת סיכון בלתי סביר לאפשרות גרימת התוצאות, מתוך תקווה להצליח למנוע אותן. חוק העונשין, תשל"ז–1977, סעיף 20.
```


## IL-327

### 1. legal_eval_plan (attempt 1, 21.1 s, tokens 126 in / 512 out, stop: length)

**Output**

```text
{ "issues": [
{
"issue": "The legal standard of 'reasonableness' (דרישת הסבירות) as a requirement for exceptions to criminal liability.",
"law": "חוק העונשין, התשכ\"ב-1968 (פִּקּוּד עוֹנְשִׁיִן)",
"sections": ["25", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "1
```

### 2. legal_eval_plan (attempt 2, 6.6 s, tokens 166 in / 155 out, stop: stop)

**Output**

```text
{"issues": [
    {"issue": "Reasonableness Standard in Criminal Procedure – Exclusion of Criminal Liability",
     "law": "חוק סדר הדין הפלילי בשישראל (סדרי דין)",
     "sections": ["46", "47", "48"]},
    {"issue": "Judicial Review of Prosecutorial Discretion – Application of Reasonableness",
     "law": "חוק תובע",
     "sections": []},
    {"issue": "Principles of Criminal Law – Justification and Excuse",
     "law": "פקודת החוק הפלילי (עבירות שדורשות דעת)",
     "sections": []}
]}
```

### 3. legal_eval_baseline (attempt 1, 10.0 s, tokens 3932 in / 130 out, stop: stop)

**Output**

```text
כן, "דרישת הסבירות" קשורה לסייגים לאחריות פלילית מכיוון שעל פי סעיף 34כב(ב) לחוק העונשין, התשע"ז-1977, אם התעורר ספק סביר שמא קיים סייג לאחריות פלילית, והספק לא הוסר, הסייג יחול. המשמעות היא שקיומו של ספק סביר לגבי קיומו של סייג מחייב הפעלה של הסייג.
```


## IL-420

### 1. legal_eval_plan (attempt 1, 7.2 s, tokens 117 in / 161 out, stop: stop)

**Output**

```text
{"issues": [
{"issue": "Derivative Lawsuit - Definition and Standing", "law": "חוק השותפויות (שותפויות מוגבלות), תשנ\"ז-1997", "sections": ["48", "48א"]},
{"issue": "Derivative Lawsuit - Scope of Action and Representation", "law": "פקודת בתי משפט (סדרי דין), תשל\"ס-1970", "sections": ["144", "145"]},
{"issue": "Derivative Lawsuit - Liability of Plaintiff", "law": "חוק החברות, התשנ\"ג-1993", "sections": ["149"]}
]}
```

### 2. legal_eval_baseline (attempt 1, 8.4 s, tokens 4106 in / 82 out, stop: stop)

**Output**

```text
תביעה נגזרת היא תביעה שהוגשה בשם חברה על ידי בעל מניה או דירקטור, כאשר ישנה עילת תביעה נגד החברה. על מנת להגיש תביעה נגזרת, יש לקבל אישור מבית המשפט (חוק החברות, סעיף 198).
```


## IL-046

### 1. legal_eval_plan (attempt 1, 8.6 s, tokens 221 in / 191 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Contract Formation & Validity - Oral Contracts",
        "law": "חוק החוזים (חלק כללי) – The Contract Law (General Part) Law",
        "sections": ["27", "30"]
        },
    {
        "issue": "Requirement of Writing for Contracts - Statute of Frauds",
        "law": "חוק החוזים (חלק כללי) – The Contract Law (General Part) Law",
        "sections": ["12"]
        },
    {
        "issue": "Formalities of Contract Execution - Signature Requirement",
        "law": "חוק החוזים (חלק כללי) – The Contract Law (General Part) Law",
        "sections": ["12"]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 8.7 s, tokens 3010 in / 109 out, stop: stop)

**Output**

```text
ד. 

חוזה יכול להיעשות בכל צורה, אלא אם החוק קבע צורה מסוימת כתנאי לתוקפו. סעיף 23 לחוק החוזים (חלק כללי) קובע כי "חוזה יכול שייעשה בעל פה, בכתב או בצורה אחרת, זולת אם היתה צורה מסויימת תנאי לתקפו על פי חוק או הסכם בין הצדדים."
```


## IL-049

### 1. legal_eval_plan (attempt 1, 12.9 s, tokens 215 in / 302 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Interpretation and Enforcement of Contracts - Gap-Filling (מילוי פרטים חסרים בחוזה)",
        "law": "חוק החוזים (חלק כללי), התשכג – 1973 (HaChukot HaKuzot (Hakhelal), HaTashkag – 1973)",
        "sections": ["25", "29", "30"]
    },
    {
        "issue": "Good Faith in Contractual Relations (תום לב בחוזים)",
        "law": "חוק החוזים (חלק כללי), התשכג – 1973 (HaChukot HaKuzot (Hakhelal), HaTashkag – 1973)",
        "sections": ["6", "12"]
    },
    {
        "issue": "Contractual Uncertainty and Nullity (בטלות חוזה מחמת חוסר מסוימות)",
        "law": "חוק החוזים (חלק כללי), התשכג – 1973 (HaChukot HaKuzot (Hakhelal), HaTashkag – 1973)",
        "sections": ["13"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.0 s, tokens 2835 in / 96 out, stop: stop)

**Output**

```text
ג. ייקבע לפי הנוהג המקובל בחוזים מאותו סוג.

סעיף 26 לחוק החוזים (חלק כללי) קובע כי פרטים שלא נקבעו בחוזה או על פיו יהיו לפי הנוהג הקיים בין הצדדים, ובאין נוהג כזה – לפי הנוהג המקובל בחוזים מאותו סוג.
```


## IL-103

### 1. legal_eval_plan (attempt 1, 7.8 s, tokens 172 in / 160 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Contractual Validity of Future Gifts (Promise to Give a Gift)",
        "law": "חוק החוזים (מכר) - The Contract Law (Sale of Goods) Law",
        "sections": ["4", "16", "29", "36"]
        },
    {
        "issue": "Statute of Frauds - Requirement for Written Agreements",
        "law": "חוק הפרוצדורה האזרחית, תשכ"
        },
    {
        "issue": "Evidence and Oral Testimony",
        "law": " חוק הראיות, תשכ"
        }
    ]
}
```

### 2. legal_eval_baseline (attempt 1, 6.5 s, tokens 3308 in / 52 out, stop: stop)

**Output**

```text
ג. 

התחייבות לתת מתנה בעתיד טעונה מסמך בכתב, כפי שקבוע בסעיף 5 לחוק המתנה, תשכ״ח–1968.
```


## IL-105

### 1. legal_eval_plan (attempt 1, 9.9 s, tokens 205 in / 224 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Statute of Limitations for Insurance Claims (excluding life and care insurance)",
      "law": "חוק חוזה הביטוח (Chok Chovat HaBituach - The Insurance Contracts Law)",
      "sections": ["סעיף 22"]
    },
    {
      "issue": "Definition of 'Date of Occurrence of the Insured Event' (מועד קרות מקרה הביטוח)",
      "law": "חוק חוזה הביטוח (Chok Chovat HaBituach - The Insurance Contracts Law)",
      "sections": ["סעיף 2"]
    },
    {
      "issue": "Interpretation of 'Rejection of the Claim' (דחיית התביעה)",
      "law": "חוק חוזה הביטוח (Chok Chovat HaBituach - The Insurance Contracts Law)",
      "sections": ["סעיף 22"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 7.6 s, tokens 3770 in / 71 out, stop: stop)

**Output**

```text
ג.

תקופת ההתיישנות של תביעה לתגמולי ביטוח (שאינו ביטוח חיים או סיעוד) היא שלוש שנים מיום קרות מקרה הביטוח, כפי שמופיע בסעיף 31 לחוק חוזה הביטוח.
```


## IL-188

### 1. legal_eval_plan (attempt 1, 5.9 s, tokens 181 in / 118 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Order of Inheritance in the Presence of a Spouse and Children",
        "law": "חוק הירושה, תשכ"
        },
    {
        "issue": "Spousal Rights in Inheritance",
        "law": "חוק הירושה, תשכ"
        },
    {
        "issue": "Children's Rights in Inheritance",
        "law": "חוק הירושה, תשכ"
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 7.7 s, tokens 2866 in / 90 out, stop: stop)

**Output**

```text
א. בן הזוג והילדים

סעיף 10 לחוק הירושה קובע מי הם היורשים על פי דין. כאשר למוריש יש בן זוג וילדים, הם היורשים. סעיף 11 לחוק הירושה קובע את חלקו של בן הזוג בעזבון, אשר תלוי בהאם יש ילדים או הורים.
```


## IL-193

### 1. legal_eval_plan (attempt 1, 7.8 s, tokens 203 in / 167 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Division of marital property under the Matrimonial Regime Law – specifically, the treatment of property received as a gift during marriage.",
        "law": "חוק יחסי ממון בין בני זוג, התשל" },{"issue": "The relevance of the date of the gift (before or after 2000) in determining its inclusion in the marital estate.",
        "law": "חוק יחסי ממון בין בני זוג, התשל" },
    {
        "issue": "The effect of joint registration of property on its inclusion in the marital estate.",
        "law": "חוק יחסי ממון בין בני זוג, התשל" }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 9.3 s, tokens 3536 in / 117 out, stop: stop)

**Output**

```text
ב. מוחרגת מהאיזון, ככלל

סעיף 5(א)(1) לחוק יחסי ממון קובע כי איזון משאבים לא יכלול נכסים שהיו לבן הזוג ערב הנישואין או שקיבלו במתנה או בירושה בתקופת הנישואין. דירה שקיבלה במתנה מהוריה במהלך הנישואין נחשבת למתנה, ולכן מוחרגת מהאיזון.
```


## IL-286

### 1. legal_eval_plan (attempt 1, 11.1 s, tokens 211 in / 255 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "The legal status and interaction of severance pay (פיצויי פיטורים) and pension fund contributions designated for severance pay (הפקדות לרכיב פיצויים בקרן פנסיה) under Israeli law.",
        "law": "חוק פיצויי פיטורים (Chok Pizuy Piturim) - Severance Pay Law",
        "sections": ["14", "34"]
    },
    {
        "issue": "Whether contributions to a pension fund designated for severance pay affect the employee's entitlement to severance pay.",
        "law": "חוק פיצויי פיטורים (Chok Pizuy Piturim) - Severance Pay Law",
        "sections": ["14", "34"]
    },
    {
        "issue": "The potential substitution or supplementation of severance pay with pension fund contributions.",
        "law": "חוק פיצויי פיטורים (Chok Pizuy Piturim) - Severance Pay Law",
        "sections": ["14", "34"]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 9.6 s, tokens 3039 in / 133 out, stop: stop)

**Output**

```text
ג. באות במקום פיצויי הפיטורים, בשיעור ובתקופה שבהם הופקדו

לפי סעיף 14 לחוק פיצויי פיטורים, תשלום לקופת גמל או קרן פנסיה לא בא במקום פיצויי פיטורים אלא אם נקבע אחרת בהסכם קיבוצי או אושר על ידי שר העבודה. עם זאת, סעיף 20 לחוק מאפשר הסכם קיבוצי שיקבע שהפקדות יבואו במקום פיצויי הפיטורים.
```


## IL-331

### 1. legal_eval_plan (attempt 1, 14.1 s, tokens 173 in / 335 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Aiding and Abetting a Crime (סיוע לעבירה)",
        "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן, הַתְּשַׁלְז׳–1977)",
        "sections": ["סעיף 31", "סעיף 32"]
    },
    {
        "issue": "Maximum Penalties for Aiding and Abetting (עונש מרבי לסיוע לעבירה)",
        "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן, הַתְּשַׁלְז׳–1977)",
        "sections": ["סעיף 45"]
    },
    {
        "issue": "Determining the Base Crime's Sentence (קביעת עונש העבירה הבסיסית)",
        "law": "חוק העונשין, התשל\"ז-1977 (פִּקּוּד עוֹנְשִׁיִן, הַתְּשַׁלְז׳–1977)",
        "sections": ["סעיף 31"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.0 s, tokens 3530 in / 85 out, stop: stop)

**Output**

```text
ג.

הסיוע לעבירה שעונשה מאסר 10 שנים, העונש המרבי יהיה מחצית מהעונש שנקבע לעבירה העיקרית, כלומר 5 שנות מאסר. סעיף 32 לחוק העונשין, תשל"ז-1977 קובע זאת.
```


## IL-332

### 1. legal_eval_plan (attempt 1, 12.0 s, tokens 175 in / 282 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "The prompt concerns the time limit for bringing a detained person before a judge (appearance before a magistrate). This is a fundamental right related to due process and preventing unlawful detention.",
        "law": "חוק סדר הדין הפלילי (מעצרים) - *Huk Seder HaDin HaPli'ali (Ma'atzrim)* (Criminal Procedure Law (Arrests))",
        "sections": ["8", "12"]
    },
    {
        "issue": "The question touches upon the legality of pre-trial detention and the safeguards against prolonged or arbitrary detention without judicial oversight.",
        "law": "חוק זכויות האדם - *Huk Zchuyot HaAdam* (Basic Law: Human Dignity and Liberty)",
        "sections": ["5"]
    },
    {
        "issue": "The prompt relates to the procedural rights of a suspect during arrest and detention, specifically the right to a prompt judicial review of the detention.",
        "law": "פקודת סדרי דין הפלילי - *Pekudat Sederi Din HaPli'ali* (The Code of Criminal Procedure)",
        "sections": ["27"]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 8.4 s, tokens 4939 in / 65 out, stop: stop)

**Output**

```text
ג.

העצור יובא בפני שופט לא יאוחר מ-24 שעות משעת מעצרו, כפי שמצוין בסעיף 29 לחוק סדר הדין הפלילי (סמכויות אכיפה – מעצרים).
```


## IL-339

### 1. legal_eval_plan (attempt 1, 11.6 s, tokens 156 in / 269 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Criminal Liability for Manslaughter (המתה מקלה)",
        "law": "חוק העונשין, התשל\"ז-1977 (Huk ha'Onshin, HaTshil'v-1977)",
        "sections": ["83", "85"]
    },
    {
        "issue": "Sentencing Guidelines for Criminal Offenses (קביעת עונש)",
        "law": "חוק העונשין, התשל\"ז-1977 (Huk ha'Onshin, HaTshil'v-1977)",
        "sections": ["34", "34א"]
    },
    {
        "issue": "Definition of 'Manslaughter' and its Degrees (הגדרת המתה מקלה והדרגות שלה)",
        "law": "חוק העונשין, התשל\"ז-1977 (Huk ha'Onshin, HaTshil'v-1977)",
        "sections": ["82", "83", "85"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 6.6 s, tokens 2718 in / 68 out, stop: stop)

**Output**

```text
ב. 12 שנות מאסר.

ההתה בקלות דעת מוגדר בסעיף 301ג' לחוק העונשין, הקובע כי דינו של הגורם למותו של אדם בקלות דעת הוא מאסר שתים עשרה שנים.
```


## IL-378

### 1. legal_eval_plan (attempt 1, 8.3 s, tokens 143 in / 185 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Composition and Structure of the Knesset",
        "law": "חוק הכנסת (פרוצדורה) - Hukat HaKnesset (Prozedura)",
        "sections": ["4", "5", "6"]
    },
    {
        "issue": "Constitutional Framework Defining Legislative Bodies",
        "law": "חוק יסוד: הכנסת - Hukkat Yesod: HaKnesset",
        "sections": ["1", "2"]
    },
    {
        "issue": "Electoral System and Representation (Indirectly Relevant)",
        "law": "חוק המפלחות - Huk HaMiflachot",
        "sections": ["1", "2", "3"]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 5.8 s, tokens 2577 in / 48 out, stop: stop)

**Output**

```text
ג. 120

חוק-יסוד: הכנסת קובע בסעיף 3 כי "הכנסת בהיבחרה תהיה בת מאה ועשרים חבר".
```


## IL-380

### 1. legal_eval_plan (attempt 1, 10.4 s, tokens 169 in / 238 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Statute of Limitations/Time Limit for Filing a Response to a Civil Lawsuit",
        "law": "חוק פראסגוריה - חוק ההתדיינות האזרחית (Zakat Ha-Pirsa'goriyah - Chok Ha-Hitdineut Ha-Azirit)",
        "sections": ["סעיף 71"]
    },
    {
        "issue": "Civil Procedure Rules - Specifically, the rules governing the form and timing of pleadings in civil cases.",
        "law": "תקנות סדר דין אזרחי (Rules of Civil Procedure)",
        "sections": ["תקנה 140"]
    },
    {
        "issue": "Jurisdiction and Court Procedures - The question implicitly relates to the proper court and procedures for handling civil claims.",
        "law": "חוק בתי משפט (Chok Betey Mishpat)",
        "sections": ["סעיפים 61-63"]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 9.6 s, tokens 3845 in / 120 out, stop: stop)

**Output**

```text
א. 60 ימים

תקנה 9 לתקנות סדר הדין האזרחי, התשע"ט-2018 קובעת כי כתב הגנה יוגש בתוך 60 ימים ממועד המצאת כתב התביעה לידי הנתבע. במקרים מסוימים, כמו תביעה שעניינה רשלנות רפואית, המועד הוא 120 ימים, ובית המשפט רשאי להאריך את המועד.
```


## IL-381

### 1. legal_eval_plan (attempt 1, 9.0 s, tokens 166 in / 201 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Statute of Limitations for Responding to a Civil Claim (specifically Negligence)",
      "law": "חוק סדר דין אזרחי, התשי״ב-1951",
      "sections": ["161", "162"]
    },
    {
      "issue": "Calculation of Time Limits in Civil Procedure",
      "law": "חוק סדר דין אזרחי, התשי״ב-1951",
      "sections": ["165"]
    },
    {
      "issue": "Specific Considerations for Medical Malpractice Claims (potentially impacting the statute of limitations)",
      "law": "פקודת בתי משפט (נוהלי עבודה), התשכ״ז-1967",
      "sections": []
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 9.0 s, tokens 4383 in / 93 out, stop: stop)

**Output**

```text
ב. 120 ימים.

תקנה 9(ב) לתקנות סדר הדין האזרחי, התשע"ט-2018 קובעת כי בתביעה שעניינה רשלנות רפואית, כתב ההגנה יוגש תוך 120 ימים ממועד המצאת כתב התביעה לידי הנתבע.
```


## IL-382

### 1. legal_eval_plan (attempt 1, 12.8 s, tokens 196 in / 299 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Jurisdiction of Magistrates' Courts (בית משפט השלום) in Criminal Matters - Specifically, the limits on the types of offenses they can hear based on maximum sentence.",
        "law": "חוק בתי משפט (סדרי דין) – *Huk Batim Mishpat (S'drei Din)*",
        "sections": ["סעיף 73"]
    },
    {
        "issue": "Definition of 'Maximum Sentence' (עונשן המרבי) and its relevance to jurisdictional limits.",
        "law": "חוק העונשין – *Huk Ha'Onashin*",
        "sections": ["Relevant sections defining penalties for various crimes would be applicable, but no specific section directly addresses the *maximum* sentence for jurisdictional purposes."]
    },
    {
        "issue": "Interpretation of Criminal Law and Jurisdictional Boundaries – How the maximum sentence prescribed in the criminal law interacts with the jurisdictional limits of the court.",
        "law": "פקודת תעבורה – *Pekudat Ta'avora* (if the question relates to traffic offenses)",
        "sections": ["Relevant sections defining penalties for traffic offenses would be applicable, but no specific section directly addresses the *maximum* sentence for jurisdictional purposes."]
    }
]
}
```

### 2. legal_eval_baseline (attempt 1, 8.9 s, tokens 5302 in / 70 out, stop: stop)

**Output**

```text
ג. 
בית משפט השלום מוסמך לדון בעבירות שעונשן המרבי אינו עולה על 7 שנות מאסר, כפי שכתוב בסעיף 51(א)(1) לחוק בתי המשפט [נוסח משולב].
```


## IL-383

### 1. legal_eval_plan (attempt 1, 8.6 s, tokens 179 in / 194 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Requirements for a Vote of No Confidence in the Government",
        "law": "חוק יסוד: הממשלה (Basic Law: The Government)",
        "sections": ["48(א)","49(ב)"]
    },
    {
        "issue": "Role of the President in relation to a Vote of No Confidence",
        "law": "חוק יסוד: נשיא המדינה (Basic Law: The President)",
        "sections": ["11"]
    },
    {
        "issue": "Formation of an Alternative Government following a Vote of No Confidence",
        "law": "חוק יסוד: הממשלה (Basic Law: The Government)",
        "sections": ["49(ב)","51"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.2 s, tokens 2984 in / 99 out, stop: stop)

**Output**

```text
א. רוב של שני שלישים

חוק-יסוד: הממשלה קובע כי הבעת אי-אמון בממשלה תיעשה בהחלטה של הכנסת, ברוב חבריה (סעיף 28(א)). עם זאת, כדי להביע אמון בממשלה אחרת, יש צורך ברוב חברי הכנסת, אשר בפועל הוא רוב של שני שלישים.
```


## IL-426

### 1. legal_eval_plan (attempt 1, 7.6 s, tokens 161 in / 163 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Statute of Limitations for Challenging Arbitration Awards",
      "law": "חוק בוררות (סדרי דין)",
      "sections": ["48"]
    },
    {
      "issue": "Procedural Requirements for Filing a Motion to Vacate an Arbitration Award",
      "law": "חוק בוררות (סדרי דין)",
      "sections": ["26"]
    },
    {
      "issue": "Jurisdiction and Court Authority to Review Arbitration Awards",
      "law": "חוק בוררות (סדרי דין)",
      "sections": ["25"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.9 s, tokens 4323 in / 90 out, stop: stop)

**Output**

```text
א. 45 ימים

הבקשה לביטול פסק בורר תוגש תוך 45 ימים מיום מתן הפסק, כפי שנקבע בסעיף 27 לחוק הבוררות, תשכ"ח-1968. סעיף 27 קובע גם שהמועד יכול להיות מוארך מטעמים מיוחדים.
```


## IL-108

### 1. legal_eval_plan (attempt 1, 8.6 s, tokens 129 in / 193 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Duty to Mitigate Damages (Obligation to Minimize Loss)",
      "law": "חוק החוזים (מכר) - Perek Ha'Mitzui Le'Haktanat HaNezak",
      "sections": ["47"]
    },
    {
      "issue": "General Tort Law Principles - Applicability of Mitigation Duty",
      "law": "פקודת הנזיקין - Pkudat HaNezikin",
      "sections": ["35"]
    },
    {
      "issue": "Contract Law - Specific Application in Contractual Disputes",
      "law": "חוק החוזים - חלק כללי - Chok Ha'Chozim - Chelek Klali",
      "sections": ["12"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.3 s, tokens 3566 in / 92 out, stop: stop)

**Output**

```text
כן, סעיף 14 לחוק החוזים (תרופות בשל הפרת חוזה), תשל"א–1970, מסדיר את חובת הקטנת הנזק. הסעיף קובע כי המפר אינו חייב בפיצויים אם הנפגע יכול היה באמצעים סבירים למנוע או להקטין את הנזק.
```


## IL-110

### 1. legal_eval_plan (attempt 1, 9.0 s, tokens 127 in / 204 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Revocation of a Gift Promise (Withdrawal from a Commitment to Give a Gift)",
      "law": "חוק החוזים (מכר) - Perek Ha'Chuzim (Mikhar)",
      "sections": ["47", "48"]
    },
    {
      "issue": "Contractual Validity and Reliance (Potential for Reliance Damages if Revocation is Unjust)",
      "law": "חוק החוזים - Perek Ha'Chuzim (General)",
      "sections": ["14", "61"]
    },
    {
      "issue": "General Principles of Contract Law and Good Faith",
      "law": "חוק החוזים - Perek Ha'Chuzim (General)",
      "sections": ["2", "12"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.0 s, tokens 2890 in / 98 out, stop: stop)

**Output**

```text
לא, האפשרות לחזור מהתחייבות לתת מתנה מוסדרת בסעיף 5 לחוק המתנה, תשכ״ח–1968. הסעיף קובע שכל עוד מקבל המתנה לא שינה את מצבו בהסתמך על ההתחייבות, הנותן רשאי לחזור בו ממנה, אלא אם כן ויתר בכתב על רשות זו.
```


## IL-240

### 1. legal_eval_plan (attempt 1, 9.4 s, tokens 128 in / 218 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Statute of Limitations (General)",
"law": "חוק ההתיישנות, התשי״ז-1957",
"sections": ["1", "3", "5", "6", "7", "8", "9", "10", "11", "12"]
},
{
"issue": "Specific Limitation Periods for Different Claims (Implied by the question's focus)",
"law": "חוק ההתיישנות, התשי״ז-1957",
"sections": ["3", "5", "6", "7", "8", "9", "10", "11", "12"]
},
{
"issue": "Interpretation and Application of the Statute of Limitations",
"law": "חוק ההתיישנות, התשי״ז-1957",
"sections": ["1", "2", "13"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 7.1 s, tokens 2741 in / 79 out, stop: stop)

**Output**

```text
כן, סעיף 5 לחוק ההתיישנות קובע את תקופות ההתיישנות. סעיף 5(1) קובע כי התקופה היא שבע שנים בשאינו מקרקעין, וסעיף 5(2) קובע כי היא חמש עשרה שנה במקרקעין.
```


## IL-388

### 1. legal_eval_plan (attempt 1, 9.0 s, tokens 134 in / 202 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Location of the Limitation Clause in the Basic Law: Human Dignity and Freedom",
"law": "חוק-יסוד: כבוד האדם וחירותו (Huk-Yesod: Kvod HaAdam ve-Khrut)",
"sections": ["3" ]
},
{
"issue": "Interpretation and Application of Limitation Clauses in Basic Laws",
"law": "חוק-יסוד: כבוד האדם וחירותו (Huk-Yesod: Kvod HaAdam ve-Khrut)",
"sections": ["2", "3"]
},
{
"issue": "Constitutional Law Principles Regarding Basic Laws",
"law": "חוק-יסוד: כבוד האדם וחירותו (Huk-Yesod: Kvod HaAdam ve-Khrut)",
"sections": []
}
]}
```

### 2. legal_eval_baseline (attempt 1, 5.8 s, tokens 2092 in / 57 out, stop: stop)

**Output**

```text
כן, פסקת ההגבלה קבועה בסעיף 32 בהצעת תנועת החירות לחוקת יסוד למדינת ישראל, אשר שולבה בחוק-יסוד: כבוד האדם וחירותו.
```


## IL-389

### 1. legal_eval_plan (attempt 1, 10.3 s, tokens 130 in / 240 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Binding Precedent of Supreme Court Decisions",
      "law": "חוק בתי המשפט (סדרי דין) - Perek HaKnesset, 1970",
      "sections": ["74", "75"]
    },
    {
      "issue": "Judicial Hierarchy and Authority",
      "law": "חוק בתי משפט השלום, בית המשפט המחוזי ובית המשפט העליון - Perek HaKnesset, 1969",
      "sections": ["11", "12"]
    },
    {
      "issue": "General Principles of Legal Interpretation",
      "law": "This issue is less directly governed by a specific statute, but principles of statutory interpretation would be relevant.  While there isn't a single statute *specifically* on legal interpretation, the principles are derived from various sources including the Basic Laws and judicial precedent.",
      "sections": ["N/A - Principles derived from various sources"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 7.6 s, tokens 3219 in / 80 out, stop: stop)

**Output**

```text
כן, הלכת בית המשפט העליון מחייבת את הערכאות הנמוכות בהתאם לסעיף 20(ב) לחוק-יסוד: השפיטה, הקובע כי "הלכה שנפסקה בבית המשפט העליון מחייבת כל בית משפט, זולת בית המשפט העליון".
```


## IL-391

### 1. legal_eval_plan (attempt 1, 7.5 s, tokens 142 in / 163 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Disclosure Requirements in Political Advertising - Deepfakes",
      "law": "חוק הבחירות לכנסת (פגם בטופס הבחירות), התשס"
      },
    {
      "issue": "Definition of 'Deepfake' and Related Advertising Regulations",
      "law": "פקודת העבירות האלקטרוניות, התשס"
      },
    {
      "issue": "Enforcement and Penalties for Violations of Election Advertising Laws",
      "law": "חוק סדר הדין הפלילי (סמכויות אכיפה), התשנ"
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 11.8 s, tokens 4673 in / 155 out, stop: stop)

**Output**

```text
לא. חובת הגילוי על "נחזות עמוקה" מוסדרת בחוק הבחירות (דרכי תעמולה), תשי"ט–1959, סעיף 2א2, כהוראת שעה מ-23.7.2026 ועד 26.10.2027. כמו כן, קיימים כללי הבחירות (דרכי תעמולה) (עמידה בחובת הגילוי לגבי תעמולת בחירות שהיא נחזות עמוקה), התשפ"ו–2026, המסדירים את אופן ביצוע החובה.
```


## IL-432

### 1. legal_eval_plan (attempt 1, 8.2 s, tokens 125 in / 182 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Requirements for Class Action Lawsuit Approval (Conditions for Certification)",
"law": "חוק תובענות ייצוגיות, תשכ\"ט-1968",
"sections": ["14", "15", "16"]
},
{
"issue": "Standing to Bring a Class Action (Representative Suit)",
"law": "חוק תובענות ייצוגיות, תשכ\"ט-1968",
"sections": ["5", "6"]
},
{
"issue": "Court Discretion in Class Action Decisions",
"law": "חוק תובענות ייצוגיות, תשכ\"ט-1968",
"sections": ["14(b)"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 15.0 s, tokens 4269 in / 241 out, stop: stop)

**Output**

```text
כן, תנאי לאישור תובענה ייצוגית קבוע בסעיף 8(א) לחוק תובענות ייצוגיות, התשס״ו–2006, לפיו בית המשפט ימצא שהתקיימו התנאים הבאים: (1) התובענה מעוררת שאלות מהותיות של עובדה או משפט המשותפות לכלל חברי הקבוצה, ויש אפשרות סבירה שהן יוכרעו בתובענה לטובת הקבוצה; (2) תובענה ייצוגית היא הדרך היעילה וההוגנת להכרעה במחלוקת בנסיבות הענין; (3) קיים יסוד סביר להניח כי ענינם של כלל חברי הקבוצה ייוצג וינוהל בדרך הולמת; (4) קיים יסוד סביר להניח כי ענינם של כלל חברי הקבוצה ייוצג וינוהל בתום לב.
```


## IL-060

### 1. legal_eval_plan (attempt 1, 8.4 s, tokens 161 in / 186 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Contract Interpretation & Unrepresented Parties",
      "law": "חוק החוזים (מתן כוח) - החלק הכללי",
      "sections": ["סעיף 25"]
    },
    {
      "issue": "Contractual Agreements on Interpretation",
      "law": "חוק החוזים, התשכג – 1962",
      "sections": ["סעיף 14"]
    },
    {
      "issue": "Legal Validity of Clauses in Contracts",
      "law": "חוק החוזים (חלק כללי), התשכג – 1962",
      "sections": ["סעיף 25"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 9.5 s, tokens 3184 in / 128 out, stop: stop)

**Output**

```text
לא, הסכמה בין צדדים לעניין אופן הפרשנות של חוזה לא יהיה לה תוקף אם הצדדים לא היו מיוצגים על ידי עורך דין בעריכת החוזה. סעיף 25(א)(5) לחוק החוזים (חלק כללי), תשל״ג–1973 קובע כי "יראו צדדים שאינם מיוצגים על ידי עורך דין לעניין עריכת החוזה כצדדים שלא הסכימו על אופן הפרשנות".
```


## IL-198

### 1. legal_eval_plan (attempt 1, 8.7 s, tokens 131 in / 194 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Date of Implementation of Durable Power of Attorney within the Capacity to Act Law",
"law": "חוק הכשרות המשפטית, התשכ\"ב-1962",
"sections": ["סעיף 13א"]
},
{
"issue": "Amendments to the Capacity to Act Law",
"law": "חוק הכשרות המשפטית (ייפוי כוח מתמשך), התשע\"ו-2016",
"sections": []
},
{
"issue": "Legal Interpretation of the Durable Power of Attorney Institution",
"law": "חוק הכשרות המשפטית, התשכ\"ב-1962",
"sections": ["סעיפים 3, 5, 7, 10"]
}
]}
```

### 2. legal_eval_baseline (attempt 1, 8.8 s, tokens 3456 in / 106 out, stop: stop)

**Output**

```text
לא, מוסד "ייפוי הכוח המתמשך" נוסף לחוק הכשרות המשפטית והאפוטרופסות בשנת תשע"ז, 2017. סעיף 32יט(א) לחוק הכשרות המשפטית והאפוטרופסות, תשכ"ב–1962, קובע את מועד כניסתו לתוקף של ייפוי כוח מתמשך.
```


## IL-347

### 1. legal_eval_plan (attempt 1, 10.5 s, tokens 170 in / 239 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Validity and Interpretation of Amended Legislation (specifically, Section 17 of the Pre-Indictment Detention Law)",
      "law": "חוק המעצרים (מעצר לפני הגשת כתב אישום) - *Huk haMe'atzim (Ma'atzar Lifnei Hagashat Kitve Ishim)*",
      "sections": ["17"]
    },
    {
      "issue": "Retroactivity of Laws and Constitutional Considerations (regarding application of amended law to past detention periods)",
      "law": "חוק יסוד: זכויות אדם - *Huk Yesod: Zkhuyot Adam*",
      "sections": []
    },
    {
      "issue": "Judicial Review and the Process of Reassessing Detention Orders",
      "law": "פקודת בית המשפט (נוהלי עבודה) - *Pekudat Beit HaMishpat (Nohalei Avoda)*",
      "sections": []
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 11.3 s, tokens 5070 in / 133 out, stop: stop)

**Output**

```text
לא. סעיף 17 לחוק המעצרים אינו תוקן בשנים 2024–2026. סעיף 17(ד) לחוק המעצרים, כפי שהוא מופיע כעת, קובע כי אם תובע הצהיר שעומדים להגיש כתב אישום נגד אדם, ושוכנע בית המשפט שיש עילה לבקש את מעצרו עד תום ההליכים, רשאי שופט להאריך את המעצר לתקופה שלא תעלה על 5 ימים.
```


## IL-392

### 1. legal_eval_plan (attempt 1, 20.9 s, tokens 145 in / 512 out, stop: length)

**Output**

```text
{ "issues": [
{
"issue": "Scope of Application of Civil Procedure Rules",
"law": "תקנות סדר הדין האזרחי, התשע\"ט-2018 (Tekanot Seder HaDin HaAzari, HaTash'at-2018)",
"sections": ["1", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "1
```

### 2. legal_eval_plan (attempt 2, 10.6 s, tokens 185 in / 261 out, stop: stop)

**Output**

```text
{"issues": [
    {
      "issue": "Scope of Civil Procedure Rules Application",
      "law": "תקנות סדר הדין האזרחי, התשע\"ט-2018 (Tekanot Seder HaDin HaAzrachi, HaTish'a Tzvah Vav Reish, 2018)",
      "sections": ["1", "3", "4", "5"]
    },
    {
      "issue": "Retroactivity of Legal Regulations",
      "law": "חוק החקיקה, התשנ\"ב-1992 (Chok HaChikah, HaTish'a Nun Beit, Vav Beit, 1992)",
      "sections": ["11"]
    },
    {
      "issue": "Application of Previous Civil Procedure Rules",
      "law": "תקנות סדר הדין האזרחי, התשכ\"ד-1974 (Tekanot Seder HaDin HaAzrachi, HaTish'a Chet Chet Dalet, 1974)",
      "sections": []
    }
  ]
}
```

### 3. legal_eval_baseline (attempt 1, 9.9 s, tokens 3519 in / 133 out, stop: stop)

**Output**

```text
כן, תקנות סדר הדין האזרחי, התשע"ט-2018 חלות על הליכים אזרחיים בבית המשפט, אלא אם כן נקבע אחרת בתקנות ספציפיות. לפני כניסתן לתוקף, תקנות סדר הדין האזרחי, התשמ"ד-1984 חלות על הליכים שנפתחו לפני יום תחילתן של התקנות החדשות, אלא אם כן חלות לגביהן התקנות החדשות לפי תקנה 180(ג).
```


## IL-452

### 1. legal_eval_plan (attempt 1, 11.2 s, tokens 170 in / 252 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Disclosure of Material Facts (Non-Disclosure/Misrepresentation)",
      "law": "חוק חוזה ביטוח, תשמ" },{"issue": "Good Faith and Fair Dealing in Insurance Contracts (Duty of Utmost Good Faith - *דרישות תום לב*)",
      "law": "חוק חוזה ביטוח, תשמ" },
    {
      "issue": "Reasonable Timeframe for Insurance Company Response/Processing Claims",
      "law": "פקודת ביטוח, תשל" },{"issue": "Contract Interpretation - Ambiguity in Questionnaire",
      "law": "חוק החוזים (תفسור), תשל" },
    {
      "issue": "Potential for Bad Faith Claim Against the Insurer",
      "law": "חוק החוזים (תفسור), תשל" },
    {
      "issue": "Enforceability of the Insurance Policy Clause Regarding Disclosure",
      "law": "חוק חוזה ביטוח, תשמ" }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 31.7 s, tokens 7842 in / 567 out, stop: stop)

**Output**

```text
הסוגיה – חובת גילוי בחוזה ביטוח – חוק חוזה הביטוח, התשמ״א–1981, סעיף 6.
הסוגיה – ביטול חוזה ביטוח עקב אי גילוי – חוק חוזה הביטוח, התשמ״א–1981, סעיף 7(א).
הסוגיה – תקופת ביטול חוזה ביטוח עקב אי גילוי – חוק חוזה הביטוח, התשמ״א–1981, סעיף 7(א).
הסוגיה – חובת המבטח להודיע על כוונת תביעה נגד צד שלישי – חוק הפיקוח על שירותים פיננסיים (ביטוח), התשמ״א–1981, סעיף 108א.
הסוגיה – אפשרות להגיש תלונה לממונה על שוק ההון ולוועדת תלונות – חוק שוויון זכויות לאנשים עם מוגבלות, התשנ״ח–1998, סעיף 19לה(2).
הסוגיה – חובת דיווח על קרות מקרה ביטוח – חוק חוזה הביטוח, התשמ״א–1981, סעיף 22.
הסוגיה – חובת מסירת מידע ומסמכים למבטח – חוק חוזה הביטוח, התשמ״א–1981, סעיף 2(ב).
הסוגיה – חובת המבטח למסור פוליסה למבוטח – חוק חוזה הביטוח, התשמ״א–1981, סעיף 2.
הסוגיה – חובת סוכן הביטוח – תקנות הפיקוח על שירותים פיננסיים (ביטוח) (בקשה לרישיון, הכשרה, התמחות ובחינות של סוכני ביטוח, יועצים פנסיוניים וסוכני שיווק פנסיוני), התשס״ו–2006.
הסוגיה – חובת גילוי מידע על ביטוח – פקודת ביטוח רכב מנועי [נוסח חדש], תש״ל–1970, סעיף 17.
```


## IL-453

### 1. legal_eval_plan (attempt 1, 16.1 s, tokens 135 in / 384 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Self-Defense (הגנה עצמית)",
      "law": "חוק ההגנה על המשפחה והבית - Perek HaHaga'a Al HaMishpacha VeHaBayit",
      "sections": ["1", "2", "3"]
    },
    {
      "issue": "Use of Force (שימוש בכוח)",
      "law": "חוק השימוש בכוח - Chukat HaShimmush BeKoch",
      "sections": ["1", "2"]
    },
    {
      "issue": "Criminal Liability for Excessive Force (אחריות פלילית לשימוש בכוח מופרז)",
      "law": "חוק העונשין - Chukat HaOnashin",
      "sections": ["36", "38", "43"]
    },
    {
      "issue": "Property Rights and Trespass (זכויות קניין ופלישה)",
      "law": "חוק המקרקעין - Chukat HaMekarakin",
      "sections": ["10", "27"]
    },
    {
      "issue": "Theft (גניבה)",
      "law": "חוק העונשין - Chukat HaOnashin",
      "sections": ["327", "328"]
    },
    {
      "issue": "Flight of the Intruder (בריחת הפורץ)",
      "law": "חוק העונשין - Chukat HaOnashin",
      "sections": ["16", "23"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.6 s, tokens 3146 in / 110 out, stop: stop)

**Output**

```text
הירי של בעל הבית לעבר פורץ – חוק העונשין, סעיף 327
הכניסה לבית הפורץ – חוק העונשין, סעיף 405
ההחזקה של שקית הרכוש על ידי הפורץ – חוק העונשין, סעיף 389
הפריצה וההתפרצות – חוק העונשין, סעיף 408
```


## IL-455

### 1. legal_eval_plan (attempt 1, 13.9 s, tokens 166 in / 322 out, stop: stop)

**Output**

```text
{
"issues": [
    {
        "issue": "Breach of Fiduciary Duty (אי מילוי חובת אמונים)",
        "law": "חוק השליחות, התשל" },{"issue": "Conflict of Interest (ניגוד עניינים)",
        "law": "חוק השליחות, התשל" },
    {
        "issue": "Fraudulent Conveyance/Undervaluation (העברה כוזבת/התחממות)",
        "law": "חוק הגנת עובדים, התשכ\"ח-1978 (potentially relevant if the transaction was designed to avoid creditors)" },
    {
        "issue": "Property Law - Transfer of Ownership (דיני מקרקעין - העברת בעלות)",
        "law": "חוק המקרקעין, התשל" },
    {
        "issue": "Registration in the Land Registry (רישום בטאבו)",
        "law": "חוק הטאבו, התשכ" },{"issue": "Potential for Civil Recourse (אפשרות לתביעה אזרחית)",
        "law": "חוק הפרוצדורה האזרחית, התשכ" },{"issue": "Possible Criminal Liability (אפשרות לאחריות פלילית)",
        "law": "חוק העונשין, התשכ" }]}
```

### 2. legal_eval_baseline (attempt 1, 12.3 s, tokens 3769 in / 184 out, stop: stop)

**Output**

```text
הסוגיה – הפרת חובת נאמנות של שלוח – חוק השליחות, סעיף 8.
הסוגיה – ניגוד עניינים בין השלוח לשולח – חוק השליחות, סעיף 8(3), (4), (5).
הסוגיה – מכירת נכס במחיר נמוך מהשוק – חוק הגנת הצרכן, סעיף 2(א)(13).
הסוגיה – עבירה על חוק העונשין בגין גניבת נכסים – חוק העונשין, סעיף 388.
הסוגיה – אפשרות לתביעה בגין הפרת חוזה – חוק השליחות, סעיף 8.
```


## IL-456

### 1. legal_eval_plan (attempt 1, 21.0 s, tokens 173 in / 512 out, stop: length)

**Output**

```text
{
"issues": [
    {
        "issue": "Transfer of Property as a Gift (Ha'avdat Matana) and its Impact on Marital Property",
        "law": "חוק שמירת זכויות משפחה (1980) - Chukat Shmirat Zchuyot Mishpacha (1980)",
        "sections": ["10", "12"]
    },
    {
        "issue": "Ownership Rights in Matrimonial Property (Kesuvin/Property Division)",
        "law": "חוק המשפחה (חלוקת רכוש) (1973) - Chukat HaMishpacha (Halukat Reshus) (1973)",
        "sections": ["3", "5", "7"]
    },
    {
        "issue": "Potential Claim of Unjust Enrichment (העשרה שלא כדין) by the Wife",
        "law": "General Principles of Civil Law (applicable through case law and the Civil Procedure Code)",
        "sections": []
    },
    {
        "issue": "The Parents' Right to Reclaim the Property Based on Abuse (Potential Tort Claim/Contractual Argument)",
        "law": "חוק הגנת נפגעי תקיפה מינית (1991) - Chukat Hagnat Nifge'i Takifa Minita (1991) (relevant if the abuse constitutes sexual assault) & General Tort Law principles",
        "sections": []
    },
    {
        "issue": "Validity of the Gift Transfer – Potential for Rescission (פגם בהעברה)",
        "law": "חוק החוזים (חלק כללי) (1973) - Chukat Ha'Hozim (Chelek Klali) (1973) (specifically regarding misrepresentation or duress)",
        "sections": ["13", "14"]
    },
    {
        "issue": "Impact of the Divorce Proceedings on Property Claims",
        "law": "חוק בתי הדין הרבניים (שיפוט דתי) (1953) - Chukat Beitey HaDin HaRabanin (Shifut Dati) (1953) (governing jurisdiction and procedure in
```

### 2. legal_eval_plan (attempt 2, 12.0 s, tokens 213 in / 290 out, stop: stop)

**Output**

```text
{"issues": [
    {"issue": "Transfer of Ownership & Gift Law (Hebrew: חוק מתנה)", "law": "חוק המתנה, תשכא-1978 (Chok HaMatana, Tashka-1978)", "sections": ["5", "13"]},
    {"issue": "Divorce and Equitable Distribution of Assets (Hebrew: חוק יחסי משפחה)", "law": "חוק יחסי משפחה, תשכ"
    },{"issue": "Abuse and Potential for Reversal of Gift (Hebrew: דיני נזיקין)", "law": "פקודת הנזיקין [נושאים בנזיקין], תשל"
    },{"issue": "Registration of Property (Hebrew: חוק המקרקעין)", "law": "חוק המקרקעין, תשל"
    },{"issue": "Parental Rights and Obligations (Hebrew: חוק הקטנים והבגירים)", "law": "חוק הקטנים והבגירים, תשכ"
    },{"issue": "Good Faith and Unjust Enrichment (Hebrew: עשיית עושר ולא מגיע)", "law": "עשיית עושר ולא מגיע, סעיף 1 לחוק הנזיקין"}
]}
```

### 3. legal_eval_baseline (attempt 1, 19.8 s, tokens 4254 in / 360 out, stop: stop)

**Output**

```text
הסוגיות המשפטיות העולות מהעובדות הן:

1.  העברת הדירה במתנה – חוק המתנה, תשכ״ח–1968, סעיף 1.
2.  אפשרות לחזור מהתחייבות למתנה – חוק המתנה, תשכ״ח–1968, סעיף 5(ב).
3.  התחייבות למתנה בהתנהגות מחפירה – חוק המתנה, תשכ״ח–1968, סעיף 5(ג).
4.  חלוקת רכוש בדין תרומה – חוק יחסי ממון בין בני זוג, תשל״ג–1973.
5.  סמכות בית הדין הרבני – חוק בית המשפט לעניני משפחה, התשנ״ה–1995, סעיף 1(6).
6.  אלימות במשפחה כעילה לביטול מתנה – חוק למניעת אלימות במשפחה, התשנ״א–1991.
7.  הגשת תביעה כספית ורכושית – תקנות סדר הדין האזרחי, התשמ״ד–1984, סעיף 258ז(1).
8.  העברת נכס ללא תמורה – תקנות הבטחת הכנסה, התשמ״ב–1982, סעיף 11.
```


## IL-461

### 1. legal_eval_plan (attempt 1, 21.2 s, tokens 156 in / 512 out, stop: length)

**Output**

```text
{ "issues": [
    {
      "issue": "Unfair Contract Terms - Automatic Renewal & High Cancellation Fees",
      "law": "חוק זכויות הצרכן, התשנ״א-1991 (Zchuyot HaTzorekh Law, 1991)",
      "sections": ["3", "8", "13", "16"]
    },
    {
      "issue": "Lack of Transparency & Misleading Practices in Contractual Terms",
      "law": "חוק זכויות הצרכן, התשנ״א-1991 (Zchuyot HaTzorekh Law, 1991)",
      "sections": ["1", "16"]
    },
    {
      "issue": "Forum Selection Clause (Mandatory Arbitration in a Distant City)",
      "law": "חוק בתי משפט, התשכ" },{"issue": "חוק זכויות הצרכן, התשנ״א-1991 (Zchuyot HaTzorekh Law, 1991)",
      "law": "חוק בתי משפט, התשכ" },{"issue": "חוק זכויות הצרכן, התשנ״א-1991 (Zchuyot HaTzorekh Law, 1991)",
      "law": "חוק בתי משפט, התשכ"
    },
    {
      "issue": "Consumer Protection against Unfair Business Practices",
      "law": "חוק הגנת הצרכן, התשנ״א-1991 (Hagana LeTzorekh Law, 1991)",
      "sections": ["5", "13"]
    },
    {
      "issue": "Contractual Validity - Potential for Unconscionability",
      "law": "חוק החוזים (חלק כללי), התשכ" },{"issue": "חוק זכויות הצרכן, התשנ״א-1991 (Zchuyot HaTzorekh Law, 1991)",
      "law": "חוק החוזים (חלק כללי), התשכ"
```

### 2. legal_eval_plan (attempt 2, 13.2 s, tokens 196 in / 328 out, stop: stop)

**Output**

```text
{"issues": [
    {"issue": "Unconscionability of Contract Terms (תנאי הפוגע)", "law": "חוק זכויות הצרכן, התשנ״א-1991", "sections": ["14", "33"]},
    {"issue": "Automatic Renewal Clauses (חידוש אוטומטי)", "law": "חוק זכויות הצרכן, התשנ״א-1991", "sections": ["14"]},
    {"issue": "Excessive Cancellation Fees (דמי ביטול מוגזמים)", "law": "חוק זכויות הצרכן, התשנ״א-1991", "sections": ["14", "33"]},
    {"issue": "Choice of Forum Clause (סעיף שיפוט)", "law": "חוק זכויות הצרכן, התשנ״א-1991", "sections": ["35"]},
    {"issue": "Standardized Contracts (חוזים אחידים)", "law": "חוק זכויות הצרכן, התשנ״א-1991", "sections": ["1", "14", "33"]},
    {"issue": "Consumer Protection & Misleading Practices (הגנת הצרכן והטעיה)", "law": "חוק זכויות הצרכן, התשנ״א-1991", "sections": ["5", "13"]}
]}
```

### 3. legal_eval_baseline (attempt 1, 13.8 s, tokens 5266 in / 194 out, stop: stop)

**Output**

```text
הסוגיה – חוזה אחיד והגבלת זכויות צרכניות – חוק החוזים האחידים, סעיף 2
הסוגיה – התחדשות אוטומטית של חוזה והטעיית צרכנים – חוק הגנת הצרכן, סעיף 2(א)
הסוגיה – דמי ביטול גבוהים – חוק הגנת הצרכן, סעיף 13ו(א)(1) ו-(2)
הסוגיה – הגבלת אפשרות התדיינות משפטית – חוק החוזים האחידים, סעיף 5(א)
הסוגיה – חיוב בתשלומים לאחר ביטול העסקה – חוק הגנת הצרכן, סעיף 31א(א)(2א)
```


## IL-468

### 1. legal_eval_plan (attempt 1, 20.3 s, tokens 161 in / 493 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Sexual Harassment in the Workplace",
      "law": "חוק למניעת הטרדה מינית, תשנ״ח-1998 (Sexual Harassment Prevention Law, 1998)",
      "sections": ["1", "3", "5", "7", "11", "13"]
    },
    {
      "issue": "Employer's Obligation to Address Harassment & Failure to Act",
      "law": "חוק למניעת הטרדה מינית, תשנ״ח-1998 (Sexual Harassment Prevention Law, 1998)",
      "sections": ["13", "14"]
    },
    {
      "issue": "Defamation/Damage to Reputation (Libel)",
      "law": "חוק איסור לשון הרע, תשנ״א-1991 (Defamation Law, 1991)",
      "sections": ["1", "2", "3", "5"]
    },
    {
      "issue": "Retaliation against the complainant (potential)",
      "law": "חוק למניעת הטרדה מינית, תשנ״ח-1998 (Sexual Harassment Prevention Law, 1998)",
      "sections": ["11", "13"]
    },
    {
      "issue": "Workplace Environment & Duty of Care",
      "law": "חוק הבטיחות והבריאות התעסוקתית, התשנ״ח-1998 (Occupational Safety and Health Law, 1998)",
      "sections": []
    },
    {
      "issue": "Potential for Breach of Contract/Employment Law (depending on employment terms)",
      "law": "חוק עבודת נשים, תשנ״א-1991 (Working Women's Law, 1991) & חוק שוויון השכר, התשנ״ח-1996 (Equal Pay Law, 1996)",
      "sections": []
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 21.1 s, tokens 7711 in / 317 out, stop: stop)

**Output**

```text
הטרדה מינית – חוק למניעת הטרדה מינית, התשנ״ח–1998, סעיף 3(א)
התנכלות – חוק למניעת הטרדה מינית, התשנ״ח–1998, סעיף 3(ב)
אחריות מעסיק – חוק למניעת הטרדה מינית, התשנ״ח–1998, סעיף 7(א)
חובת מעסיק לנקוט אמצעים – חוק למניעת הטרדה מינית, התשנ״ח–1998, סעיף 7(א)
הפרת חובת מעסיק – חוק למניעת הטרדה מינית, התשנ״ח–1998, סעיף 7(ב)
הליך תלונה – תקנות למניעת הטרדה מינית (חובות מעסיק), התשנ״ח–1998, סעיף 14
אחריות פלילית של המטריד – חוק העונשין, סעיפים 348, 349, 428
סמכות בית הדין לעבודה – חוק בית הדין לעבודה, תשכ״ט–1969, סעיף 24(ב)
```


## IL-470

### 1. legal_eval_plan (attempt 1, 10.7 s, tokens 153 in / 237 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Right to Access Information/Freedom of Information",
      "law": "חוק חופש המידע, תשנ"
      },
    {
      "issue": "Privacy Rights of Public Officials",
      "law": "חוק הגנת הפרטיות, תשנ"
      },
    {
      "issue": "Public Interest vs. Privacy Balance",
      "law": "חוק חופש המידע, תשנ"
      },
    {
      "issue": "Definition of 'Public Information'",
      "law": "חוק חופש המידע, תשנ"
      },
    {
      "issue": "Reasonableness of Municipal Decision",
      "law": "חוק הבטחת השירותים הממלכתיים, תשכ"
      },
    {
      "issue": "Potential for Judicial Review of Municipal Decision",
      "law": "חוק בתי המשפט, תשכ"
      }
    ]
  }
```

### 2. legal_eval_baseline (attempt 1, 12.0 s, tokens 5106 in / 152 out, stop: stop)

**Output**

```text
הסוגיה – חופש המידע, חוק חופש המידע, סעיף 8 ו-9.
הסוגיה – הגנת הפרטיות, חוק הגנת הפרטיות, סעיף 23ב.
הסוגיה – סמכות העירייה, צו המועצות המקומיות, סעיף 196.
הסוגיה – ענין הציבור, חוק חופש המידע, סעיף 10.
הסוגיה – סייג לאיסור מסירת מידע, חוק הגנת הפרטיות, סעיף 23ג.
```


## IL-483

### 1. legal_eval_plan (attempt 1, 15.0 s, tokens 146 in / 359 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Fraudulent Conveyance/Transfer of Assets to Avoid Creditors (העברת נכסים כדי להתחמק מנושים)",
      "law": "חוק חדלות פירעון, התשע״ב-2012 (Hotel Ha'adlut Pir'on, HaTash'a'at Bet-2012)",
      "sections": ["סעיפים 133-138 (Se'im 133-138) - specifically dealing with avoidance of transfers"]
    },
    {
      "issue": "Voidable Transactions (עסקאות שניתן לבטל)",
      "law": "חוק חדלות פירעון, התשע״ב-2012 (Hotel Ha'adlut Pir'on, HaTash'a'at Bet-2012)",
      "sections": ["סעיף 123 (Se'if 123) - General provisions regarding voidable transactions"]
    },
    {
      "issue": "Reporting Obligations Prior to Bankruptcy Filing (חובת דיווח לפני הגשת בקשת פשיטת רגל)",
      "law": "חוק חדלות פירעון, התשע״ב-2012 (Hotel Ha'adlut Pir'on, HaTash'a'at Bet-2012)",
      "sections": ["סעיף 93 (Se'if 93) - Regarding disclosure of assets and liabilities"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 15.3 s, tokens 5180 in / 230 out, stop: stop)

**Output**

```text
לא. העברת נכסים לקרובי משפחה לפני הגשת בקשת חדלות פירעון כדי להסתיר אותם מהנושים היא פעולה אסורה. חוק חדלות פירעון ושיקום כלכלי מאפשר לנאמן לדרוש העברת נכסים לידיו (סעיף 133). כמו כן, בית המשפט רשאי לאשר העברת סכומים או נכסים מנכסי קופת הנשייה לידי היחיד, אך רק אם הדבר מוצדק בנסיבות העניין (סעיף 165). ניסיון להתחמק מחובות באמצעות העברת נכסים לקרובי משפחה עלול להיחשב כהפרעה להליך חדלות הפירעון, דבר שעונשו עשוי להיות חמור. במקום זאת, מומלץ לפנות לייעוץ משפטי ולבחון אפשרויות להסדר חובות במסגרת הליך חדלות הפירעון.
```


## IL-484

### 1. legal_eval_plan (attempt 1, 7.3 s, tokens 128 in / 160 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Future Legislation Regarding Rental Fees",
"law": "חוק השכירות והשאילה (בטוחות)",
"sections": ["1", "13", "18", "30"]
},
{
"issue": "Potential Amendments to Existing Rental Law",
"law": "חוק השכירות והשאילה (בטוחות)",
"sections": ["1", "13", "18", "30"]
},
{
"issue": "Parliamentary Authority to Legislate",
"law": "חוק יסוד: הכנסת",
"sections": ["1", "4", "11"]
}
] }
```

### 2. legal_eval_baseline (attempt 1, 8.0 s, tokens 3521 in / 85 out, stop: stop)

**Output**

```text
לא. אין חוק שהכנסת תחוקק בשנה הבאה לגבי דמי שכירות. החוקים הקיימים, כגון חוק השכירות והשאילה, חוק הגנת הדייר וחוק נכסי נפקדים, קובעים את הכללים לגבי דמי שכירות, אך אין חוק חדש בתהליך חקיקה.
```


## IL-486

### 1. legal_eval_plan (attempt 1, 8.1 s, tokens 142 in / 177 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Contract Cancellation Due to Misrepresentation (Mistake)",
"law": "חוק החוזים (חלק כללי) – The Contract Law (General Part) Law",
"sections": ["13", "39"]
},
{
"issue": "Time Limit for Claiming Breach of Contract/Cancellation",
"law": "חוק החוזים (חלק כללי) – The Contract Law (General Part) Law",
"sections": ["23"]
},
{
"issue": "Interpretation of 'Precise' Time Limit",
"law": "חוק החוזים (חלק כללי) – The Contract Law (General Part) Law",
"sections": ["1", "3"]
}
] }
```

### 2. legal_eval_baseline (attempt 1, 8.9 s, tokens 3216 in / 112 out, stop: stop)

**Output**

```text
לא, אין לבטל חוזה בשל הטעיה תוך 30 יום בדיוק. סעיף 15 לחוק החוזים (חלק כללי) מאפשר ביטול חוזה עקב טעות שהיא תוצאה של הטעיה, אך אינו קובע תקופת זמן מוגדרת לביטול. הביטול צריך להיעשות תוך זמן סביר לאחר שנודע על עילת הביטול (סעיף 20).
```


## IL-487

### 1. legal_eval_plan (attempt 1, 8.5 s, tokens 147 in / 192 out, stop: stop)

**Output**

```text
{ "issues": [
    {
      "issue": "Entitlement to Advance Notice of Termination (Severance Pay)",
      "law": "חוק הודעה מוקדמת לפיטורים",
      "sections": ["1", "2", "3"]
    },
    {
      "issue": "Definition of 'Veteran Employee' (Relevant for Notice Period Calculation)",
      "law": "חוק עבודת המגן (הגנה על עובדים מפני פיטורים הולמים)",
      "sections": ["1", "2"]
    },
    {
      "issue": "Contractual Override/Agreements (Potential for a more favorable agreement)",
      "law": "חוק החוזים (חלק כללי)",
      "sections": ["14", "30"]
    }
  ]
}
```

### 2. legal_eval_baseline (attempt 1, 8.8 s, tokens 4072 in / 95 out, stop: stop)

**Output**

```text
לא, לפי חוק הודעה מוקדמת לפיטורים ולהתפטרות, התשס״א–2001, עובד במשכורת זכאי להודעה מוקדמת לפיטורים בהתאם לתקופת העסקתו. עובד ותיק, לאחר שנת עבודתו הראשונה, זכאי לחודש ימים של הודעה מוקדמת.
```


## IL-493

### 1. legal_eval_plan (attempt 1, 9.3 s, tokens 134 in / 210 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Determination of Damages in Tort Law (specifically, hospital stay compensation)",
"law": "פקודת הנזיקין (Pekudat HaNazikin) - The Torts Ordinance",
"sections": ["7", "9", "37"]
},
{
"issue": "Calculation of Daily Compensation Amounts",
"law": "חוק הפיצויים לנפגעי תאונות דרכים (Chok HaPitzuyim LeNefge'i Ta'onot Derechim) - The Victims of Road Accidents Compensation Law",
"sections": ["9"]
},
{
"issue": "General Principles of Damages Calculation in Civil Law",
"law": "חוק הפרוצדורה האזרחית (Chok HaProzedura HaAzirit) - The Civil Procedure Code",
"sections": ["220", "221"]
}
] }
```

### 2. legal_eval_baseline (attempt 1, 11.1 s, tokens 5825 in / 116 out, stop: stop)

**Output**

```text
לא. פקודת הנזיקין אינה קובעת פיצוי קבוע ליום אשפוז. סעיף 4(א) לחוק פיצויים לנפגעי תאונות דרכים קובע כי על זכותו של נפגע לפיצוי על נזק גוף יחולו הוראות סעיפים 19 עד 22, 76 עד 83, 86, 88 ו-89 לפקודת הנזיקין.
```


## IL-496

### 1. legal_eval_plan (attempt 1, 8.9 s, tokens 123 in / 201 out, stop: stop)

**Output**

```text
{ "issues": [
{
"issue": "Access to Court Decisions & Transparency",
"law": "חוק בית המשפט העליון, תשנ״ט-1999 (Supreme Court Law, 1999)",
"sections": ["4", "5", "11"]
},
{
"issue": "Right to Information/Public Records",
"law": "חוק חופש המידע, תשנ״ח-1998 (Freedom of Information Act, 1998)",
"sections": ["5", "6", "10"]
},
{
"issue": "Standing to Inquire/Judicial Review Process",
"law": "חוק בתי משפט, תשכ״ז-1967 (The Courts Law, 1967)",
"sections": ["49", "50"]
}
] }
```

### 2. legal_eval_baseline (attempt 1, 9.3 s, tokens 4837 in / 93 out, stop: stop)

**Output**

```text
אני מצטער, אין במידע שסופק תשובה לשאלה. העתירה שהגשת אתמול היא הליך משפטי ספציפי, ואין לי גישה לפרטים לגביה. כדי לדעת מה החליט בית המשפט העליון בעתירה שלך, תצטרך לבדוק את פסק הדין או לפנות לבית המשפט.
```


## case_01

### 1. legal_eval_baseline (attempt 1, 81.2 s, tokens 8645 in / 1735 out, stop: stop)

**Output**

```text
בסדר גמור. הנה תיק העבודה כפי שביקשת:

**1. תקציר עובדתי**

מיכל לוי, עובדת בטק-פלוס בע"מ כבודקת תוכנה, הודיעה למעסיק על הריונה ב-10.6.2026. כתוצאה מכך, הועברה לעבודה חלקית (60%) ב-15.7.2026, לכאורה עקב האטה בפרויקט, למרות שעובדים אחרים לא קוצצו. ב-5.8.2026 נערך לה שימוע, בו הועלו טענות ביצועים שלא הוכחו בכתב. ב-10.8.2026 קיבלה מכתב פיטורים, שהכנסו לתוקף ב-10.9.2026. מיכל טוענת שהפיטורים קשורים להריונה ואינה יודעת אם המעסיקה קיבלה היתר ממשרד העבודה. משכורת אוגוסט שולמה לה רק ב-12.9.2026. על פי הסכם העסקה, שכר מיכל החודשי הוא 13,000 ש"ח, והמעסיקה מפנה ל"חוק פיצויי פיטורים" בנוגע לפיצויי פיטורים. משוב שנתי מ-ינואר 2026 מציין את רמתה המקצועית הגבוהה ואת המלצה לקידום. הודעת וואטסאפ מאורי, מנהל הצוות, מרמזת על כך שההריון מהווה בעיה מבחינת זמינותה.

**2. ציר זמן**

| תאריך | אירוע | מקור |
|---|---|---|
| 1.3.2024 | תחילת העסקה | מסמך 2 |
| 10.6.2026 | הודעה על הריון | מסמך 7 |
| 15.7.2026 | קיצוץ משרה ל-60% | מסמך 1 |
| 3.8.2026 | זימון לשימוע | מסמך 1 |
| 5.8.2026 | שימוע | מסמך 1 |
| 10.8.2026 | קבלת מכתב פיטורים | מסמך 5 |
| 12.9.2026 | תשלום משכורת אוגוסט | מסמך 6 |
| 20.9.2026 | תאריך קבלת התיק | - |

**3. סוגיות משפטיות**

*   **פיטורי עובדת בהריון:** סעיף 9(א) לחוק עבודת נשים, תשי"ד-1954, קובע כי מעסיק לא רשאי לפטר עובדת בהריון ללא היתר משר העבודה והרווחה. נראה כי הפיטורים בוצעו בניגוד להוראה זו, שכן לא הוצג היתר.
*   **אפליה מחמת הריון:** סעיף 9(א) לחוק עבודת נשים, תשי"ד-1954, קובע כי פיטורים בקשר להריון אינם חוקיים. הודעת הוואטסאפ של אורי מעלה חשד לאפליה.
*   **הודעה מוקדמת:** סעיף 3 לחוק הודעה מוקדמת לפיטורים ולהתפטרות, התשס"א-2001, קובע את תקופת ההודעה המוקדמת הנדרשת. בהתבסס על תקופת העסקתה, מיכל זכאית להודעה מוקדמת של חודש ימים.

**4. מועדים ודחיפות**

*   **התיישנות:** תביעה לפיטורים שלא כדין מתיישנת תוך שנה ויום אחד ממועד הפיטורים (סעיף 9(ג) לחוק עבודת נשים). מועד התיישנות: 11.9.2027.
*   **מועדים דיוניים:** בהתאם למועד ההתיישנות, יש לפעול במהירות.
*   **מועדים חוזיים:** אין מועדים חוזיים רלוונטיים מעבר לתאריך הפיטורים.
*   **דחיפות:** התיק דחוף ביותר, לאור מועד ההתיישנות הקרוב.

**5. סתירות וסימני אזהרה**

*   השימוע לא תועד בכתב, וטענות הביצועים לא הוצגו למיכל.
*   ההודעה על קיצוץ המשרה והפיטורים מגיעות זמן קצר לאחר הודעת ההריון.
*   הודעת וואטסאפ מאורי מרמזת על קשר בין ההריון לפיטורים.
*   התלוש שכר מראה כי מיכל קיבלה רק 60% משכרה.
*   עמודים 2-3 של הסכם העסקה חסרים.

**6. מידע ומסמכים חסרים**

*   יש לבקש מהלקוחה את הסכם העסקה המלא.
*   יש לבקש את כל ההתכתבויות בין מיכל לאורי בנוגע לפיטורים.
*   יש לבקש מסמכים המעידים על ביצועיה של מיכל.
*   יש לבדוק האם המעסיקה ביקשה היתר לפיטורים ממשרד העבודה.

**7. טיוטת מסמך**

(טיוטה ראשונית - יש להתאים ולשפר בהתאם למידע נוסף)

[תאריך]

טק-פלוס בע"מ
[כתובת]

**הנדון: דרישה לבטול פיטורים ולהשיב את היקף המשרה של מיכל לוי**

לכבוד המעסיקים הנכבדים,

מכתב זה נשלח בשם מרשתי, מיכל לוי, עובדת לשעבר בחברתכם.

אנו סבורים כי פיטורי מרשתי, אשר הוכרזו ב-10.8.2026 והכנסו לתוקף ב-10.9.2026, נעשו באופן בלתי חוקי ומהווים הפרה של חוק עבודת נשים, התשי"ד-1954.

אנו דורשים מכם לבטל את הפיטורים, להשיב את היקף משרתה המקורי ולשמור על כל הראיות הקשורות לפיטורים.

אנו מבקשים לקבל תשובה בכתב תוך 14 יום.

בכבוד רב,
[שם עורך הדין]

**8. המלצה לצעד הבא**

יש לפנות בדחיפות למעסיקה ולדרוש הסבר מפורט על נסיבות הפיטורים. יש לבדוק את האפשרות להגיש תלונה למשרד העבודה, הרווחה והשירותים החברתיים. יש להשלים את קבלת המסמכים החסרים מהלקוחה.
```


## case_02

### 1. legal_eval_baseline (attempt 1, 89.7 s, tokens 8359 in / 1946 out, stop: stop)

**Output**

```text
בסדר גמור, הנה תיק העבודה כפי שביקשת:

**1. תקציר עובדתי**

יוסי כהן שכר דירה מאבי דהן ב-25.8.2025 לתקופה של שנה. על פי החוזה, יוסי אחראי לתשלום ועד הבית, ביטוח מבנה ותשלומים מיוחדים לשיפוץ הבניין. הוא הפקיד פיקדון של 13,000 ש"ח וערבות בנקאית של 19,500 ש"ח. במהלך תקופת השכירות, הייתה נזילה מהתקרה בחדר השינה, עליה יוסי דיווח למשכיר. לאחר שהמשכיר לא טיפל בבעיה בזמן סביר, יוסי הזמין אינסטלטור על חשבונו בסך 1,800 ש"ח. ב-1.5.2026 שילם יוסי 2,400 ש"ח לוועד הבית עבור היטל חד פעמי לשיפוץ המעלית. עם סיום תקופת השכירות ב-31.8.2026, אבי מעכב את החזר הפיקדון, בטענה להוצאות צביעה (4,500 ש"ח), שריטות בפרקט (3,000 ש"ח) ו"בלאי כללי" (1,500 ש"ח). אבי מציין כי יחזיר את היתרה (4,000 ש"ח) לאחר בדיקת חשבונות החשמל, והערבות הבנקאית תוחזר בנפרד. יוסי מסר את המפתחות ב-31.8.2026 ושילם את כל חשבונות החשמל, המים והארנונה.

**2. ציר זמן**

| תאריך | אירוע | מקור |
|---|---|---|
| 25.8.2025 | חתימת חוזה שכירות | מסמך 1 |
| 1.9.2025 | תחילת תקופת השכירות | מסמך 1 |
| 3.2.2026 | דיווח על נזילה מהתקרה | מסמך 2 |
| 20.2.2026 | המשך דיווח על נזילה | מסמך 2 |
| 10.3.2026 | הזמנת אינסטלטור על ידי השוכר | מסמך 2 |
| 1.5.2026 | תשלום לוועד הבית | מסמך 3 |
| 20.3.2026 | הודעה על סיום הטיפול בנזילה | מסמך 2 |
| 31.8.2026 | מסירת מפתחות | מסמך 5 |
| 15.9.2026 | הודעה על עיכוב החזר פיקדון | מסמך 4 |
| 21.9.2026 | תרשומת שיחה עם הלקוח | מסמך 5 |
| 22.9.2026 | תאריך קבלת התיק | - |

**3. סוגיות משפטיות**

*   **חוק השכירות והשאילה, סעיף 25ח:** השוכר אחראי לתיקון ליקויים בדירה, אך המשכיר אחראי לתיקון פגמים שאינם נגרמים משימוש בלתי סביר. העיכוב בטיפול בנזילה מעלה שאלה האם המשכיר עמד בהתחייבויותיו.
*   **חוק השכירות והשאילה, סעיף 7:** המשכיר חייב לתקן פגמים במושכר, ואי עשיית כן מזכה את השוכר בתרופות.
*   **חוק השכירות והשאילה, סעיף 25י(ב):** גובה הערובה מוגבלת, וייתכן שהדרישה של אבי להשאיר את הפיקדון מעבר לגבול המותר מהווה הפרה של החוק.
*   **תקנות הדיור המוגן (טופס מסמך גילוי), סעיף 9(ג):** קובע מועד להשבת הפיקדון.

**4. מועדים ודחיפות**

*   **התיישנות:** תביעה כספית נגד המשכיר מתיישנת תוך 7 שנים (חוק ההתיישנות, תשי"ב-1952).
*   **החזר פיקדון:** לפי תקנות הדיור המוגן, הפיקדון צריך להיות מוחזר תוך זמן סביר.
*   **דחיפות:** החזר הפיקדון הוא הנושא הדחוף ביותר, שכן המשכיר מעכב את החזר הכספים בצורה לא חוקית.

**5. סתירות וסימני אזהרה**

*   **פרוטוקול מסירה:** העדר פרוטוקול מסירה חתום במועד הכניסה.
*   **הוצאות:** אבי דהן טוען להוצאות צביעה, שריטות בפרקט ובלאי כללי, ללא הצגת קבלות או הוכחות.
*   **מצב הדירה:** יוסי כהן טוען שהדירה לא הייתה צבועה טרי בכניסה.

**6. מידע ומסמכים חסרים**

*   **פרוטוקול מסירה:** יש לבקש מהלקוח עותק של פרוטוקול המסירה, אם קיים.
*   **קבלה מהאינסטלטור:** יש לבקש מהלקוח להעביר את הקבלה מהאינסטלטור.
*   **הצעות מחיר:** יש לבקש מאבי דהן להציג הצעות מחיר וחשבוניות עבור הצביעה, תיקון הפרקט וה"בלאי הכללי".
*   **תמונות:** יש לבקש מאבי דהן להציג תמונות של הנזקים הנטענים.

**7. טיוטת מסמך**

(מכתב התראה למשכיר)

[תאריך]

אבי דהן
[כתובת]

**הנדון: דרישה להשבת פיקדון – חוזה שכירות לדירה ב[כתובת הדירה]**

שלום רב,

הנדון מכתב התראה בדרישה להשבת פיקדון ששולם על ידי מר יוסי כהן, שוכר בדירה המצויה ב[כתובת הדירה], בהתאם לחוזה שכירות מ-25.8.2025.

מר כהן מסר את הדירה ב-31.8.2026 ושילם את כל החשבונות הנדרשים. למרות זאת, קיבל מר כהן הודעה מטעמך בדבר עיכוב בהשבת הפיקדון, בטענה להוצאות צביעה, תיקון פרקט ובלאי כללי.

אנו סבורים כי דרישתך להשאיר את הפיקדון מעבר לסכום המותר על פי דין מהווה הפרה של החוק. אנו דורשים ממך להחזיר את הפיקדון במלואו, בסך 13,000 ש"ח, תוך 14 יום ממועד קבלת מכתב זה.

אנו מזהירים כי במידה ולא תעמוד בדרישה זו, נפעל למימוש זכויותיו של מר כהן בדרכים המשפטיות העומדות לרשותנו.

בכבוד רב,
[שם עורך הדין]

**8. המלצה לצעד הבא**

יש לפנות לאבי דהן באמצעות מכתב ההתראה, כפי שנוסח בטיוטה. במקביל, יש לאסוף את כל המסמכים החסרים מהלקוח ולבחון את האפשרות להגיש תביעה לבית המשפט במידה ולא יוחזר הפיקדון.
```


## case_03

### 1. legal_eval_baseline (attempt 1, 80.2 s, tokens 7380 in / 1745 out, stop: stop)

**Output**

```text
## תיק עבודה – רונית אברהם מול "ספות בקליק"

**תאריך קבלת התיק:** 23.9.2026

### 1. תקציר עובדתי

רונית אברהם הזמינה בסביבות ה-2.9.2026 באתר "ספות בקליק" ספה תלת-מושבית דגם "מילאנו" עור אמיתי במחיר 4,900 ש"ח כולל משלוח. הספה נמסרה ללקוחה ב-8.9.2026. הלקוחה טוענת שהספה אינה עור אמיתי כפי שפורסם באתר, וביטלה את העסקה. העוסק, "ספות בקליק", דורש תשלום של 15% דמי ביטול (735 ש"ח) ו-350 ש"ח דמי איסוף, בהתבסס על סעיף 9 בתקנון האתר הקובע כי "רהיטים אינם ניתנים לביטול". הלקוחה לא זוכרת אם קיבלה מסמך נפרד עם פרטי העסקה וזכות הביטול.

### 2. ציר זמן

| תאריך | אירוע | מקור |
|---|---|---|
| 2.9.2026 | הזמנת הספה באתר | מסמך 1 |
| 2.9.2026 | צילום מסך של עמוד המוצר | מסמך 2 |
| 8.9.2026 | מסירת הספה ללקוחה | מסמך 3 |
| 15.9.2026 | צילום תווית הספה | מסמך 4 |
| 17.9.2026 | מייל ביטול מהלקוחה לעוסק | מסמך 5 |
| 18.9.2026 | תשובת העוסק ללקוחה | מסמך 6 |
| 22.9.2026 | תרשומת שיחה עם הלקוחה | מסמך 7 |

### 3. סוגיות משפטיות

*   **הטעיה בניגוד לחוק הגנת הצרכן, סעיף 32:** הלקוחה טוענת להטעיה מצד העוסק בנוגע לחומר הריפוד של הספה. אם יוכח שהספה אינה עור אמיתי כפי שפורסם, הלקוחה עשויה להיות זכאית לביטול העסקה.
*   **זכות הביטול לפי חוק הגנת הצרכן, סעיף 14ג:**  עסקת המכר היא עסקה מרחוק, ולכן הלקוחה זכאית לביטול בתוך 14 יום מקבלת הנכס.
*   **תקנון האתר וחוקיות דמי הביטול לפי תקנות הגנת הצרכן (ביטול עסקה), סעיף 5:** דרישת העוסק לגביית 15% דמי ביטול ודמי איסוף עשויה להיות בלתי חוקית, בהתאם לתקנות.
*   **הגבלת זכות הביטול לפי תקנות הגנת הצרכן (ביטול עסקה), סעיף 6(א):** סעיף 6(א) מגביל את זכות הביטול עבור רהיטים שהורכבו בבית הצרכן או יוצרו במיוחד לפי דרישות מיוחדות. יש לבדוק האם הספה יוצרה במיוחד עבור הלקוחה.

### 4. מועדים ודחיפות

*   **מועד התיישנות:** חוק הגנת הצרכן אינו קובע מועד התיישנות מפורש. עם זאת, סביר להניח שבית המשפט יקבע מועד סביר בהתאם לנסיבות המקרה.
*   **מועד דיוני:** בהתאם לכללים, יש להגיש כתב תביעה תוך 90 יום מקבלת התיק.
*   **מועד חוזי:** העוסק דורש תשלום של 735 ש"ח + 350 ש"ח.
*   **דחיפות:** יש לפעול במהירות כדי למנוע גביית סכומים נוספים מהלקוחה.

### 5. סתירות וסימני אזהרה

*   **סתירה:** פרסום באתר מציין "עור אמיתי" בעוד שתווית הספה מציינת "עור אקולוגי (PU)".
*   **מסמכים חסרים:** הלקוחה לא זוכרת אם קיבלה מסמך נפרד עם פרטי העסקה וזכות הביטול.
*   **תקנון האתר:** סעיף 9 בתקנון האתר סותר לכאורה את זכות הצרכן לביטול עסקה.

### 6. מידע ומסמכים חסרים

*   **העתק של התקנון המלא של "ספות בקליק":** כדי לבדוק את כל הסעיפים הרלוונטיים.
*   **ההקלטה של שיחת הטלפון עם העוסק:** כדי להבין את נסיבות הביטול.
*   **הודעה מפורטת מהלקוחה לגבי הנסיבות שהובילו להזמנה:** כדי להבין את הציפיות שלה.

### 7. טיוטת מסמך

(להלן הטיוטה, יש להתאים אותה לנסיבות הספציפיות של התיק)

**הודעת ביטול ודרישה להשבה**

לכבוד: "ספות בקליק" – מ.ק. ריהוט בע"מ

הנדון: ביטול הזמנה מספר 58812 ודרישה להשבה

הרינו מודיעים בזאת על ביטול העסקה שנעשתה ב-2.9.2026 לרכישת ספה תלת-מושבית דגם "מילאנו".

הספה נמסרה ב-8.9.2026, ולאחר בדיקתה התברר כי חומר הריפוד אינו עור אמיתי כפי שפורסם באתר, אלא עור אקולוגי (PU). לכן, אנו מבטלים את העסקה ומבקשים החזר מלא של הסכום ששולם, וכן איסוף הספה על ידכם.

אנו דוחים את דרישתכם לגביית דמי ביטול ודמי איסוף, שכן היא אינה חוקית.

אנו מצפים לקבל את הסכמתכם לביטול העסקה ולביצוע הפעולות הנדרשות בהתאם לחוק הגנת הצרכן.

בכבוד רב,

רונית אברהם

### 8. המלצה לצעד הבא

1.  יש להשיג את התקנון המלא של "ספות בקליק" כדי לבחון את תוקף סעיף 9.
2.  יש לפנות לעוסק בכתב, תוך ציון הטיוטה, ולדרוש הסרה מיידית של החיוב.
3.  יש לשקול פנייה לרשות להגנת הצרכן.
```


## case_04

### 1. legal_eval_baseline (attempt 1, 92.2 s, tokens 9840 in / 1968 out, stop: stop)

**Output**

```text
בסדר גמור. הנה תיק העבודה כפי שביקשת:

**תיק עבודה – עסקאות נוגדות בדירה**

**1. תקציר עובדתי:**

דוד ושרה מזרחי חתמו על הסכם מכר לדירה ברחוב הגפן 12, חיפה, ב-5.5.2026, תמורת 1,600,000 ש"ח. שילמו 400,000 ש"ח במעמד החתימה, ומועד מסירת החזקה נקבע ל-1.10.2026. נרשמה הערת אזהרה לטובתם ב-14.7.2026. עם זאת, נסח רישום מקרקעין מ-12.9.2026 מצביע על קיום משכנתה לבנק אופק והערת אזהרה קודמת לטובת נועה פרץ, שנרשמה ב-22.6.2026. נועה פרץ טוענת שחתמה על הסכם לרכישת הדירה ב-20.6.2026, שילמה 900,000 ש"ח, ובדקה את הרישום ב-19.6.2026. המוכר, אלון בר, אינו זמין ליצירת קשר, ולפי שכנים טס לחו"ל. הלקוחות קיבלו משכנתה עקרונית של 1,000,000 ש"ח. עו"ד ק., עורך הדין הקודם, הודיע ללקוחות שההערה תירשם תוך יומיים, אך בפועל נרשמה רק ב-14.7.2026.

**2. ציר זמן:**

| תאריך | אירוע | מקור |
|---|---|---|
| 5.5.2026 | חתימת הסכם מכר בין דוד ושרה מזרחי לאלון בר | מסמך 1 |
| 5.5.2026 | העברה בנקאית של 400,000 ש"ח | מסמך 2 |
| 20.6.2026 | נועה פרץ חותמת על הסכם לרכישת הדירה (לטענתה) | מסמך 4 |
| 22.6.2026 | רישום הערת אזהרה לטובת נועה פרץ | מסמך 3 |
| 14.7.2026 | רישום הערת אזהרה לטובת דוד ושרה מזרחי | מסמך 3 |
| 1.7.2026 | הודעת SMS מהמוכר לדוד | מסמך 5 |
| 10.9.2026 | קבלת מכתב מעו"ד של נועה פרץ | מסמך 4 |
| 12.9.2026 | הפקת נסח רישום מקרקעין | מסמך 3 |
| 20.9.2026 | פגישה עם הלקוחות | מסמך 5 |
| 21.9.2026 | תאריך קבלת התיק | - |

**3. סוגיות משפטיות:**

*   **עסקאות נוגדות והבטחת השקעות של רוכשי דירות:** חוק המכר (דירות) (הבטחת השקעות של רוכשי דירות), תשל״ה–1974, סעיף 2(4) קובע כי המוכר חייב לרשום הערת אזהרה לטובת הקונים כדי למנוע עסקאות נוגדות. העובדה שהערת אזהרה נרשמה רק ב-14.7.2026 מעלה שאלות לגבי תקינות העסקה.
*   **תקופת הבדק לאי-התאמה יסודית:** חוק המכר (דירות), תשל״ג–1973, סעיף 4(א)(3) קובע תקופת בדק לאי-התאמה יסודית של 20 שנה. יש לבדוק האם קיימת אי-התאמה יסודית בדירה.
*   **הפרת חובות המוכר:** חוק המכר (דירות) (הבטחת השקעות של רוכשי דירות), תשל״ה–1974, סעיף 4ב(א) קובע עיצומים כספיים על הפרת חובות המוכר, כגון אי-דיווח לממונה או אי-מתן בטוחה לרוכש.

**4. מועדים ודחיפות:**

*   **תקופת ההתיישנות:** בהתאם לחוק המכר (דירות), תשל״ג–1973, יש לבדוק את תקופות ההתיישנות הרלוונטיות לתביעות אפשריות.
*   **מועד מסירה:** 1.10.2026. מועד קריטי הדורש טיפול מיידי.
*   **דחיפות:** רישום הערת אזהרה מאוחרת, העובדה שהמוכר אינו זמין, והתקרבות מועד המסירה הופכים את הטיפול בתיק לדחוף ביותר.

**5. סתירות וסימני אזהרה:**

*   **רישום הערת אזהרה מאוחרת:** העיכוב ברישום הערת האזהרה מעלה שאלות לגבי כוונותיו של המוכר.
*   **הסכם עם נועה פרץ:** קיום הסכם קודם עם נועה פרץ יוצר מצב של עסקאות נוגדות.
*   **היעדר המוכר:** היעדר המוכר מהארץ מעכב את קבלת מידע רלוונטי.
*   **ייפוי כוח חסר חתימה:** נספח ב' להסכם המכר (ייפוי כוח) חסר חתימת המוכר.

**6. מידע ומסמכים חסרים:**

*   **הסכם עם נועה פרץ:** יש לקבל עותק של ההסכם שנחתם עם נועה פרץ.
*   **ייפוי כוח חתום:** יש לדרוש ייפוי כוח חתום מהמוכר.
*   **הסבר מהמוכר:** יש לנסות ליצור קשר עם המוכר ולקבל הסבר לגבי העיכוב ברישום הערת האזהרה וההסכם עם נועה פרץ.
*   **בדיקת משכנתה:** יש לבדוק את תנאי המשכנתה לבנק אופק.

**7. טיוטת מסמך:**

(רשימת בקשות לבית המשפט - טיוטה ראשונית)

לכבוד בית המשפט המחוזי בחיפה

רשימת בקשות

1.  הוצאת צו מניעה האוסר על אלון בר לבצע כל פעולה בנכס המצוי ברחוב הגפן 12, חיפה, עד להכרעה סופית בעניין.
2.  הוצאת צו להעברת הבעלות בדירה לדוד ושרה מזרחי.
3.  הוצאת צו להורות על ביטול ההסכם עם נועה פרץ.
4.  הוצאת צו להורות על רישום הערת אזהרה לטובת דוד ושרה מזרחי.

**8. המלצה לצעד הבא:**

1.  **ניסיון דחוף ליצירת קשר עם המוכר:** יש לפנות למשטרה במידת הצורך.
2.  **הגשת בקשה לצו מניעה:** כדי למנוע פעולות נוספות מצד המוכר ונועה פרץ.
3.  **בדיקת אפשרות להגשת תלונה במשטרה:** עקב היעדר המוכר וההתנהלות החשודה.
4.  **הכנת תביעה לבית המשפט:** תוך צירוף כל המסמכים הרלוונטיים.
```


## case_05

### 1. legal_eval_baseline (attempt 1, 68.5 s, tokens 7833 in / 1450 out, stop: stop)

**Output**

```text
בסדר גמור, הנה תיק העבודה כפי שביקשת:

**תיק עבודה – התנגדות לקיום צוואה**

**1. תקציר עובדתי:**

אברהם גולן נפטר ב-2.8.2026 בגיל 87. ב-12.5.2019 נערכה צוואה בעדים, המורישה את כל רכושו לשלושת ילדיו בחלקים שווים. ב-1.3.2026 נכתבה "צוואה" נוספת בכתב יד, המורישה את הדירה למטפלת, מרינה ק., וכל השאר לילדים. חוות דעת גרפולוגית ראשונית מצביעה על כך שכתב היד ב"צוואה" השנייה אינו תואם לכתב ידו של המנוח. ב-8.2.2026, סיכום ביקור אצל רופאת משפחה מציין ירידה קוגניטיבית מתונה. הלקוחות, יעל, תמר ורון גולן, ילדי המנוח, מתנגדים לקיום הצוואה השנייה. רחל גולן, האלמנה, מבקשת להמשיך לגור בדירה. המנוח חולק חשבון בנק משותף עם רחל, ובו 180,000 ש"ח.

**2. ציר זמן:**

| תאריך | אירוע | מקור |
|---|---|---|
| 12.5.2019 | נערכה צוואה בעדים | מסמך 1 |
| 8.2.2026 | סיכום ביקור אצל רופאת משפחה | מסמך 4 |
| 1.3.2026 | נכתבה "צוואה" בכתב יד | מסמך 2 |
| 15.9.2026 | פורסמה הודעה על בקשה לקיום צוואה | מסמך 5 |
| 15.9.2026 | חוות דעת גרפולוגית ראשונית | מסמך 3 |
| 21.9.2026 | תרשומת פגישה עם הילדים | מסמך 6 |
| 22.9.2026 | תאריך קבלת התיק | - |

**3. סוגיות משפטיות:**

*   **תוקף הצוואה השנייה:** חוק הירושה, סעיף 66 – צוואה בכתב יד אינה חייבת להיות נוכחת בפני עדים, אך יש לבדוק את תוקפה לאור חוות הדעת הגרפולוגית והירידה הקוגניטיבית של המנוח.
*   **השפעת הירידה הקוגניטיבית:** חוק הירושה, סעיף 67 – יש לבדוק האם הירידה הקוגניטיבית של המנוח השפיעה על כשרויותו בעת כתיבת הצוואה השנייה.
*   **השפעת המטפלת:** חוק הירושה, סעיף 67 – יש לבדוק את מעורבותה של המטפלת, מרינה ק., בכתיבת הצוואה השנייה והשפעתה על המנוח.
*   **התנגדות לבקשה:** תקנות הירושה, התשנ״ח–1998 סעיף 19 – יש להגיש התנגדות לבקשה לקיום הצוואה בתוך המועד הקבוע בדין.

**4. מועדים ודחיפות:**

*   **מועד להגשת התנגדות:** 14 ימים מיום המצאת ההודעה על הבקשה לקיום הצוואה (פורסמה ב-15.9.2026), כלומר עד 29.9.2026. **דחוף ביותר.**
*   **מועדי התיישנות:** אין מועדי התיישנות רלוונטיים בשלב זה.
*   **מועדים דיוניים:** תלוי בהחלטת בית הדין/בית המשפט.
*   **מועדים חוזיים:** אין מועדים חוזיים רלוונטיים.

**5. סתירות וסימני אזהרה:**

*   **סתירה בין הצוואות:** הצוואה הראשונה מורישה את הכל לילדים, בעוד הצוואה השנייה מורישה את הדירה למטפלת.
*   **חוות דעת גרפולוגית לא חתומה:** יש לבקש חוות דעת גרפולוגית חתומה ומפורטת יותר.
*   **השפעת המטפלת:** טענות הילדים על כך שהמטפלת שלטה בטלפון של אביהם ו"לא אפשרה" להם לבקר מעלות חשד.
*   **מסמכים חסרים:** חסרה הצוואה המקורית.

**6. מידע ומסמכים חסרים:**

*   **חוות דעת גרפולוגית חתומה ומפורטת.**
*   **העתק של הצוואה המקורית.**
*   **תיעוד רפואי מפורט יותר לגבי מצבו הקוגניטיבי של המנוח.**
*   **ראיונות עם המנוח, המטפלת, רחל גולן והילדים.**

**7. טיוטת מסמך:**

(טיוטת שלד להתנגדות לקיום הצוואה משנת 2026 ורשימת ראיות יצורפו כנספח נפרד).

**8. המלצה לצעד הבא:**

1.  יש לפעול בדחיפות להגשת התנגדות לבקשה לקיום הצוואה עד 29.9.2026.
2.  יש לפנות ללקוחות ולבקש מהם את המסמכים החסרים.
3.  יש להזמין חוות דעת גרפולוגית חתומה ומפורטת.
4.  יש לברר את מעורבותה של המטפלת בכתיבת הצוואה השנייה.
```

