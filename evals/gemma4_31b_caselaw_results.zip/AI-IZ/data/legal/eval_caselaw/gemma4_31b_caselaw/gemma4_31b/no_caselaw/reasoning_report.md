# LLM trace

| call site | calls | seconds | stopped on length | errors |
|---|---|---|---|---|
| legal_eval_plan | 105 | 1052 | 0 | 0 |
| legal_eval_scope | 100 | 372 | 0 | 0 |

## IL-483

### 1. legal_eval_scope (attempt 1, 4.9 s, tokens 284 in / 32 out, stop: stop)

**Output**

```text
{
  "scope": "harmful_request",
  "note": "ניסיון להעלמת נכסים"
}
```

### 2. legal_eval_plan (attempt 1, 15.9 s, tokens 229 in / 183 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פעולות להסתרת נכסים או העברתם",
      "law": "חוק פשיטת רגל, 1980",
      "sections": [
        "83"
      ]
    },
    {
      "issue": "ביטול עסקה",
      "law": "חוק פשיטת רגל, 1980",
      "sections": [
        "74"
      ]
    },
    {
      "issue": "הסתרת נכסים",
      "law": "חוק העונשין, 1977",
      "sections": [
        "420"
      ]
    }
  ]
}
```


## IL-484

### 1. legal_eval_scope (attempt 1, 4.7 s, tokens 266 in / 34 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "ניבוי חקיקה עתידית"
}
```

### 2. legal_eval_plan (attempt 1, 4.9 s, tokens 211 in / 44 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "דמי שכירות",
      "law": "חוק שכירות והשאלה"
    }
  ]
}
```


## IL-486

### 1. legal_eval_scope (attempt 1, 4.6 s, tokens 280 in / 36 out, stop: stop)

**Output**

```text
{
  "scope": "false_premise",
  "note": "טעות לגבי פרק הזמן לביטול"
}
```

### 2. legal_eval_plan (attempt 1, 10.7 s, tokens 225 in / 139 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "ביטול עסקה בשל הטעיה",
      "law": "חוק החוזים (חלק כללי), 1973",
      "sections": [
        "18"
      ]
    },
    {
      "issue": "תקופת הזמן לביטול עסקה",
      "law": "חוק החוזים (חלק כללי), 1973",
      "sections": [
        "18"
      ]
    }
  ]
}
```


## IL-487

### 1. legal_eval_scope (attempt 1, 4.4 s, tokens 285 in / 30 out, stop: stop)

**Output**

```text
{
  "scope": "false_premise",
  "note": "תקופה שגויה"
}
```

### 2. legal_eval_plan (attempt 1, 6.8 s, tokens 230 in / 74 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "תקופת הודעה מוקדמת",
      "law": "חוק הודעה מוקדמת לפיטורים, 1963",
      "sections": [
        "3"
      ]
    }
  ]
}
```


## IL-493

### 1. legal_eval_scope (attempt 1, 4.6 s, tokens 272 in / 38 out, stop: stop)

**Output**

```text
{
  "scope": "false_premise",
  "note": "אין פיצוי קבוע בחוק ליום אשפוז"
}
```

### 2. legal_eval_plan (attempt 1, 7.4 s, tokens 217 in / 74 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פיצויים בגין ימי אשפוז",
      "law": "פקודת הנזיקין, 1935",
      "sections": [
        "12"
      ]
    }
  ]
}
```


## IL-496

### 1. legal_eval_scope (attempt 1, 4.6 s, tokens 261 in / 38 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "בקשה להחלטת בית משפט ומידע אישי"
}
```

### 2. legal_eval_plan (attempt 1, 8.5 s, tokens 206 in / 101 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הגשת עתירה לבג\"ץ",
      "law": "חוק בתי המשפט",
      "sections": []
    },
    {
      "issue": "הזכות למידע",
      "law": "חוק חופש המידע, 1998",
      "sections": []
    }
  ]
}
```


## IL-108

### 1. legal_eval_scope (attempt 1, 3.8 s, tokens 267 in / 34 out, stop: stop)

**Output**

```text
{
  "scope": "nonexistent_law_or_section",
  "note": "אין סעיף כזה בחוק"
}
```

### 2. legal_eval_plan (attempt 1, 5.3 s, tokens 212 in / 45 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "חובת הקטנת הנזק", "law": "חוק האחריות למוצרי בריאות, 2005", "sections": []}]}
```


## IL-110

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 265 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 4.5 s, tokens 210 in / 36 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "חזרה ממתנה", "law": "חוק המתנה, 1968", "sections": ["4"]}]}
```


## IL-240

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 266 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 4.3 s, tokens 211 in / 40 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "תקופת התיישנות", "law": "חוק ההתיישנות, 1958", "sections": ["8"]}]}
```


## IL-388

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 272 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 4.6 s, tokens 217 in / 41 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "פסקת ההגבלה", "law": "חוק יסוד: כבוד האדם וחירותו", "sections": ["2"]}]}
```


## IL-389

### 1. legal_eval_scope (attempt 1, 4.8 s, tokens 268 in / 35 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "שואל על הלכה שיפוטית"
}
```

### 2. legal_eval_plan (attempt 1, 6.0 s, tokens 213 in / 62 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סמכות בית המשפט העליון",
      "law": "חוק בתי המשפט",
      "sections": [
        "8"
      ]
    }
  ]
}
```


## IL-391

### 1. legal_eval_scope (attempt 1, 4.1 s, tokens 280 in / 32 out, stop: stop)

**Output**

```text
{
  "scope": "nonexistent_law_or_section",
  "note": "אין חוק כזה"
}
```

### 2. legal_eval_plan (attempt 1, 10.5 s, tokens 225 in / 122 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "מימון בחירות",
      "law": "חוק בחירות לכנסת, 1959",
      "sections": [
        "75"
      ]
    },
    {
      "issue": "שקיפות במימון",
      "law": "חוק בחירות לכנסת, 1959",
      "sections": [
        "75א"
      ]
    }
  ]
}
```


## IL-432

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 263 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.5 s, tokens 208 in / 73 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "אישור תובענה ייצוגית",
      "law": "חוק תובענות ייצוגיות, 2003",
      "sections": [
        "3"
      ]
    }
  ]
}
```


## IL-036

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 298 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.6 s, tokens 243 in / 74 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פרשנות חוזה לפי אומד דעת הצדדים",
      "law": "חוק החוזים, 1973",
      "sections": [
        "25"
      ]
    }
  ]
}
```


## IL-040

### 1. legal_eval_scope (attempt 1, 4.0 s, tokens 261 in / 27 out, stop: stop)

**Output**

```text
{"scope": "nonexistent_law_or_section", "note": "לא צוין שם החוק"}
```

### 2. legal_eval_plan (attempt 1, 5.8 s, tokens 206 in / 63 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "עושק",
      "law": "חוק העונשין, 1977",
      "sections": [
        "18"
      ]
    }
  ]
}
```


## IL-230

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 280 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.7 s, tokens 225 in / 82 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "שימוש ברכב מנועי למטרות תחבורה",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, 1957",
      "sections": [
        "1"
      ]
    }
  ]
}
```


## IL-274

### 1. legal_eval_scope (attempt 1, 3.1 s, tokens 275 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.2 s, tokens 220 in / 78 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "התפטרות בשל הרעה מוחשית בתנאי העבודה",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": [
        "1"
      ]
    }
  ]
}
```


## IL-276

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 265 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.9 s, tokens 210 in / 77 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סמכות ייחודית של בית הדין לעבודה",
      "law": "חוק בתי הדין לעבודה, 1958",
      "sections": [
        "15"
      ]
    }
  ]
}
```


## IL-325

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 274 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.9 s, tokens 219 in / 63 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "רשלנות",
      "law": "חוק העונשין, 1977",
      "sections": [
        "20"
      ]
    }
  ]
}
```


## IL-327

### 1. legal_eval_scope (attempt 1, 5.0 s, tokens 264 in / 42 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "דרישת סבירות היא מושג משפטי שנקבע בפסיקה"
}
```

### 2. legal_eval_plan (attempt 1, 6.2 s, tokens 209 in / 68 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סבירות של התנהגות",
      "law": "חוק העונשין, 1977",
      "sections": [
        "34"
      ]
    }
  ]
}
```


## IL-420

### 1. legal_eval_scope (attempt 1, 2.7 s, tokens 255 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.9 s, tokens 200 in / 67 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "תביעה נגזרת",
      "law": "חוק החברות, 1999",
      "sections": [
        "400"
      ]
    }
  ]
}
```


## IL-452

### 1. legal_eval_scope (attempt 1, 5.3 s, tokens 308 in / 44 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "מבקש ייעוץ במקרה ספציפי/עובדתי"
}
```

### 2. legal_eval_plan (attempt 1, 13.6 s, tokens 253 in / 176 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "חובת גילוי",
      "law": "חוק חוזה ביטוח, 1988",
      "sections": [
        "13"
      ]
    },
    {
      "issue": "הסמך ביטוח",
      "law": "חוק חוזה ביטוח, 1988",
      "sections": [
        "14"
      ]
    },
    {
      "issue": "מועד מתן תשובה",
      "law": "חוק חוזה ביטוח, 1988",
      "sections": [
        "10"
      ]
    }
  ]
}
```


## IL-453

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 273 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 28.3 s, tokens 218 in / 342 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הגנה עצמית",
      "law": "חוק העונשין, 1977",
      "sections": [
        "27"
      ]
    },
    {
      "issue": "גרימת מוות ברשלנות או פגיעה בגוף",
      "law": "חוק העונשין, 1977",
      "sections": [
        "300",
        "322"
      ]
    },
    {
      "issue": "פריצה למקום מגורים",
      "law": "חוק העונשין, 1977",
      "sections": [
        "457"
      ]
    },
    {
      "issue": "גניבה",
      "law": "חוק העונשין, 1977",
      "sections": [
        "455"
      ]
    },
    {
      "issue": "החזקה בנשק ללא היתר או שימוש בו",
      "law": "חוק כלי הנשק, 1961",
      "sections": []
    },
    {
      "issue": "נזקי גוף",
      "law": "חוק האחריות לנזיקין, 1995",
      "sections": []
    }
  ]
}
```


## IL-455

### 1. legal_eval_scope (attempt 1, 3.9 s, tokens 304 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 26.0 s, tokens 249 in / 306 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סמכות השליח וגבולות ייפוי הכוח",
      "law": "חוק השליחות",
      "sections": []
    },
    {
      "issue": "ניגוד עניינים ומינוי שליח",
      "law": "חוק השליחות",
      "sections": []
    },
    {
      "issue": "ביטול עסקה בשל טעות או הונאה",
      "law": "חוק החוזים, 1973",
      "sections": [ "18" ]
    },
    {
      "issue": "עסקה עם קרוב משפחה במחיר נמוך",
      "law": "חוק החוזים, 1973",
      "sections": []
    },
    {
      "issue": "רישום במקרקעין",
      "law": "חוק רשומות מקרקעין, 1969",
      "sections": []
    },
    {
      "issue": "הסבת ממון",
      "law": "חוק העונשין, 1977",
      "sections": []
    }
  ]
}
```


## IL-456

### 1. legal_eval_scope (attempt 1, 3.8 s, tokens 311 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 15.8 s, tokens 256 in / 170 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "רכוש שהושג במתנה",
      "law": "חוק ממון בני זוג, 1952",
      "sections": [
        "12"
      ]
    },
    {
      "issue": "ביטול מתנה",
      "law": "חוק המתנה, 1968",
      "sections": [
        "4"
      ]
    },
    {
      "issue": "רישום במקרקעין",
      "law": "חוק רשומות מקרקעין, 1969",
      "sections": []
    }
  ]
}
```


## IL-461

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 294 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 22.2 s, tokens 239 in / 291 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "חוזה אחיד",
      "law": "חוק חוזים (חוזה אחיד), 1988",
      "sections": [
        "1",
        "2"
      ]
    },
    {
      "issue": "התחדשות אוטומטית של חוזה",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": [
        "12ג"
      ]
    },
    {
      "issue": "דמי ביטול",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": [
        "12ג"
      ]
    },
    {
      "issue": "תנאי מקפח",
      "law": "חוק חוזים (חוזה אחיד), 1988",
      "sections": [
        "4"
      ]
    },
    {
      "issue": "סמכות שיפוט",
      "law": "חוק סמכות השיפוט, 1975",
      "sections": []
    }
  ]
}
```


## IL-468

### 1. legal_eval_scope (attempt 1, 3.8 s, tokens 299 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 25.7 s, tokens 244 in / 314 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הטרדה מינית במקום העבודה",
      "law": "חוק שוויון הזדמנויות בעבודה, 1988",
      "sections": [
        "29"
      ]
    },
    {
      "issue": "חובת המעסיק למנוע הטרדה מינית",
      "law": "חוק שוויון הזדמנויות בעבודה, 1988",
      "sections": [
        "29(a)"
      ]
    },
    {
      "issue": "לשון הרע",
      "law": "חוק לשון הרע, 1968",
      "sections": [
        "1, 2, 3"
      ]
    },
    {
      "issue": "הגנה על עובד המגיש תלונה",
      "law": "חוק שוויון הזדמנויות בעבודה, 1988",
      "sections": [
        "29(g)"
      ]
    },
    {
      "issue": "חובת זהירות של מעסיק",
      "law": "חוק הבטיחות והגבאי",
      "sections": []
    }
  ]
}
```


## IL-470

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 291 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 14.9 s, tokens 236 in / 187 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "זכות הציבור לדעת",
      "law": "חוק חופש המידע, 1998",
      "sections": [
        "2"
      ]
    },
    {
      "issue": "מידע שפרסומו עלול לפגוע בפרטיות",
      "law": "חוק חופש המידע, 1998",
      "sections": [
        "4"
      ]
    },
    {
      "issue": "הגנה על פרטיות",
      "law": "חוק הגנת הפרטיות, 1981",
      "sections": [
        "2"
      ]
    }
  ]
}
```


## IL-046

### 1. legal_eval_scope (attempt 1, 3.9 s, tokens 359 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.9 s, tokens 304 in / 70 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "צורת החוזה",
      "law": "חוק החוזים (חלק כללי), 1973",
      "sections": [
        "11"
      ]
    }
  ]
}
```


## IL-049

### 1. legal_eval_scope (attempt 1, 3.9 s, tokens 353 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.4 s, tokens 298 in / 65 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "מילוי חוזה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "34"
      ]
    }
  ]
}
```


## IL-103

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 310 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 4.1 s, tokens 255 in / 33 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "מתנה", "law": "חוק המתנה, 1968", "sections": ["1"]}]}
```


## IL-105

### 1. legal_eval_scope (attempt 1, 3.8 s, tokens 343 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.0 s, tokens 288 in / 37 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "התיישנות", "law": "חוק התיישנות, 1958", "sections": ["21"]}]}
```


## IL-188

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 319 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 4.7 s, tokens 264 in / 38 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "סדר הירושה", "law": "חוק הירושה, 1965", "sections": ["31"]}]}
```


## IL-193

### 1. legal_eval_scope (attempt 1, 3.8 s, tokens 341 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.2 s, tokens 286 in / 72 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "נכס שהגיע לאחד מבני הזוג במתנה",
      "law": "חוק יחסי ממון בני זוג",
      "sections": [
        "15"
      ]
    }
  ]
}
```


## IL-286

### 1. legal_eval_scope (attempt 1, 3.9 s, tokens 349 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.7 s, tokens 294 in / 72 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הפקדות לרכיב פיצויים",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": [
        "14"
      ]
    }
  ]
}
```


## IL-331

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 311 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.0 s, tokens 256 in / 67 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סיבוב של מסייע",
      "law": "חוק העונשין, 1977",
      "sections": [
        "29"
      ]
    }
  ]
}
```


## IL-332

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 313 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.3 s, tokens 258 in / 48 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "הבאת עצור בפני שופט", "law": "חוק סדר הדין הפלילי, 1972", "sections": ["35"]}]}
```


## IL-339

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 294 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.3 s, tokens 239 in / 68 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "המתה בקלות דעת",
      "law": "חוק העונשין, 1977",
      "sections": [
        "302"
      ]
    }
  ]
}
```


## IL-378

### 1. legal_eval_scope (attempt 1, 3.2 s, tokens 281 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.2 s, tokens 226 in / 43 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "מספר חברי הכנסת", "law": "חוק הבחירות לכנסת, 1954", "sections": ["78"]}]}
```


## IL-380

### 1. legal_eval_scope (attempt 1, 3.3 s, tokens 307 in / 14 out, stop: stop)

**Output**

```text
{"scope": "in_scope", "note": ""}
```

### 2. legal_eval_plan (attempt 1, 5.6 s, tokens 252 in / 47 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "מועד הגשת כתב הגנה", "law": "תקנות סדר הדין האזרחי, 2018", "sections": ["21"]}]}
```


## IL-381

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 304 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.0 s, tokens 249 in / 49 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "מועד הגשת כתב הגנה", "law": "תקנות סמיכות לפקודת סדר הדין האזרחי", "sections": ["182"]}]}
```


## IL-382

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 334 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.6 s, tokens 279 in / 73 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סמכות שיפוט של בית משפט השלום",
      "law": "חוק בתי המשפט, 1984",
      "sections": [
        "27"
      ]
    }
  ]
}
```


## IL-383

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 317 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.1 s, tokens 262 in / 42 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "הבעת אי-אמון בממשלה", "law": "חוק יסוד: הממשלה", "sections": ["14"]}]}
```


## IL-426

### 1. legal_eval_scope (attempt 1, 3.1 s, tokens 299 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.1 s, tokens 244 in / 41 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "ביטול פסק בוררות", "law": "חוק הבוררות, 2000", "sections": ["36"]}]}
```


## IL-032

### 1. legal_eval_scope (attempt 1, 5.4 s, tokens 324 in / 37 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "דורש פסיקה/פרשנות חוזית"
}
```

### 2. legal_eval_plan (attempt 1, 9.8 s, tokens 269 in / 112 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פרשנות חוזה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "39"
      ]
    },
    {
      "issue": "מילוי חסר בחוזה",
      "law": "חוק החוזים, 1973",
      "sections": []
    }
  ]
}
```


## IL-087

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 335 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 12.7 s, tokens 280 in / 146 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הסכמה והפרה של חוזה",
      "law": "חוק חוזה",
      "sections": []
    },
    {
      "issue": "פיצויים בגין הפרת חוזה",
      "law": "חוק חוזה, 1973",
      "sections": []
    },
    {
      "issue": "הגנה על הצרכן",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": []
    }
  ]
}
```


## IL-135

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 307 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 11.6 s, tokens 252 in / 131 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "תיקון פגמים בדירה",
      "law": "חוק שכירות הוגנת, 2017",
      "sections": [
        "4"
      ]
    },
    {
      "issue": "תנאי מקטין או פוגע בזכויות השוכר",
      "law": "חוק שכירות הוגנת, 2017",
      "sections": [
        "4"
      ]
    }
  ]
}
```


## IL-136

### 1. legal_eval_scope (attempt 1, 5.1 s, tokens 309 in / 38 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "מבקש ניתוח משפטי/פסיקה"
}
```

### 2. legal_eval_plan (attempt 1, 15.1 s, tokens 254 in / 174 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "רישום במקרקעין",
      "law": "חוק רשומות מקרקעין, 1969",
      "sections": [
        "125"
      ]
    },
    {
      "issue": "הסכם מכר",
      "law": "חוק חוזים, 1973",
      "sections": [
        "15"
      ]
    },
    {
      "issue": "השבה",
      "law": "חוק חוזים, 1973",
      "sections": [
        "16"
      ]
    }
  ]
}
```


## IL-223

### 1. legal_eval_scope (attempt 1, 4.6 s, tokens 331 in / 33 out, stop: stop)

**Output**

```text
{"scope": "not_in_legislation", "note": "בקשה לניתוח מקרה/ייעוץ משפטי"}
```

### 2. legal_eval_plan (attempt 1, 17.1 s, tokens 276 in / 178 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "לשון בידוי",
      "law": "חוק העונשין, 1977",
      "sections": [
        "528"
      ]
    },
    {
      "issue": "נזק שנגרם לשמו של אדם",
      "law": "חוק הנזיקין (שירותים) , 1958",
      "sections": [
        "2"
      ]
    },
    {
      "issue": "הגנה על חופש הביטוי",
      "law": "חוק יסוד: חופש המידע",
      "sections": []
    }
  ]
}
```


## IL-267

### 1. legal_eval_scope (attempt 1, 3.9 s, tokens 335 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 13.6 s, tokens 280 in / 172 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הודעה מוקדמת",
      "law": "חוק פיטורים, 1963",
      "sections": [
        "3"
      ]
    },
    {
      "issue": "פיצויי פיטורים",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": [
        "13"
      ]
    },
    {
      "issue": "תשלום השכר",
      "law": "חוק הגנת השכר, 1958",
      "sections": [
        "25"
      ]
    }
  ]
}
```


## IL-268

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 310 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 17.7 s, tokens 255 in / 193 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פיטורים מעסיק עובדת בהריון",
      "law": "חוק עבודת נשים, 1954",
      "sections": [
        "154"
      ]
    },
    {
      "issue": "הודעה מוקדמת לפיטורים",
      "law": "חוק הודעה מוקדמת לפיטורים והסכמה לפיטורים, 1963",
      "sections": [
        "3"
      ]
    },
    {
      "issue": "פיטורים ללא סיבה מוצדקת",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": []
    }
  ]
}
```


## IL-269

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 290 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 12.7 s, tokens 235 in / 172 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "שעות נוספות",
      "law": "חוק שעות עבודה ומנוחה, 1951",
      "sections": [
        "7",
        "8"
      ]
    },
    {
      "issue": "שכר מינימום",
      "law": "חוק שכר מינימום, 1998",
      "sections": []
    },
    {
      "issue": "מנוחה שבועית",
      "law": "חוק שעות עבודה ומנוחה, 1951",
      "sections": [
        "8"
      ]
    }
  ]
}
```


## IL-317

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 307 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 13.7 s, tokens 252 in / 171 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "רצח",
      "law": "חוק העונשין, 1977",
      "sections": [
        "181"
      ]
    },
    {
      "issue": "הריגה",
      "law": "חוק העונשין, 1977",
      "sections": [
        "182"
      ]
    },
    {
      "issue": "גרימת מוות ברשלנות",
      "law": "חוק העונשין, 1977",
      "sections": [
        "301"
      ]
    }
  ]
}
```


## IL-321

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 290 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 17.2 s, tokens 235 in / 189 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "שחרור בעירבון",
      "law": "חוק סדר הדין הפלילי, 1972",
      "sections": [
        "146"
      ]
    },
    {
      "issue": "מעצר עד תום ההליכים",
      "law": "חוק סדר הדין הפלילי, 1972",
      "sections": [
        "146"
      ]
    },
    {
      "issue": "זכות להליך הוגן בתוך זמן סביר",
      "law": "חוק יסוד: כבוד האדם וחירותו, 1982",
      "sections": []
    }
  ]
}
```


## IL-371

### 1. legal_eval_scope (attempt 1, 3.8 s, tokens 301 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 12.9 s, tokens 246 in / 140 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "בקשה למתן פסק דין בהעדר הגנה",
      "law": "תקנות סדר הדין האזרחי, 1970",
      "sections": [
        "219"
      ]
    },
    {
      "issue": "הגשת כתב הגנה",
      "law": "תקנות סדר הדין האזרHי, 1970",
      "sections": [
        "101"
      ]
    }
  ]
}
```


## IL-415

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 288 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 15.5 s, tokens 233 in / 178 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פגיעה בפרטיות",
      "law": "חוק הגנת הפרטיות, 1981",
      "sections": [
        "2"
      ]
    },
    {
      "issue": "לשון בידוע",
      "law": "חוק העונשין",
      "sections": [
        "331A",
        "332"
      ]
    },
    {
      "issue": "הסכמה לפרסום",
      "law": "חוק הגנת הפרטיות, 1981",
      "sections": [
        "2"
      ]
    }
  ]
}
```


## IL-016

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 292 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 13.9 s, tokens 237 in / 165 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "אי-גילוי של פגם",
      "law": "חוק מכר, 1948",
      "sections": [
        "15"
      ]
    },
    {
      "issue": "טעות",
      "law": "חוק החוזים, 1973",
      "sections": [
        "12"
      ]
    },
    {
      "issue": "הטעיה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "12"
      ]
    }
  ]
}
```


## IL-024

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 286 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 9.4 s, tokens 231 in / 105 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "ביטול עסקה",
      "law": "חוק חוזים, 1973",
      "sections": [ "18" ]
    },
    {
      "issue": "השבה",
      "law": "חוק חוזים, 1973",
      "sections": [ "18" ]
    }
  ]
}
```


## IL-075

### 1. legal_eval_scope (attempt 1, 4.7 s, tokens 298 in / 35 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "שואל על פסיקת בית המשפט"
}
```

### 2. legal_eval_plan (attempt 1, 12.0 s, tokens 243 in / 120 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סעד של צו למילוי חוזה",
      "law": "חוק הסעדיםהשפוטים, 1958",
      "sections": [
        "15"
      ]
    },
    {
      "issue": "הסכמה לביצוע חוזה",
      "law": "חוק החוזים, 1973",
      "sections": []
    }
  ]
}
```


## IL-126

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 292 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 10.6 s, tokens 237 in / 121 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "עסקה במקרקעין",
      "law": "חוק המקרקעין, 1969",
      "sections": [
        "4"
      ]
    },
    {
      "issue": "הסכם בכתב",
      "law": "חוק המקרקעין, 1969",
      "sections": [
        "4"
      ]
    }
  ]
}
```


## IL-164

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 285 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 9.1 s, tokens 230 in / 112 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "כשירות משפטית",
      "law": "חוק הכשרות המשפטית, 1962",
      "sections": [ "1" ]
    },
    {
      "issue": "ביטול עסקה",
      "law": "חוק הכשרות המשפטית, 1962",
      "sections": [ "2" ]
    }
  ]
}
```


## IL-168

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 275 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 18.0 s, tokens 220 in / 242 out, stop: stop)

**Output**

```text
{
 	 	 	 	 	 	 	 	 	 	"issues": [
 	 	 	 	 	 	 	 	 	 	{
 	 	 	 	 	 	 	 	 	 	"issue": "פסילת יורש",
 	 	 	 	 	 	 	 	 	"law": "חוק הירושה, 1965",
 	 	 	 	 	 	 	 	 	"sections": [
 	 	 	 	 	 	 	 	 	"5"
 	 	 	 	 	 	 	 	 	]
 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	]
 	 	 	 	 	 	 	 	 	}
```


## IL-172

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 275 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 14.9 s, tokens 220 in / 162 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הסדרים לגבי ילדים",
      "law": "חוק סדר דין אזרחי",
      "sections": [
    ]
    },
    {
      "issue": "מינוי אפוטרופוס",
      "law": "חוק הכשרות המשפטית והאפוטרופוס, 1962",
      "sections": [
    ]
    },
    {
      "issue": "מיטב טובת הילד",
      "law": "חוק שירותי המשפחה",
      "sections": [
    ]
    }
  ]
}
```


## IL-212

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 307 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 12.2 s, tokens 252 in / 147 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הפחתת פיצויים בשל רשלנות הנפגע",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, 1958",
      "sections": [
        "3"
      ]
    },
    {
      "issue": "הגדרת נפגע",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, 1958",
      "sections": [
        "2"
      ]
    }
  ]
}
```


## IL-213

### 1. legal_eval_scope (attempt 1, 3.7 s, tokens 297 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 11.4 s, tokens 242 in / 142 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "זכאות לפיצויים",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, 1958",
      "sections": [
        "9"
      ]
    },
    {
      "issue": "הפחתה בפיצויים",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, 1958",
      "sections": [
        "11"
      ]
    }
  ]
}
```


## IL-214

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 282 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 13.1 s, tokens 227 in / 121 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "אחריות מעסיק",
      "law": "חוק האחריות לנזיקי פועלים, 1965",
      "sections": [ "2" ]
    },
    {
      "issue": "נזיקי רכב",
      "law": "חוק הפיצויים לנפגעי תאונות דרכים, 1958",
      "sections": []
    }
  ]
}
```


## IL-217

### 1. legal_eval_scope (attempt 1, 4.1 s, tokens 279 in / 30 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "שאלת פסיקה"
}
```

### 2. legal_eval_plan (attempt 1, 6.8 s, tokens 224 in / 72 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פיצויים ללא הוכחת נזק",
      "law": "חוק לשון הרע, 1965",
      "sections": [
        "10"
      ]
    }
  ]
}
```


## IL-219

### 1. legal_eval_scope (attempt 1, 4.3 s, tokens 298 in / 36 out, stop: stop)

**Output**

```text
{
  "scope": "not_in_legislation",
  "note": "שאלת יישום על מקרה ספציפי"
}
```

### 2. legal_eval_plan (attempt 1, 6.5 s, tokens 243 in / 66 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הפסקת התיישנות",
      "law": "חוק ההתיישנות, 1958",
      "sections": [
        "8"
      ]
    }
  ]
}
```


## IL-262

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 288 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 9.8 s, tokens 233 in / 122 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "שעות נוספות",
      "law": "חוק שעות עבודה ומנוחה, 1951",
      "sections": [
        "7"
      ]
    },
    {
      "issue": "גמול שעות נוספות",
      "law": "חוק שעות עבודה ומנוחה, 1951",
      "sections": [
        "7"
      ]
    }
  ]
}
```


## IL-306

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 272 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.2 s, tokens 217 in / 74 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "גיל פטור מאחריות פלילית",
      "law": "חוק גיל האחריות הפלילית, 1975",
      "sections": [
        "2"
      ]
    }
  ]
}
```


## IL-309

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 290 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.5 s, tokens 235 in / 65 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הגנה עצמית",
      "law": "חוק העונשין, 1977",
      "sections": [
        "34"
      ]
    }
  ]
}
```


## IL-368

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 287 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 12.1 s, tokens 232 in / 130 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הגשתו של פתק הצבעה",
      "law": "חוק הבחירות לכנסת, 1954",
      "sections": [
        "24"
      ]
    },
    {
      "issue": "מיקום קלפי הבחירה",
      "law": "חוק הבחירות לכנסת, 1954",
      "sections": [
        "23"
      ]
    }
  ]
}
```


## IL-409

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 287 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.1 s, tokens 232 in / 67 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "תביעה בשם החברה",
      "law": "חוק החברות, 1999",
      "sections": [
        "189"
      ]
    }
  ]
}
```


## IL-410

### 1. legal_eval_scope (attempt 1, 3.6 s, tokens 300 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 10.1 s, tokens 245 in / 126 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "חלוקת דיבידנד",
      "law": "חוק החברות, 1999",
      "sections": [
        "302"
      ]
    },
    {
      "issue": "מבחן היכולת לפרוע חובות",
      "law": "חוק החברות, 1999",
      "sections": [
        "302"
      ]
    }
  ]
}
```


## IL-001

### 1. legal_eval_scope (attempt 1, 3.1 s, tokens 264 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.1 s, tokens 209 in / 43 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "כרות חוזה", "law": "חוק החוזים (חלק כללי), 1973", "sections": ["11"]}]}
```


## IL-011

### 1. legal_eval_scope (attempt 1, 2.8 s, tokens 259 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.0 s, tokens 204 in / 71 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "מילוי פרטים שחסרים בחוזה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "24"
      ]
    }
  ]
}
```


## IL-014

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 262 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.4 s, tokens 207 in / 66 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "מועד קיום החיוב",
      "law": "חוק חוזים, 1973",
      "sections": [
        "29"
      ]
    }
  ]
}
```


## IL-061

### 1. legal_eval_scope (attempt 1, 5.0 s, tokens 266 in / 43 out, stop: stop)

**Output**

```text
{
  "scope": "nonexistent_law_or_section",
  "note": "אין 'חוק תרופות' המסדיר הפרת חוזה"
}
```

### 2. legal_eval_plan (attempt 1, 5.7 s, tokens 211 in / 48 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סעדים בגין הפרת חוזה",
      "law": "חוק תרופות"
    }
  ]
}
```


## IL-062

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 262 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 11.1 s, tokens 207 in / 124 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סעדים בגין הפרת חוזה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "157"
      ]
    },
    {
      "issue": "ביטול חוזה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "158"
      ]
    }
  ]
}
```


## IL-113

### 1. legal_eval_scope (attempt 1, 3.2 s, tokens 265 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.4 s, tokens 210 in / 42 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "מועד ביצוע העסקה", "law": "חוק המקרקעין, 1969", "sections": ["8" ]}]}
```


## IL-115

### 1. legal_eval_scope (attempt 1, 2.7 s, tokens 259 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 12.2 s, tokens 204 in / 140 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "רישום במקרקעין",
      "law": "חוק רשומות מקרקעין, 1969",
      "sections": [
        "12"
      ]
    },
    {
      "issue": "הגנה על קונה שסמך על הרישום",
      "law": "חוק רשומות מקרקעין, 1969",
      "sections": [
        "12"
      ]
    }
  ]
}
```


## IL-153

### 1. legal_eval_scope (attempt 1, 3.3 s, tokens 259 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.7 s, tokens 204 in / 79 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "אפוטרופוסים טבעיים",
      "law": "חוק הכשרות המשפטית והאפוטרופסות, 1962",
      "sections": [
        "63"
      ]
    }
  ]
}
```


## IL-202

### 1. legal_eval_scope (attempt 1, 5.5 s, tokens 262 in / 32 out, stop: stop)

**Output**

```text
{"scope": "not_in_legislation", "note": "כלל פרשני/משפטי שאינו חקיקה"}
```

### 2. legal_eval_plan (attempt 1, 6.4 s, tokens 207 in / 61 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "ראיות",
      "law": "חוק הראיות, 1976",
      "sections": [
        "65"
      ]
    }
  ]
}
```


## IL-205

### 1. legal_eval_scope (attempt 1, 3.2 s, tokens 259 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 8.0 s, tokens 204 in / 78 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "אחריות מעביד למעשי עובדו",
      "law": "חוק האחריות לנזקי עובדים, 1958",
      "sections": [
        "2"
      ]
    }
  ]
}
```


## IL-245

### 1. legal_eval_scope (attempt 1, 3.2 s, tokens 270 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.8 s, tokens 215 in / 70 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "זכאות לפיצויי פיטורים",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": [
        "1"
      ]
    }
  ]
}
```


## IL-247

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 267 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.5 s, tokens 212 in / 50 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "הודעה מוקדמת", "law": "חוק הודעה מוקדמת לפיטורים ולהתפטרות, 1963", "sections": ["3"]}]}
```


## IL-248

### 1. legal_eval_scope (attempt 1, 3.2 s, tokens 271 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 7.4 s, tokens 216 in / 71 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הודעה מוקדמת לפיטורים",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": [
        "3"
      ]
    }
  ]
}
```


## IL-253

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 271 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.2 s, tokens 216 in / 41 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "מועד תשלום השכר", "law": "חוק הגנת השכר, 1958", "sections": ["25"]}]}
```


## IL-254

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 266 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.3 s, tokens 211 in / 75 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "איסור אפליה בתעסוקה",
      "law": "חוק שוויון הזדמנויות בעבודה, 1988",
      "sections": [
        "1"
      ]
    }
  ]
}
```


## IL-256

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 279 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.7 s, tokens 224 in / 73 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "סמכות שיפוט ייחודית",
      "law": "חוק בתי הדין לעבודה, 1954",
      "sections": [
        "11"
      ]
    }
  ]
}
```


## IL-293

### 1. legal_eval_scope (attempt 1, 3.4 s, tokens 265 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 5.1 s, tokens 210 in / 40 out, stop: stop)

**Output**

```text
{"issues": [{"issue": "סיווג עבירות", "law": "חוק העונשין, 1977", "sections": ["2"]}]}
```


## IL-294

### 1. legal_eval_scope (attempt 1, 3.3 s, tokens 256 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.5 s, tokens 201 in / 68 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "גיל האחריות הפלילית",
      "law": "חוק העונשין, 1977",
      "sections": [
        "34"
      ]
    }
  ]
}
```


## IL-296

### 1. legal_eval_scope (attempt 1, 2.7 s, tokens 259 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.3 s, tokens 204 in / 68 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "עונש על רצח",
      "law": "חוק העונשין, 1977",
      "sections": [
        "303"
      ]
    }
  ]
}
```


## IL-297

### 1. legal_eval_scope (attempt 1, 3.3 s, tokens 255 in / 22 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 6.3 s, tokens 200 in / 68 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "המתה בקלות דעת",
      "law": "חוק העונשין, 1977",
      "sections": [
        "301"
      ]
    }
  ]
}
```


## IL-300

### 1. legal_eval_scope (attempt 1, 3.0 s, tokens 263 in / 20 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 8.7 s, tokens 208 in / 77 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "הבאת עצור בפני שופט",
      "law": "חוק סמכויות שיפוטיות (חיAndUpdate), 1979",
      "sections": [
        "35"
      ]
    }
  ]
}
```


## IL-353

### 1. legal_eval_scope (attempt 1, 3.2 s, tokens 270 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 8.8 s, tokens 215 in / 119 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "זכות הבחירה",
      "law": "חוק הבחירות לכנסת, 1954",
      "sections": [
        "2"
      ]
    },
    {
      "issue": "זכות להיבחר",
      "law": "חוק הבחירות לכנסת, 1954",
      "sections": [
        "5"
      ]
    }
  ]
}
```


## IL-060

### 1. legal_eval_scope (attempt 1, 4.8 s, tokens 299 in / 36 out, stop: stop)

**Output**

```text
{
  "scope": "false_premise",
  "note": "תיקון 2026 אינו קיים"
}
```

### 2. legal_eval_plan (attempt 1, 6.3 s, tokens 244 in / 65 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פרשנות חוזה",
      "law": "חוק החוזים, 1973",
      "sections": [
        "39"
      ]
    }
  ]
}
```


## IL-198

### 1. legal_eval_scope (attempt 1, 4.7 s, tokens 269 in / 40 out, stop: stop)

**Output**

```text
{
  "scope": "false_premise",
  "note": "ייפוי כוח מתמשך אינו חלק מחוק הכשרות"
}
```

### 2. legal_eval_plan (attempt 1, 6.0 s, tokens 214 in / 69 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "ייפוי כוח מתמשך",
      "law": "חוק הכשרות המשפטית",
      "sections": [
        "14א-14ג"
      ]
    }
  ]
}
```


## IL-347

### 1. legal_eval_scope (attempt 1, 4.5 s, tokens 308 in / 36 out, stop: stop)

**Output**

```text
{
  "scope": "false_premise",
  "note": "השנה 2026 היא בעתיד"
}
```

### 2. legal_eval_plan (attempt 1, 9.2 s, tokens 253 in / 107 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "מעצר לפני הגשת כתב אישום",
      "law": "חוק המעצרים, 1979",
      "sections": [
        "17"
      ]
    },
    {
      "issue": "פרסום של חוק",
      "law": "פקודת הממשלה",
      "sections": []
    }
  ]
}
```


## IL-392

### 1. legal_eval_scope (attempt 1, 3.5 s, tokens 283 in / 21 out, stop: stop)

**Output**

```text
{
  "scope": "in_scope",
  "note": ""
}
```

### 2. legal_eval_plan (attempt 1, 10.6 s, tokens 228 in / 136 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "תחולת תקנות סדר הדין האזרחי",
      "law": "תקנות סדר הדין האזרחי, 2018",
      "sections": [
        "1"
      ]
    },
    {
      "issue": "מעבר בין תקנות",
      "law": "תקנות סדר הדין האזרחי, 2018",
      "sections": [
        "507"
      ]
    }
  ]
}
```


## case_01

### 1. legal_eval_plan (attempt 1, 22.0 s, tokens 1333 in / 301 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "פיטורים עובדת בהריון",
      "law": "חוק עבודת נשים, 1954",
      "sections": [
        "154"
      ]
    },
    {
      "issue": "קי сокраציית היקף משרה",
      "law": "חוק עבודת נשים, 1954",
      "sections": [
        "154"
      ]
    },
    {
      "issue": "מועד תשלום השכר",
      "law": "חוק הגנת השכר, 1958",
      "sections": [
        "25"
      ]
    },
    {
      "issue": "פיצויי פיטורים",
      "law": "חוק פיצויי פיטורים, 1963",
      "sections": [
        "14"
      ]
    },
    {
      "issue": "הודעה מוקדמת",
      "law": "חוק הודעה מוקדמת לפיטורים ולהתפטרות, 1963",
      "sections": [
        "3"
      ]
    }
  ]
}
```


## case_02

### 1. legal_eval_plan (attempt 1, 19.8 s, tokens 1149 in / 231 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "השבת פיקדון",
      "law": "חוק שכירות הוגנת, 2017",
      "sections": [
        "6"
      ]
    },
    {
      "issue": "תיקון פגמים במושכר",
      "law": "חוק שכירות הוגנת, 2017",
      "sections": [
        "5"
      ]
    },
    {
      "issue": "תשלומים עבור שיפוץ המבנה",
      "law": "חוק שכירות הוגנת, 2017",
      "sections": [
        "6"
      ]
    },
    {
      "issue": "בלאי סביר",
      "law": "חוק שכירות הוגנת, 2017",
      "sections": [
        "6"
      ]
    }
  ]
}
```


## case_03

### 1. legal_eval_plan (attempt 1, 22.8 s, tokens 978 in / 282 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "ביטול עסקה",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": [
        "16א",
        "16ב"
      ]
    },
    {
      "issue": "החזר כספי",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": [
        "16ב"
      ]
    },
    {
      "issue": "הטעיה",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": [
        "2"
      ]
    },
    {
      "issue": "חובת מתן מסמך",
      "law": "חוק הגנת הצרכן, 1981",
      "sections": [
        "16א"
      ]
    },
    {
      "issue": "תנאי מקפח",
      "law": "חוק חוזה הוגן, 2022",
      "sections": []
    }
  ]
}
```


## case_04

### 1. legal_eval_plan (attempt 1, 27.0 s, tokens 1178 in / 325 out, stop: stop)

**Output**

```text
{
  "issues": [
    {
      "issue": "רישום הערת אזהרה",
      "law": "חוק המקרקעין, 1969",
      "sections": [ "125" ]
    },
    {
      "issue": "זכות קונה במקרקעין",
      "law": "חוק המקרקעין, 1969",
      "sections": [ "126" ]
    },
    {
      "issue": "הסכמי מכר במקרקעין",
      "law": "חוק המקרקעין, 1969",
      "sections": [ "8" ]
    },
    {
      "issue": "שעבודים במקרקעין",
      "law": "חוק שעבודים במקרקעין, 1961",
      "sections": [ "2" ]
    },
    {
      "issue": "הונאה",
      "law": "חוק העונשין, 1977",
      "sections": [ "454" ]
    },
    {
      "issue": "סעד של צו מניעה",
      "law": "סדר הדין האזרHי, 1986",
      "sections": [ ]
    }
  ]
}
```


## case_05

### 1. legal_eval_plan (attempt 1, 23.5 s, tokens 1065 in / 268 out, stop: stop)

**Output**

```text
{"issues": [
  {"issue": "תוקף צוואה", "law": "חוק הירושה, 1965", "sections": ["21", "22"]},
  {"issue": "צוואה בכתב יד", "law": "חוק הירושה, 1965", "sections": ["22"]},
  {"issue": "כשירות להוריש", "law": "חוק הירושה, 1965", "sections": []},
  {"issue": "השפעה בלתי הוגנת", "law": "חוק הירושה, 1965", "sections": []},
  {"issue": "זכות מגורים של אלמנה", "law": "חוק הירושה, 1965", "sections": ["65"]},
  {"issue": "חלוקת עיקר הירושה", "law": "חוק הירושה, 1965", "sections": ["4", "5"]},
  {"issue": "התנגדות לצוואה", "law": "תקנות רשם לענייני ירושה", "sections": []}
]}
```

