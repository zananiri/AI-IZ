# Kaggle eval run gemma4_31b_caselaw

100 questions, 5 cases; case-law index: `/kaggle/input/datasets/ibrahimramzi/case-law/israeli_caselaw`

## Judge-free comparison

| | gemma3:27b-it-qat, 29 Sept (corpus_gemma27b_fixes) | gemma4:31b / caselaw | gemma4:31b / no_caselaw |
|---|---|---|---|
| answers (errors / empty) | 100 | 100 (0 / 0) | 43 (0 / 0) |
| multiple choice | 14/16 | 16/16 | 15/15 |
| yes/no label | 15/18 | 17.0/18 | None |
| governing section retrieved (%) | 88.8 | 88.8 | 87.8 |
| questions given case law | - | 77 | 0 |
| judgments per such question | - | 2.57 | 0 |
| answers citing a retrieved judgment | - | 7 | 0 |
| cases given case law / work files citing one | - | 5 / 1 | 0 / 0 |
| median answer call (s) | - | 60.7 | 43.3 |
| max prompt tokens (answer call) | - | 15251 | 10350 |
| answer calls stopped at length | - | 1 | 0 |
| judged overall (%) | 75.8 | after judging | after judging |
| cases judged (01-05) | 25 / 31 / 43 / 42 / 44 | after judging | after judging |

## gemma4:31b / caselaw

- repairs {'completeness_revision': 17, 'conclusion_first': 18}

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 105 | 1 | 0 | 60.7 | 15251 | 2959 |
| legal_eval_completeness | 64 | 0 | 0 | 7.7 | 1576 | 997 |
| legal_eval_extract | 77 | 0 | 0 | 58.5 | 9239 | 791 |
| legal_eval_plan | 105 | 0 | 0 | 7.6 | 1333 | 342 |
| legal_eval_repair | 4 | 1 | 0 | 210.4 | 15643 | 2957 |
| legal_eval_scope | 100 | 0 | 0 | 5.0 | 359 | 44 |
| legal_eval_toc | 77 | 0 | 0 | 15.0 | 7601 | 103 |

## gemma4:31b / no_caselaw

- repairs {'completeness_revision': 6}

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 43 | 0 | 0 | 43.3 | 10350 | 509 |
| legal_eval_completeness | 16 | 0 | 0 | 10.8 | 1000 | 602 |
| legal_eval_extract | 31 | 0 | 0 | 45.8 | 9239 | 775 |
| legal_eval_plan | 45 | 0 | 0 | 7.2 | 1333 | 342 |
| legal_eval_scope | 44 | 0 | 0 | 5.2 | 359 | 44 |
| legal_eval_toc | 32 | 0 | 0 | 13.3 | 5696 | 102 |
