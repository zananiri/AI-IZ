# Israeli legal eval set: 500 questions + 10 paralegal cases

Hebrew evaluation set for an offline legal RAG system over Israeli legislation.
Built on 26 Sep 2026.

## Files

| File | Send to the model under test? | Contents |
|---|---|---|
| `questions.jsonl` | **yes** | 500 items: `id`, `category`, `area`, `format`, `instructions`, `question`, and `options` for multiple choice. No answers. |
| `gold.jsonl` | **no, judge only** | Same `id`s: gold answer, key points, expected law and section, `answer_letter` / `answer_label`, `confidence`, `scoring` method. |
| `cases/00_TASK_INSTRUCTIONS.md` + `cases/case_XX_*.md` | **yes** | 10 case files with fictional documents, and one shared paralegal task. |
| `cases_gold.json` | **no, judge only** | Per case: chronology, issues with law and section, computed deadlines, red flags, missing info, deliverable checks, `must_not` list, and a 100-point rubric with penalties. |
| `judge_prompt.md` | judge | Prompt A (single question) and prompt B (case file), with JSON output formats. |
| `score.py` | – | `prepare` builds judge requests; `report` scores multiple choice and yes/no automatically and merges judge results. |
| `verify_gold.py` | – | Checks each gold citation against **your** ChromaDB. Run this before trusting the set. |

## How the 500 questions are organised

The categories follow the LegalBench reasoning types (issue spotting, rule recall, rule application, rule conclusion, interpretation), plus multiple-choice questions in the Israeli bar exam format and three categories specific to RAG systems.

| Category | n | Format | Scored by |
|---|---:|---|---|
| rule_recall | 110 | short answer | judge |
| rule_conclusion | 90 | yes/no + reason | label automatically, reason by judge |
| mcq_bar | 80 | 4 options (א–ד), balanced 20/20/20/20; 57 substantive, 23 procedural | exact letter |
| rule_application | 60 | open IRAC analysis | judge against key points |
| interpretation | 40 | short answer | judge |
| citation_grounding | 35 | which law and section | judge |
| issue_spotting | 35 | fact pattern → list issues | judge (share of key points found) |
| abstention | 30 | false premise, fictional law, out of scope, harmful request | judge |
| temporal_amendment | 20 | which version of the law applies | judge |

The questions cover 11 areas: contracts, remedies and sale, property and tenancy, family and succession, torts and limitation, labor, criminal law and evidence, constitutional law and civil procedure, commercial and consumer law, plus the cross-area issue-spotting and abstention sets. They include the three 2026 laws from earlier testing (elections, October 7 prosecution, Contracts Law section 25).

## Running it

1. Run each question in `questions.jsonl` through your pipeline: `instructions` followed by `question`, plus the options for multiple choice. Save one line per answer: `{"id": "IL-001", "answer": "..."}`.
2. `python score.py prepare --questions questions.jsonl --gold gold.jsonl --answers answers.jsonl --out judge_requests.jsonl`
3. Run the judge model on `judge_requests.jsonl` and save one JSON object per line with the `id` added.
4. `python score.py report --gold gold.jsonl --answers answers.jsonl --judged judged.jsonl`. Add `--confidence high` to score only the higher-confidence items.
5. For the cases: give the model `00_TASK_INSTRUCTIONS.md` together with one case file; grade the output with prompt B and that case's entry in `cases_gold.json`.

Run the set in the three configurations you already use (no context / RAG / full document), so you can tell retrieval errors from model errors.

## Before you rely on the gold answers

- **Accuracy.** I wrote the gold answers from knowledge of Israeli law as of mid-2026, and I checked the riskiest numbers against the law texts: tenancy deposit and repair deadlines, civil procedure deadlines, arrest periods, and the 2019 homicide reform. Even so, the set has not been reviewed by a lawyer.
- **Confidence levels.** 168 items are marked `confidence: medium`, mostly because of exact section numbers, or details in regulations or recent amendments. Have a lawyer review these, or leave them out of headline scores.
- **Check against your index.** Run `verify_gold.py` against your index. Anything that isn't `VERIFIED` needs a look. `SECTION_MATCH_NUMBERS_MISSING` on a multiple-choice or worked example often just means the gold answer contains a computed number (e.g. 3 × rent) that doesn't appear in the statute.
- **Regulations.** The 7 items citing `CPR` (Civil Procedure Regulations 2018: IL-358, 363, 371, 380, 381, 390, 392) need regulations in your corpus. If you indexed laws only, either filter those items out or treat them as abstention tests.
- **Recent amendments.** Section 17 of the Arrests Law was amended several times in 2024–2026. Check IL-301, IL-318, IL-333 and IL-347 against your current text.
- **One title to check.** The official title of the October 7 prosecution law (Sefer HaChukim 3527) is abbreviated in `gold.jsonl`; check it against your index.
- **No citation, by design.** `IL-291` (minimum wage) intentionally has no citation. It tests whether the model admits that it needs the latest published amount.
- **Earlier 24-question set.** q20 in the earlier `eval_gold_24.json` ("what does section 25(ב1) of the Contracts Law say?") was unanswerable when only the 2026 amendment was indexed. Now that the full Contracts Law is in your index, it becomes answerable, so update that gold item.

## Deliberate traps in the cases

Each case has at least one trap listed under `red_flags` or `must_not` in the gold file. Examples: conflicting dates between documents, a missing signature, a privileged document forwarded to a family group, a conflict of interest when a second family member asks to be represented, and a case whose title says "deadline close" although the client was a minor at the time (which changes the limitation calculation). Most models lose points on these, so read those rubric lines when comparing systems.
