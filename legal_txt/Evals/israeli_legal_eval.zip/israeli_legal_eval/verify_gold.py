#!/usr/bin/env python3
"""Check every gold answer against YOUR ChromaDB before trusting the eval.

For each gold item that cites a law and section, the script retrieves the top-k
chunks and checks three things:
  1. a retrieved chunk belongs to the cited law      (metadata law field, fuzzy)
  2. it is the cited section                          (metadata section field, or "סעיף N" in text)
  3. every number in the gold answer appears in the retrieved text (periods, amounts, ages)

Status per item: VERIFIED | SECTION_MATCH_NUMBERS_MISSING | LAW_ONLY | NOT_FOUND | SKIPPED
Anything not VERIFIED should be reviewed by a lawyer before the item is used.

Usage (offline):
  python verify_gold.py --gold gold.jsonl --chroma-path ./chroma_db --collection laws \
      --law-field law_name --section-field section_number \
      --model /models/bge-m3 --k 8 --out gold_verification.jsonl

The field names default to the metadata schema from the chunking design
(law_name, section_number, inserted_section). Change them to match your index.
"""
import argparse
import collections
import hashlib
import json
import re

HEB_YEAR = re.compile(r'התש[א-ת]?["״]?[א-ת]-?\d{4}|\d{4}')
STRIP = re.compile(r'[\s"״׳\'\-–,\.\(\)\[\]:]')
# numbers are compared only where the gold states the rule itself; in application
# and conclusion items the gold often contains computed values (e.g. 3 x rent)
NUMBER_CHECK_CATEGORIES = {"rule_recall", "interpretation", "citation_grounding", "mcq_bar", "temporal_amendment"}


def norm_law(name: str) -> str:
    """'חוק החוזים (חלק כללי), התשל"ג-1973' -> 'חוקהחוזיםחלקכללי'"""
    name = (name or "").replace("[נוסח חדש]", "").replace("[נוסח משולב]", "")
    name = HEB_YEAR.sub("", name)
    return STRIP.sub("", name)


def base_section(sec: str) -> str:
    """'14(א)' -> '14', '25י' -> '25י', '6(4) › 116יז10(ה)' -> '6'"""
    m = re.match(r"\s*(\d+[א-ת]*\d*)", sec or "")
    return m.group(1) if m else ""


def numbers(text: str) -> set[str]:
    nums = set(re.findall(r"\d[\d,\.]*", text or ""))
    return {n.replace(",", "").rstrip(".") for n in nums if len(n.replace(",", "")) >= 1}


_UNITS = {"אחד": 1, "אחת": 1, "שניים": 2, "שתיים": 2, "שני": 2, "שתי": 2, "שלושה": 3, "שלוש": 3,
          "ארבעה": 4, "ארבע": 4, "חמישה": 5, "חמש": 5, "שישה": 6, "שש": 6, "שבעה": 7, "שבע": 7,
          "שמונה": 8, "תשעה": 9, "תשע": 9}
_TENS = {"עשרים": 20, "שלושים": 30, "ארבעים": 40, "חמישים": 50, "שישים": 60, "שבעים": 70,
         "שמונים": 80, "תשעים": 90}
_TEENS = {f"{u} {s}": v + 10 for u, v in _UNITS.items() for s in ("עשר", "עשרה")}
_PHRASES = {**{f"{t} ו{u}": tv + uv for t, tv in _TENS.items() for u, uv in _UNITS.items()},
            **_TEENS, **_TENS, "עשר": 10, "עשרה": 10, "מאה": 100, "מאתיים": 200, **_UNITS}


def words_to_digits(text: str) -> str:
    """Statutes often spell numbers ('שבע שנים', 'שלושים ימים'); add digit forms."""
    extra = [str(v) for p, v in sorted(_PHRASES.items(), key=lambda kv: -len(kv[0]))
             if re.search(rf"(?<![א-ת]){p}(?![א-ת])", text or "")]
    return (text or "") + " " + " ".join(extra)


def check_item(item, hits, law_field, section_fields):
    """Pure function: item = gold row; hits = [(document, metadata)]."""
    if not item["citations"]:
        return {"status": "SKIPPED", "reason": "no citation"}
    want_laws = {norm_law(c["law"]) for c in item["citations"]}
    want_secs = {base_section(c["section"]) for c in item["citations"] if base_section(c["section"])}
    law_hits, sec_hits = [], []
    for doc, meta in hits:
        meta = meta or {}
        law_ok = any(w and (w in norm_law(str(meta.get(law_field, ""))) or norm_law(str(meta.get(law_field, ""))) in w)
                     for w in want_laws if norm_law(str(meta.get(law_field, ""))))
        if not law_ok:
            continue
        law_hits.append(doc)
        meta_secs = {base_section(str(meta.get(f, ""))) for f in section_fields}
        text_secs = {m for m in re.findall(r"סעיף\s+(\d+[א-ת]*)", doc or "")}
        if not want_secs or want_secs & (meta_secs | text_secs):
            sec_hits.append(doc)
    if not law_hits:
        return {"status": "NOT_FOUND"}
    if not sec_hits:
        return {"status": "LAW_ONLY"}
    if item.get("category") not in NUMBER_CHECK_CATEGORIES:
        return {"status": "VERIFIED"}
    cited_nums = {re.sub(r"\D", "", s) for s in want_secs}
    want_nums = {n for n in numbers(item["gold_answer"])
                 if n not in cited_nums and not re.fullmatch(r"(19|20)\d\d", n) and n not in {"1", "2"}}
    have = set()
    for d in sec_hits:
        d = words_to_digits(d)
        have |= numbers(d)
        have |= {w for w in re.findall(r"\d+", d or "")}
    missing = sorted(n for n in want_nums if n not in have)
    if missing:
        return {"status": "SECTION_MATCH_NUMBERS_MISSING", "missing_numbers": missing}
    return {"status": "VERIFIED"}


class HashEmbedder:
    """Deterministic bag-of-words embedder, only for smoke tests."""
    def __init__(self, dim=256):
        self.dim = dim

    def encode(self, texts, **_):
        out = []
        for t in texts:
            v = [0.0] * self.dim
            for w in re.findall(r"[א-ת\d]+", t):
                v[int(hashlib.md5(w.encode()).hexdigest(), 16) % self.dim] += 1.0
            n = sum(x * x for x in v) ** 0.5 or 1.0
            out.append([x / n for x in v])
        return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--gold", required=True)
    p.add_argument("--chroma-path", required=True)
    p.add_argument("--collection", required=True)
    p.add_argument("--law-field", default="law_name")
    p.add_argument("--section-field", action="append", default=None,
                   help="repeatable; default: section_number and inserted_section")
    p.add_argument("--model", default="BAAI/bge-m3", help="local path or name; 'hash' for smoke tests")
    p.add_argument("--k", type=int, default=8)
    p.add_argument("--out", default="gold_verification.jsonl")
    a = p.parse_args()
    section_fields = a.section_field or ["section_number", "inserted_section"]

    import chromadb
    col = chromadb.PersistentClient(path=a.chroma_path).get_collection(a.collection)
    if a.model == "hash":
        emb = HashEmbedder()
    else:
        from sentence_transformers import SentenceTransformer
        emb = SentenceTransformer(a.model)

    gold = [json.loads(line) for line in open(a.gold, encoding="utf-8") if line.strip()]
    counts = collections.Counter()
    review = []
    with open(a.out, "w", encoding="utf-8") as f:
        for g in gold:
            if not g["citations"]:
                res = {"status": "SKIPPED", "reason": "no citation"}
            else:
                c0 = g["citations"][0]
                query = f"{c0['law']} סעיף {c0['section']} {g['gold_answer'][:400]}"
                vec = emb.encode([query], normalize_embeddings=True) if a.model != "hash" else emb.encode([query])
                vec = [list(map(float, vec[0]))]
                r = col.query(query_embeddings=vec, n_results=a.k, include=["documents", "metadatas"])
                hits = list(zip(r["documents"][0], r["metadatas"][0]))
                res = check_item(g, hits, a.law_field, section_fields)
            counts[res["status"]] += 1
            if res["status"] not in ("VERIFIED", "SKIPPED"):
                review.append((g["id"], g["confidence"], res["status"]))
            f.write(json.dumps({"id": g["id"], "confidence": g["confidence"], **res}, ensure_ascii=False) + "\n")
    print("status counts:", dict(counts))
    print(f"items to review: {len(review)} (medium confidence first)")
    for i, conf, st in sorted(review, key=lambda x: x[1] != "medium")[:40]:
        print(f"  {i}  {conf:6}  {st}")
    print(f"full report: {a.out}")


if __name__ == "__main__":
    main()
