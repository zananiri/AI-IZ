# Kaggle eval run gemma4_31b_caselaw

100 questions, 5 cases; case-law index: `/kaggle/input/datasets/ibrahimramzi/case-law/israeli_caselaw`

## Judge-free comparison

| | gemma3:27b-it-qat, 29 Sept (corpus_gemma27b_fixes) | gemma4:31b / caselaw | gemma4:31b / no_caselaw |
|---|---|---|---|
| answers (errors / empty) | 100 | 100 (100 / 100) | 100 (100 / 100) |
| multiple choice | 14/16 | 0/16 | 0/16 |
| yes/no label | 15/18 | 0.0/18 | 0.0/18 |
| governing section retrieved (%) | 88.8 | 0.0 | 0.0 |
| questions given case law | - | 0 | 0 |
| judgments per such question | - | 0 | 0 |
| answers citing a retrieved judgment | - | 0 | 0 |
| cases given case law / work files citing one | - | 0 / 0 | 0 / 0 |
| median answer call (s) | - | None | None |
| max prompt tokens (answer call) | - | None | None |
| answer calls stopped at length | - | None | None |
| judged overall (%) | 75.8 | after judging | after judging |
| cases judged (01-05) | 25 / 31 / 43 / 42 / 44 | after judging | after judging |

## gemma4:31b / caselaw

- repairs {}

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_plan | 105 | 0 | 0 | 7.3 | 1333 | 342 |
| legal_eval_scope | 100 | 0 | 0 | 3.6 | 359 | 44 |

## gemma4:31b / no_caselaw

- repairs {}

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_plan | 105 | 0 | 0 | 7.4 | 1333 | 342 |
| legal_eval_scope | 100 | 0 | 0 | 3.6 | 359 | 44 |
