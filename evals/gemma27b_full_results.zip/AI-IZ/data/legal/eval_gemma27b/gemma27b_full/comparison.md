# Kaggle eval run gemma27b_full

400 questions planned (new400), 10 cases; notebook ran 5.81 h

## gemma3:27b-it-qat

### Questions: 400 of 400 answered

mean model time per question: 39.1 s; by category: {'rule_recall': 88, 'rule_conclusion': 72, 'mcq_bar': 64, 'rule_application': 48, 'interpretation': 32, 'issue_spotting': 28, 'citation_grounding': 28, 'abstention': 24, 'temporal_amendment': 16}

| | new questions | the 29 Sept 100: then | now |
|---|---|---|---|
| multiple choice | 56/64 | 14/16 | - |
| yes no label | 57/72 | 15/18 | - |
| governing section retrieved pct | 84.5 | 88.8 | - |
| plans cut off | 65 | 36 | - |
| plans with section numbers | 306 | 59 | - |
| judged score (%) | after Claude's judging | 75.8 | after Claude's judging |

errors 0, empty 0; repairs {'hebrew_rewrite': 18, 'stray_yes_no_opener': 6}; answers with a stray template token: 8

### Cases

| case | judged (run 1 / run 2) | rubric sections retrieved (run 1 / run 2 / now) | deadline hedges (run 1 / run 2 / now) | flagged values | repairs | minutes |
|---|---|---|---|---|---|---|
| case_01 | 25 / 27 | 1/10 / 2/10 / 1/10 | 3 / 2 / 6 | 10.10, 10.11 | facts_revised | 8.4 |
| case_02 | 31 / 43 | 2/5 / 2/5 / 2/5 | 3 / 5 / 0 | 30.10, 8,000 | facts_revised | 7.7 |
| case_03 | 43 / 50 | 3/5 / 4/5 / 2/5 | 2 / 1 / 1 | 16.9, 1.10 | facts_revised | 7.2 |
| case_04 | 42 / 27 | 1/9 / 1/9 / 2/9 | 3 / 0 / 4 | - | - | 4.2 |
| case_05 | 44 / 41 | 4/9 / 1/9 / 3/9 | 3 / 1 / 4 | - | - | 5.1 |
| case_06 |  /  |  /  / 3/8 |  /  / 1 | 17.9 | facts_revised | 7.9 |
| case_07 |  /  |  /  / 2/13 |  /  / 3 | 15.6 | facts_revised | 9.1 |
| case_08 |  /  |  /  / 2/11 |  /  / 1 | - | - | 4.6 |
| case_09 |  /  |  /  / 2/7 |  /  / 0 | 28.3, 16.9 | facts_revised | 8.5 |
| case_10 |  /  |  /  / 0/5 |  /  / 0 | - | - | 3.9 |

rubric sections retrieved in total: run 1 11/38, run 2 10/38, now 19/82

- case_01 still missing: חוק בית הדין לעבודה s.24; חוק הגנת השכר s.17; חוק הגנת השכר s.9; חוק הודעה מוקדמת לפיטורים ולהתפטרות s.3; חוק פיצויי פיטורים s.1; חוק פיצויי פיטורים s.12; חוק פיצויי פיטורים s.14; חוק שוויון ההזדמנויות בעבודה s.2; חוק שוויון ההזדמנויות בעבודה s.9
- case_02 still missing: חוק החוזים (תרופות בשל הפרת חוזה) s.10; חוק החוזים (תרופות בשל הפרת חוזה) s.2; חוק השכירות והשאילה s.25ח
- case_03 still missing: חוק הגנת הצרכן s.14ג; חוק הגנת הצרכן s.2; חוק הגנת הצרכן s.31א
- case_04 still missing: חוק החוזים (תרופות בשל הפרת חוזה) s.10; חוק החוזים (תרופות בשל הפרת חוזה) s.2; חוק החוזים (תרופות בשל הפרת חוזה) s.9; חוק המקרקעין s.127; חוק המקרקעין s.7; חוק העונשין s.415; פקודת הנזיקין [נוסח חדש] s.35
- case_05 still missing: חוק הירושה s.19; חוק הירושה s.20; חוק הירושה s.26; חוק הירושה s.27; חוק הירושה s.30; חוק הירושה s.56
- case_06 still missing: חוק ההתיישנות s.10; חוק ההתיישנות s.5; חוק ההתיישנות s.9; חוק הפיצויים לנפגעי תאונות דרכים s.2; חוק הפיצויים לנפגעי תאונות דרכים s.6ב
- case_07 still missing: חוק הבוררות s.1; חוק הבוררות s.5; חוק החוזים (חלק כללי) (תיקון מס' 3) s.1; חוק החוזים (חלק כללי) (תיקון מס' 3) s.2; חוק החוזים (תרופות בשל הפרת חוזה) s.10; חוק החוזים (תרופות בשל הפרת חוזה) s.14; חוק החוזים (תרופות בשל הפרת חוזה) s.15; חוק החוזים (תרופות בשל הפרת חוזה) s.8; חוק החוזים (תרופות בשל הפרת חוזה) s.9; חוק המכר s.11; חוק המכר s.14
- case_08 still missing: חוק לשכת עורכי הדין s.90; חוק סדר הדין הפלילי (סמכויות אכיפה – מעצרים) s.13; חוק סדר הדין הפלילי (סמכויות אכיפה – מעצרים) s.17; חוק סדר הדין הפלילי (סמכויות אכיפה – מעצרים) s.21; חוק סדר הדין הפלילי (סמכויות אכיפה – מעצרים) s.29; חוק סדר הדין הפלילי [נוסח משולב] s.None; כללי לשכת עורכי הדין (אתיקה מקצועית) s.14; פקודת הראיות [נוסח חדש] s.12; פקודת הראיות [נוסח חדש] s.48
- case_09 still missing: חוק איסור לשון הרע s.14; חוק איסור לשון הרע s.2; חוק איסור לשון הרע s.7א; חוק בית הדין לעבודה s.24; חוק הגנת הפרטיות s.2
- case_10 still missing: חוק יחסי ממון בין בני זוג s.14; חוק יחסי ממון בין בני זוג s.2; חוק יחסי ממון בין בני זוג s.5; חוק יחסי ממון בין בני זוג s.5א; חוק יחסי ממון בין בני זוג s.8

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 410 | 0 | 1 | 20.8 | 7623 | 3132 |
| legal_eval_plan | 410 | 0 | 0 | 14.6 | 1342 | 557 |
| legal_eval_repair | 6 | 0 | 0 | 222.1 | 4811 | 3130 |
| legal_eval_rewrite | 18 | 0 | 0 | 20.3 | 555 | 483 |
