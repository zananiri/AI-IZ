# Kaggle eval run corpus_qwen14b_gemma12b

100 questions, 5 cases

## qwen3:14b

- answers 100 (errors 0, empty 0), cases 5 (errors 0)
- judge-free: multiple choice 0.938 (n=16), yes/no label 0.833 (n=18)
- repairs {'hebrew_rewrite': 24}; answers with other-script words: 25

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 105 | 0 | 0 | 54.2 | 8355 | 3330 |
| legal_eval_plan | 101 | 1 | 0 | 11.8 | 210 | 512 |
| legal_eval_rewrite | 24 | 0 | 0 | 12.9 | 747 | 684 |

## gemma3:12b

- answers 100 (errors 0, empty 0), cases 5 (errors 0)
- judge-free: multiple choice 0.812 (n=16), yes/no label 0.722 (n=18)
- repairs {}; answers with other-script words: 0

| call site | calls | stopped at length | errors | median s | max prompt tok | max output tok |
|---|---|---|---|---|---|---|
| legal_eval_baseline | 105 | 0 | 0 | 9.8 | 9840 | 1968 |
| legal_eval_plan | 104 | 4 | 0 | 9.1 | 221 | 512 |
